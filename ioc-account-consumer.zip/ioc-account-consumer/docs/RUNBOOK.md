# IOC Consumer Runbook

What to do when something happens. Every action here can be done in the Ops console
(`/ops/`) or with the Ops API; both are audited.

---

## The consumer says "WAITING FOR PLATFORM"

**What it means:** Azure SQL or the Schema Registry is unreachable (or throttling hard). The consumer
has paused itself. Kafka is holding the backlog. **Nothing is lost and nothing is going to the
failure tray** — that's deliberate.

**Do:**
1. Overview → *This pod* shows the reason (e.g. `SQLServerException: Read timed out`).
2. Fix or wait for the platform. The consumer probes with backoff (1s → 30s) and resumes on its own.
3. Watch lag drain on the Throughput chart.

**Don't:** restart pods (it only causes rebalances) or replay anything (nothing failed).

Splunk: `index=ioc type=consumer.paused OR type=consumer.resumed | table _time consumer reason`

---

## The failure tray is growing

1. Failure tray → filter by **Reason**.
2. Decide by reason:

| Reason | Usually means | Action |
|---|---|---|
| `TRANSIENT_EXHAUSTED` | deadlocks/timeouts on single records | Nothing — the timer retries at 1m, 5m, 15m, 1h, 4h. If many, check DB health. |
| `DEPENDENCY_MISSING` | something it needs hasn't arrived yet | Nothing — retried automatically. If it ends in MANUAL, chase the source of the missing entity. |
| `VALIDATION` | the source broke the contract | Raise with the source team. When they've fixed the data or we've fixed the mapper, **bulk replay** by filter. |
| `DESERIALISATION` | bytes aren't valid Avro / unknown schema | Raise with the source team; check the Schema Registry. Raw bytes are kept, so replay after the fix. |
| `CONFLICT` | same version, different content | A person decides. Open it, view the payload, compare with the stored account, then replay or discard with a reason. |
| `UNKNOWN` | usually our bug | Raise a defect with the failure id; replay after the fix. |

---

## Bulk replay after a fix

1. Failure tray → set filters (e.g. Reason = VALIDATION, Error class contains `currency`).
2. **Count matching events** — nothing changes yet.
3. Give a reason (e.g. "Mapper fix for blank currency, release 1.4.2") → **Request replay**.
4. Above the threshold (default 100) **someone else** approves under Replays. You can't approve your own.
5. The request runs rate-limited; progress shows processed / ok / failed again.

Replays go through "only apply if newer" — an old event can never overwrite newer data. Events that
are now older than what we hold finish as `REPLAYED (STALE)`, which is correct.

---

## Reprocess a time window after a logic bug

When the data was *processed* but with wrong logic (e.g. a mapping bug), the tray won't help.

1. Replays → **Re-read a range from Kafka**: partition + offset range.
2. Tick **Re-derive at the same version** so records at the version we already hold are re-applied
   with the fixed logic. Older versions still can't overwrite newer ones.
3. Count → reason → request → second approver.

If the range is older than Kafka retention, the count shows a warning; use the ledger archive.

---

## OFFSET_GAP alert

A run of offsets in a partition has no ledger line.

1. Reconciliation → Offset gaps. The note says whether Kafka actually holds data there.
2. *No data records* → already auto-explained (transaction markers / compaction).
3. *N data records exist* → **Re-read** the range (button on the row). They will be processed
   normally, and the gap closes.
4. Then **Mark explained** (admin) with what you found.

---

## CONTROL_TOTAL_MISMATCH alert

Source says it sent N records for a business day; IOC received a different number of distinct events.

- IOC lower → events lost before or inside Kafka. Ask the source team for the event ids; Trace each;
  check offset gaps for that day.
- IOC higher → the source sent more than it counted (often retries with new event ids). Check
  `DUPLICATE` counts for that day in the Ledger.

---

## OUTBOX_STUCK alert

An announcement has been waiting > 5 minutes.

1. Announcements → Status = PENDING; `last error` shows why (e.g. Credit Change topic ACLs, broker down).
2. Check that at least one pod holds outbox shard leases (log `Acquired outbox shards`).
3. Once Kafka accepts again, the postman catches up in order. Nothing to replay.

---

## Pausing a consumer on purpose

Admin → Overview → **Pause consumer** (e.g. during a source-side incident). Offsets stay put; Kafka
keeps the backlog. **Resume** when ready. Both actions are audited.
