# IOC Account Consumer — reference implementation

A Spring Boot consumer for the **Account Domain topic**, built exactly to the rule book in
`IOC_Consumer_Design_Simple.md` (and the longer `IOC_Consumer_Blueprint.md`). It is also the
template every other IOC topic consumer (covenants, properties, collateral, EB …) is built from.

The main goal is **traceability under heavy load**: for any account event you can show, with
evidence, whether it arrived, what happened to it, every retry and replay, who did what, and where
the resulting Credit Change announcement landed.

```
 Kafka (raw bytes) ──► decode ─► validate ─► seen this offset? ─► seen this eventId? ─► newest in batch? ─► newer than stored?
                                                                                                   │
                              ┌──────────────────────── ONE Azure SQL transaction ─────────────────┘
                              │  t1_account upsert  +  one ledger line per record  +  outbox note (if material)
                              └──────────────────────────────────┬───────────────────────────────────
                                                                 ▼
                                                    commit, THEN tick off the offsets
   bad record      → failure tray (raw bytes kept), carry on         postman → Credit Change topic → records partition/offset
   temporary blip  → retry 1s/2s/4s, then tray                       replay timer → 1m, 5m, 15m, 1h, 4h, then a person
   DB / SR down    → pause, Kafka holds the backlog, resume          ops console / API → replay, four-eyes, audit
```

> **Status:** written against Spring Boot 3.3, Java 21, Azure SQL. It has **not yet been compiled
> or run** — the environment it was written in had no access to Maven Central. Expect a short
> fix-up pass on the first `mvn verify`. The ops console was smoke-tested in demo mode.

---

## 1. What's in the box

```
ioc-account-consumer/
├── ioc-consumer-platform/        ← the shared library: the rule book, in code (reuse for every topic)
│   ├── core/                     EventPipeline (the heart), ErrorClassifier, PlatformHealth, InboundRecord …
│   ├── kafka/                    ConsumerRuntime (when to tick off), AvroPayloadDecoder, PipelineRegistry
│   ├── ledger/ failure/ outbox/  repositories for the ledger, failure tray, outbox (+ sharded publisher)
│   ├── replay/                   ReplayService (single, bulk, four-eyes), AutoReplayScheduler, KafkaRangeReader
│   ├── observability/            ConsumerStats (1-min Splunk summary), EventLog, ReconciliationService
│   ├── ops/ security/            Ops REST API, audit, Entra/local security
│   └── resources/static/ops/     the Ops console (single page, no external dependencies)
├── ioc-account-consumer/         ← the account topic: the FOUR things a topic team writes
│   ├── AccountEventMapper        Avro → AccountState          (the only class that knows the schema)
│   ├── AccountEventValidator     the topic contract
│   ├── AccountRepository         t1_account, batched, locked
│   ├── AccountMaterialityRule    "does this change matter?" (DRAFT — business to confirm)
│   └── dev/LocalEventSimulator   local profile only: a deliberately messy producer
├── docker-compose.yml            Kafka + Schema Registry (FULL_TRANSITIVE) + SQL Server
└── deploy/k8s/                   Deployment, PDB, KEDA ScaledObject (capped)
```

---

## 2. The design, point by point → where it lives

| Design doc section | What the code does | Where |
|---|---|---|
| **1. Same letter twice** | Offset seen → skip (Kafka redelivery). EventId seen → `DUPLICATE`. Same version + same content under a new id → `DUPLICATE`. Older version → `STALE`. Same version, different content → `CONFLICT` (tray). Version guard lives on the entity row, so it still works after the ledger is purged. | `EventPipeline.persist`, `t1_account.source_version/state_hash` |
| **2. Proving every letter** | One ledger line per offset, one outcome: `PROCESSED, DUPLICATE, STALE, SUPERSEDED, FILTERED, FAILED, REPLAYED`. Every later change of outcome is kept in `event_ledger_transition`. Offset-gap check verifies holes against Kafka. Daily control totals vs producer counts. | `LedgerRepository`, `ReconciliationService` |
| **3. Can't be processed** | One failure tray for all topics with raw bytes + headers + category. Bad record → tray, carry on. Temporary → 3 quick retries then tray. **DB/Schema Registry down → pause and wait; the tray stays empty.** | `ErrorClassifier`, `EventPipeline.persistWithBisect`, `ConsumerRuntime` |
| **4. Replaying** | Timer retries `TRANSIENT_EXHAUSTED` / `DEPENDENCY_MISSING` at 1m, 5m, 15m, 1h, 4h, then `MANUAL`. Manual: single, bulk by filter, or Kafka offset re-read. Count first, second person above the threshold, rate-limited, audited. Replay runs the same pipeline, so old data can never overwrite new. | `AutoReplayScheduler`, `ReplayService`, `KafkaRangeReader` |
| **5. Layout changes** | Bytes are decoded inside the pipeline (no poison pills). Schema Registry `FULL_TRANSITIVE`; schemas registered by CI, never by the app. Mapper is the only class that knows the Avro shape. Expand–contract Flyway migrations. Graceful shutdown + static membership + cooperative rebalancing. | `AvroPayloadDecoder`, `AccountEventMapper`, `application.yml` |
| **6. Floods** | Kafka is the waiting room. Batch mode (500/poll), **coalescing** (only the newest version per account is written), **bisect** on a bad batch (the other 499 commit). KEDA scales on lag but is capped by DB capacity. Sustained throttling escalates to a pause instead of filling the tray. | `EventPipeline`, `deploy/k8s` |
| **7. Telling the rest of IOC** | Materiality rule decides (≈1 in 100). Outbox note written **in the same transaction** as the change. Postman sends from sharded leases: one sender per shard ⇒ per-account order kept; scales out. | `AccountMaterialityRule`, `OutboxRepository`, `OutboxPublisher`, `ShardLeaseManager` |
| **8. Proving announcements** | On broker ack (`acks=all`, idempotent producer) the outbox row records topic/partition/offset. Stuck-note alert after 5 min. Same trace id from source record → ledger → outbox → Credit Change headers (`traceparent`, `ioc-trace-id`). | `OutboxPublisher` |
| **9. Event ledger** | Yes. Accounts use evidence level `METADATA` (SHA-256 fingerprint, no payload) — 20M/day × full payload ≈ 7 TB/yr. Failures always keep their bytes. One ledger = the HLD's Tier 1 general ledger. | `EvidenceLevel`, `V1__consumer_platform.sql` |
| **10. Splunk** | Successes are **counted**, not logged: one `consumer.summary` line per consumer per minute. Every failure, replay, pause and ops action gets one structured line with the same fields for every topic. | `ConsumerStats`, `EventLog`, `logback-spring.xml` |
| **11. Source teams** | Contract enforced by the validator; producer totals accepted via the API. | `AccountEventValidator`, `POST …/control-totals` |
| **12. Prove it** | Testcontainers suite: one test per rule. | `AccountConsumerIT` |

### Industry practices applied

| Practice | Why it's here |
|---|---|
| Idempotent consumer + optimistic version guard | At-least-once delivery is a fact; correctness can't depend on "exactly once". |
| Commit-after-transaction (manual ack) | A crash anywhere loses nothing; redelivery is a no-op. |
| Raw-bytes consumption + in-pipeline deserialisation | Poison pills become ordinary, replayable failures. |
| Error classification: data / transient / platform | Bad records don't stop the belt; a broken DB doesn't flood the tray. |
| Pause-with-backoff via `nack` (container paused, no rebalance) | Kafka holds the backlog; consumer keeps its partitions. |
| Batch + coalesce + bisect | Throughput for 20M/day without one bad record failing 499 good ones. |
| Transactional outbox + sharded single-writer publisher | No lost or phantom announcements; per-entity order; horizontal scale; Debezium can replace the postman later without touching consumers. |
| W3C `traceparent` propagation, deterministic fallback trace id | One id from source record to CLM UI; redelivery and replay share it. |
| Structured JSON logs, counts-not-lines, one schema for all consumers | Splunk cost under control; one search for every topic. |
| Four-eyes (enforced in code AND by a DB `CHECK`), dry-run, rate limit, audit | Bank-grade control over bulk data changes. |
| Least privilege roles; payload view needs a stronger role and is audited | Customer data minimisation. |
| CooperativeSticky + static membership + graceful shutdown | Deploys and pod restarts don't stop the world. |
| Probes independent of DB/Kafka | Restarting pods never fixes a DB outage; it only causes rebalances. |
| `FULL_TRANSITIVE` schemas, v2 topics for breaking changes | 15+ producer teams can deploy in any order. |

---

## 3. Run it locally

```bash
docker compose up -d                      # Kafka, Schema Registry, SQL Server (creates DB 'ioc', topics)
mvn -pl ioc-account-consumer -am spring-boot:run -Dspring-boot.run.profiles=local
```

Open **http://localhost:8080/ops/** and sign in:

| User | Roles | Try |
|---|---|---|
| `viewer` / `viewer` | read | everything read-only, no payloads |
| `alice` / `alice` | read, replay | replay one event, request a bulk replay |
| `bob` / `bob` | read, replay, approve | approve alice's request (he can't approve his own) |
| `admin` / `admin` | all | pause/resume, mark gaps explained, submit control totals |

Then go to **Simulator** (local only) and publish 2,000 events. The simulator injects duplicates,
republish-with-new-id, stale versions, conflicts, contract breaches, corrupt bytes and over-limit
moves, so every screen has something on it.

---

## 4. The Ops console

| Screen | Answers |
|---|---|
| **Overview** | Is it running or waiting for the platform? Consumed vs processed vs failed in the last 1h/24h/7d. *"Every record accounted for"*: consumed = sum of outcomes. What needs a person right now. |
| **Trace an event** | Search by eventId, traceId, account key or `topic/partition@offset`. Shows the whole trail: Kafka record → ledger line → tray + every attempt → replays → outbox note → Credit Change partition/offset. |
| **Ledger** | Every line, filterable by outcome, account, partition, offset range, announced-only. |
| **Failure tray** | Filter by reason/status; open one (error, attempts, payload); replay or discard (reason required); *replay everything matching* with a dry-run count. |
| **Replays** | Bulk requests with progress, approve/reject (four-eyes), cancel; re-read an offset range from Kafka. |
| **Announcements** | Outbox notes, why they were announced, and where Kafka put them. |
| **Reconciliation** | Offset gaps (auto-explained when Kafka holds no data there) and daily control totals. |
| **Audit trail** | Who did what, when, with which filter, and the result. |

Everything in the console is also an API under `/ops/api/**` (same roles), so runbooks and scripts
can do the same things:

```
GET  /ops/api/consumers/{c}/overview?hours=24
GET  /ops/api/consumers/{c}/trace?q={eventId|traceId|accountKey|topic/partition@offset}
GET  /ops/api/consumers/{c}/ledger?outcome=&entityKey=&partition=&offsetFrom=&offsetTo=&from=&to=
GET  /ops/api/consumers/{c}/failures?category=&status=&entityKey=&errorClass=
GET  /ops/api/consumers/{c}/failures/{id}            GET …/failures/{id}/payload   (OPS_REPLAY, audited)
POST /ops/api/consumers/{c}/failures/{id}/replay     POST …/failures/{id}/discard {reason}
POST /ops/api/consumers/{c}/replay/dry-run           {type: FAILURES|KAFKA_RANGE, filter}
POST /ops/api/consumers/{c}/replay-requests          {type, filter, reason}
POST /ops/api/replay-requests/{id}/approve|reject|cancel
GET  /ops/api/consumers/{c}/outbox  …/gaps  …/control-totals      POST …/control-totals {businessDate, producerCount}
POST /ops/api/consumers/{c}/pause|resume            GET /ops/api/audit
```

---

## 5. Answering the auditor

> *"On 3 September the Account Domain sent a change for account TRANSACT:IE00412345. Did IOC receive it? What did it do with it? Did CLM get told?"*

1. **Trace** → search `TRANSACT:IE00412345` (or the eventId they quote).
2. The timeline shows the Kafka record (partition/offset, Kafka time, SHA-256 of the exact bytes),
   the ledger outcome, any failure and each retry with who/when, and — if material — the outbox
   note and the Credit Change **partition/offset Kafka acknowledged**.
3. Splunk: `index=ioc traceId=<the trace id>` returns every log line about it.
4. For "did you lose anything that day": **Reconciliation** shows the producer's total vs IOC's.

Useful Splunk searches:

```
index=ioc type=consumer.summary | timechart span=15m sum(consumed) sum(processed) sum(failed) sum(retried) by consumer
index=ioc type=consumer.event outcome=FAILED | stats count by consumer, errorCategory, errorClass
index=ioc type=ioc.alert | stats latest(_time) count by alert, consumer
index=ioc type=consumer.paused | table _time consumer reason backoffMs redeliverFrom
index=ioc type=ops.action | table _time actor action target result
```

---

## 6. Adding the next topic (covenants, properties …)

Write four classes and a `TopicHandler` that wires them, plus a 5-line `@KafkaListener`:

1. **Mapper** — Avro → your stable internal record.
2. **Validator** — throw `ValidationException` listing every problem.
3. **Repository** — `lockAndLoad` (`WITH (UPDLOCK, HOLDLOCK)`) and batched `apply`.
4. **Materiality rule** — return reasons; version it in config.

Throw `DependencyMissingException` when something the event needs hasn't arrived (e.g. covenant
before its CCV) — the timer retries it. Choose `EvidenceLevel.FULL` for small, audit-sensitive
topics. Everything else — ledger, tray, replay, outbox, logs, metrics, console — comes for free.

---

## 7. Tests

| Test | Proves |
|---|---|
| `ErrorClassifierTest` | Bad letter vs temporary blip vs broken system is decided correctly (incl. Schema Registry down vs unknown schema). |
| `BackoffScheduleTest` | 1m → 5m → 15m → 1h → 4h → a person; broken letters never auto-retried. |
| `InboundRecordTest` | traceparent parsing, deterministic trace ids, schema id, fingerprints. |
| `AccountMaterialityRuleTest` | Balance moves inside the limit are not announced; limit crossings, limit changes, 90% utilisation, new/deleted accounts are. |
| `AccountContractTest` | Mapping, contract checks, and DUPLICATE-vs-CONFLICT fingerprints. |
| `AccountConsumerIT` (Docker) | Duplicates harmless · every record one ledger line, no offset holes · corrupt bytes don't block · contract breach waits for a person · **DB frozen → consumer pauses, tray stays empty, catches up** · replay can't overwrite newer data · announcement evidence + same trace id · four-eyes. |

```bash
mvn verify            # unit + integration (needs Docker)
```

Still to add before production: a **10× load test** against a production-sized Azure SQL tier (to set
`maxReplicaCount`, pool size and batch size), and a CI step that checks schema compatibility.

---

## 8. Production checklist

- **Security:** `IOC_OPS_SECURITY=entra`. Create app roles `OPS_READ`, `OPS_REPLAY`, `OPS_APPROVE`,
  `OPS_ADMIN`, `RECON_SUBMIT` and configure `spring.security.oauth2.client.registration.entra` +
  `spring.security.oauth2.resourceserver.jwt.issuer-uri`. Expose `/actuator/prometheus` only inside the cluster.
- **Database:** Managed Identity auth, `socketTimeout` set (a frozen connection must fail, not hang).
  Run Flyway from the pipeline (`IOC_FLYWAY_ON_START=false`). Partition `event_ledger` by
  `business_date`, keep ~30 days hot, archive older partitions to ADLS (Parquet).
- **Sizing:** `pods × concurrency ≤ partitions`; `pods × IOC_DB_POOL <` Azure SQL connection limit.
  Optional: `useBulkCopyForBatchInsert=true` on the JDBC URL after the load test.
- **Kafka:** `group.instance.id` from the pod name (static membership), Confluent Cloud SASL settings in the secret.
- **Schemas:** registered by CI with `FULL_TRANSITIVE`; `auto.register.schemas=false` in every non-local env.
- **Alerts:** `ioc.alert` lines (OUTBOX_STUCK, OFFSET_GAP, CONTROL_TOTAL_MISMATCH, FAILURE_TRAY_WRITE_FAILED,
  CONSUMER_UNEXPECTED_ERROR), `ioc.consumer.platform.down == 1` for > 5 min, consumer lag, open MANUAL failures.

---

## 9. Placeholders and decisions still needed

| Item | Current value | Who decides |
|---|---|---|
| Account topic name | `credit.account.v1` (placeholder) | Account Domain |
| Avro schema | placeholder built from the Data Inventory's Account fields | Account Domain — **only the mapper and validator change** |
| Snapshot or delta? | The design assumes **full snapshots** (duplicates harmless). Deltas would need strict ordering and key parking. | Account Domain |
| Monotonic `sourceVersion` per account | Assumed present | Account Domain |
| Materiality rule | `ACC-MAT-0.1-DRAFT`: new/deleted, over-limit in/out, limit change, 90% utilisation, forbearance, status, collateral and customer links | Business + Architecture |
| Balance sign convention | utilisation uses `|balance|` | Account Domain |
| Credit Change topic name | `ioc.credit.change.v1` | Architecture |
| Approval threshold for bulk replay | 100 events | Ops / Risk |
| Ledger hot window / archive retention | 30 days / TBD | Architecture + Compliance |
| Daily control totals from the producer | API ready; producer job needed | Account Domain |
