package ie.aib.ioc.account.dev;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import ie.aib.account.events.v1.AccountEvent;
import ie.aib.account.events.v1.AccountSnapshot;
import ie.aib.account.events.v1.ChangeType;
import ie.aib.account.events.v1.EventHeader;
import ie.aib.ioc.account.AccountProperties;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.context.annotation.Profile;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * LOCAL PROFILE ONLY. Plays the Account Domain: publishes a realistic, deliberately messy stream so
 * every path in the console lights up — duplicates, republish-with-new-id, stale and conflicting
 * versions, contract breaches, corrupt bytes, over-limit transitions.
 *
 * <p>Use it from the console's <b>Simulator</b> tab (shown only when the {@code local} profile is active).
 */
@RestController
@Profile("local")
public class LocalEventSimulator {

    private static final String[] SYSTEMS = {"TRANSACT", "LOAN_ACCOUNTING", "BRANCH_ACCOUNTING"};
    private static final String[] STATUSES = {"ACTIVE", "ACTIVE", "ACTIVE", "ARREARS", "DORMANT"};

    private final KafkaTemplate<String, Object> avro;
    private final KafkaTemplate<String, byte[]> raw;
    private final String topic;
    private final Map<String, Acc> book = new HashMap<>();

    public LocalEventSimulator(KafkaProperties kafka, ObjectProvider<SslBundles> ssl, AccountProperties props) {
        Map<String, Object> cfg = new HashMap<>(kafka.buildProducerProperties(ssl.getIfAvailable()));
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        cfg.put("auto.register.schemas", true);
        cfg.put(ProducerConfig.CLIENT_ID_CONFIG, "dev-simulator");
        this.avro = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(cfg));
        Map<String, Object> rawCfg = new HashMap<>(cfg);
        rawCfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        rawCfg.put(ProducerConfig.CLIENT_ID_CONFIG, "dev-simulator-raw");
        this.raw = new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(rawCfg));
        this.topic = props.getTopic();
    }

    @PostMapping("/dev/simulate")
    public synchronized Map<String, Object> simulate(@RequestBody Simulation s) {
        Random rnd = new Random(s.seed() == null ? System.nanoTime() : s.seed());
        int accounts = s.accounts() == null ? 200 : s.accounts();
        int events = s.events() == null ? 2000 : s.events();
        Map<String, Integer> sent = new LinkedHashMap<>();

        for (int i = 0; i < events; i++) {
            String number = String.format("IE%08d", rnd.nextInt(accounts));
            String system = SYSTEMS[Math.floorMod(number.hashCode(), SYSTEMS.length)];
            String key = system + ":" + number;
            Acc acc = book.computeIfAbsent(key, k -> Acc.open(number, system, rnd));
            boolean created = acc.version == 0;
            acc.version++;
            acc.move(rnd, pct(s.overLimitPct(), 2));
            String trace = rnd.nextInt(3) == 0 ? hex(rnd, 32) : null;
            AccountEvent ev = acc.toEvent(UUID.randomUUID().toString(), created ? ChangeType.CREATED : ChangeType.UPDATED, trace);
            send(key, ev, trace, sent, "normal");

            double roll = rnd.nextDouble() * 100;
            if (roll < pct(s.duplicatePct(), 2)) {
                send(key, ev, trace, sent, "duplicate (same eventId)");
            } else if ((roll -= pct(s.duplicatePct(), 2)) < pct(s.republishPct(), 1)) {
                send(key, acc.toEvent(UUID.randomUUID().toString(), ChangeType.UPDATED, null), null, sent, "republish (new eventId, same version)");
            } else if ((roll -= pct(s.republishPct(), 1)) < pct(s.stalePct(), 1) && acc.version > 1) {
                AccountEvent stale = acc.toEvent(UUID.randomUUID().toString(), ChangeType.UPDATED, null);
                stale.getHeader().setSourceVersion(acc.version - 1);
                stale.getAccount().setAccountBalance(stale.getAccount().getAccountBalance().add(BigDecimal.ONE));
                send(key, stale, null, sent, "stale (older version)");
            } else if ((roll -= pct(s.stalePct(), 1)) < pct(s.conflictPct(), 0.2)) {
                AccountEvent conflict = acc.toEvent(UUID.randomUUID().toString(), ChangeType.UPDATED, null);
                conflict.getAccount().setAccountBalance(conflict.getAccount().getAccountBalance().add(new BigDecimal("999.00")));
                send(key, conflict, null, sent, "conflict (same version, different content)");
            } else if ((roll -= pct(s.conflictPct(), 0.2)) < pct(s.invalidPct(), 0.3)) {
                AccountEvent bad = acc.toEvent(UUID.randomUUID().toString(), ChangeType.UPDATED, null);
                bad.getAccount().setCurrency("EURO");
                bad.getAccount().setAccountLimit(new BigDecimal("-1.00"));
                send(key, bad, null, sent, "contract breach (validation)");
            } else if ((roll -= pct(s.invalidPct(), 0.3)) < pct(s.poisonPct(), 0.2)) {
                raw.send(new ProducerRecord<>(topic, key, ("not avro " + UUID.randomUUID()).getBytes(StandardCharsets.UTF_8)));
                sent.merge("corrupt bytes (deserialisation)", 1, Integer::sum);
            }
        }
        avro.flush();
        raw.flush();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("topic", topic);
        out.put("recordsSent", sent.values().stream().mapToInt(Integer::intValue).sum());
        out.put("byKind", sent);
        out.put("accountsKnown", book.size());
        return out;
    }

    private void send(String key, AccountEvent ev, String trace, Map<String, Integer> sent, String kind) {
        ProducerRecord<String, Object> rec = new ProducerRecord<>(topic, key, ev);
        if (trace != null) {
            rec.headers().add("traceparent", ("00-" + trace + "-00f067aa0ba902b7-01").getBytes(StandardCharsets.US_ASCII));
        }
        avro.send(rec);
        sent.merge(kind, 1, Integer::sum);
    }

    private static double pct(Double v, double dflt) {
        return v == null ? dflt : v;
    }

    private static String hex(Random r, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append(Character.forDigit(r.nextInt(16), 16));
        }
        return sb.toString();
    }

    public record Simulation(Integer accounts, Integer events, Long seed, Double duplicatePct, Double republishPct,
                             Double stalePct, Double conflictPct, Double invalidPct, Double poisonPct, Double overLimitPct) {
    }

    /** The simulator's own idea of each account. */
    private static final class Acc {
        String number;
        String system;
        String customer;
        BigDecimal limit;
        BigDecimal balance;
        String status;
        List<String> collateral = new ArrayList<>();
        LocalDate fStart;
        LocalDate fEnd;
        long version;

        static Acc open(String number, String system, Random rnd) {
            Acc a = new Acc();
            a.number = number;
            a.system = system;
            a.customer = "CIF" + (100000 + rnd.nextInt(900000));
            a.limit = BigDecimal.valueOf(10_000 + rnd.nextInt(2_000_000)).setScale(2, RoundingMode.HALF_UP);
            a.balance = a.limit.multiply(BigDecimal.valueOf(0.4 + rnd.nextDouble() * 0.45)).setScale(2, RoundingMode.HALF_UP);
            a.status = "ACTIVE";
            if (rnd.nextInt(4) == 0) {
                a.collateral.add("SIN" + (10000 + rnd.nextInt(90000)));
            }
            return a;
        }

        void move(Random rnd, double overLimitPct) {
            if (rnd.nextDouble() * 100 < overLimitPct) {
                balance = limit.multiply(BigDecimal.valueOf(1.01 + rnd.nextDouble() * 0.1)).setScale(2, RoundingMode.HALF_UP);
            } else if (rnd.nextInt(50) == 0) {
                limit = limit.multiply(BigDecimal.valueOf(1.1)).setScale(2, RoundingMode.HALF_UP);
            } else if (rnd.nextInt(200) == 0) {
                fStart = LocalDate.now();
                fEnd = fStart.plusMonths(6);
            } else if (rnd.nextInt(300) == 0) {
                status = STATUSES[rnd.nextInt(STATUSES.length)];
            } else {
                BigDecimal delta = limit.multiply(BigDecimal.valueOf((rnd.nextDouble() - 0.5) * 0.02));
                balance = balance.add(delta).max(BigDecimal.ZERO).setScale(2, RoundingMode.HALF_UP);
                if (balance.compareTo(limit) > 0 && rnd.nextBoolean()) {
                    balance = limit.multiply(BigDecimal.valueOf(0.8)).setScale(2, RoundingMode.HALF_UP);
                }
            }
        }

        AccountEvent toEvent(String eventId, ChangeType type, String trace) {
            return AccountEvent.newBuilder()
                    .setHeader(EventHeader.newBuilder().setEventId(eventId).setEventType(type).setSourceSystem(system)
                            .setSourceVersion(version).setOccurredAt(Instant.now()).setTraceId(trace).build())
                    .setAccount(AccountSnapshot.newBuilder().setSourceAccountNumber(number).setSourceAccountingSystem(system)
                            .setSourceCustomerId(customer).setCurrency("EUR").setAccountLimit(limit).setAccountBalance(balance)
                            .setAccountStatus(status).setFacilityRepaymentType(null).setCollateralIds(new ArrayList<>(collateral))
                            .setForbearanceStartDate(fStart).setForbearanceEndDate(fEnd).build())
                    .build();
        }
    }
}
