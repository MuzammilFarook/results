package ie.aib.ioc.account;

import java.util.TimeZone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/** IOC Account consumer — Tier 1, Account Domain topic. */
@SpringBootApplication(scanBasePackages = "ie.aib.ioc")
@ConfigurationPropertiesScan("ie.aib.ioc")
public class AccountConsumerApplication {

    public static void main(String[] args) {
        // Everything is stored and reasoned about in UTC; only the console displays Europe/Dublin.
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        SpringApplication.run(AccountConsumerApplication.class, args);
    }
}
