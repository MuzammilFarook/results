package ie.aib.ioc.account;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import ie.aib.account.events.v1.AccountEvent;
import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.ConsumerSettings;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.InboundRecord;
import ie.aib.ioc.platform.core.Materiality;
import ie.aib.ioc.platform.core.TopicHandler;
import org.springframework.stereotype.Component;

/**
 * Wires the account topic's four pieces (mapper, validator, repository, materiality rule) into the
 * platform. Everything else — ledger, dedup, version guard, batching, failure tray, outbox,
 * replay, logging, metrics, ops console — is the platform's job.
 */
@Component
public class AccountTopicHandler implements TopicHandler<AccountEvent, AccountState> {

    private final AccountProperties props;
    private final AccountEventMapper mapper;
    private final AccountEventValidator validator;
    private final AccountRepository repository;
    private final AccountMaterialityRule materiality;

    public AccountTopicHandler(AccountProperties props, AccountEventMapper mapper, AccountEventValidator validator,
                               AccountRepository repository, AccountMaterialityRule materiality) {
        this.props = props;
        this.mapper = mapper;
        this.validator = validator;
        this.repository = repository;
        this.materiality = materiality;
    }

    @Override
    public ConsumerSettings settings() {
        return new ConsumerSettings(props.getConsumerName(), props.getTopic(), "ACCOUNT", props.getEvidenceLevel(),
                materiality.version());
    }

    @Override
    public Class<AccountEvent> avroType() {
        return AccountEvent.class;
    }

    @Override
    public DecodedEvent<AccountState> decode(AccountEvent avro) {
        return mapper.decode(avro);
    }

    @Override
    public void validate(DecodedEvent<AccountState> event) {
        validator.validate(event);
    }

    /** Business content only — two events with the same content hash say the same thing. */
    @Override
    public byte[] stateHash(DecodedEvent<AccountState> e) {
        AccountState s = e.state();
        String canonical = String.join("|",
                e.kind().name(),
                s.accountingSystem(), s.accountNumber(), nz(s.customerId()), nz(s.currency()),
                amount(s.limit()), amount(s.balance()), nz(s.status()), nz(s.repaymentType()),
                String.join(",", s.collateralIds()),
                s.forbearanceStart() == null ? "" : s.forbearanceStart().toString(),
                s.forbearanceEnd() == null ? "" : s.forbearanceEnd().toString());
        return InboundRecord.sha256(canonical.getBytes(StandardCharsets.UTF_8));
    }

    @Override
    public Optional<String> filterReason(DecodedEvent<AccountState> event) {
        if (props.getInScopeAccountingSystems().isEmpty()
                || props.getInScopeAccountingSystems().contains(event.state().accountingSystem())) {
            return Optional.empty();
        }
        return Optional.of("Accounting system " + event.state().accountingSystem() + " is not in IOC scope");
    }

    @Override
    public Map<String, CurrentState<AccountState>> lockAndLoad(Collection<String> entityKeys) {
        return repository.lockAndLoad(entityKeys);
    }

    @Override
    public void apply(List<AppliedChange<AccountState>> changes) {
        repository.apply(changes, this::stateHash);
    }

    @Override
    public Materiality assessMateriality(CurrentState<AccountState> before, DecodedEvent<AccountState> after) {
        return materiality.assess(before, after);
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String amount(java.math.BigDecimal v) {
        return v == null ? "" : v.stripTrailingZeros().toPlainString();
    }
}
