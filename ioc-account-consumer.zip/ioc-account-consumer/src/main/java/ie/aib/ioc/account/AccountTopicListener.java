package ie.aib.ioc.account;

import java.util.List;

import ie.aib.ioc.platform.config.PlatformConfiguration;
import ie.aib.ioc.platform.kafka.ConsumerRuntime;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * The clerk at the account conveyor belt. Raw bytes in, a batch at a time; the platform runtime
 * decides when offsets are ticked off.
 */
@Component
public class AccountTopicListener {

    private final ConsumerRuntime runtime;

    public AccountTopicListener(PipelineRegistry registry, AccountProperties props) {
        this.runtime = registry.runtime(props.getConsumerName());
    }

    @KafkaListener(
            id = "${ioc.account.consumer-name:account-consumer}",
            topics = "${ioc.account.topic}",
            containerFactory = PlatformConfiguration.BATCH_FACTORY,
            autoStartup = "${ioc.account.auto-startup:true}")
    public void onBatch(List<ConsumerRecord<byte[], byte[]>> records, Acknowledgment ack) {
        runtime.onBatch(records, ack);
    }
}
