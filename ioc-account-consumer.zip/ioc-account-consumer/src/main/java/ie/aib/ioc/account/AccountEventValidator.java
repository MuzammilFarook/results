package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.ValidationException;
import org.springframework.stereotype.Component;

/**
 * Validator: the topic contract, checked on every event. A breach is a "broken letter" — it goes
 * to the failure tray as VALIDATION and waits for a person (retrying would fail the same way).
 * All problems are reported at once, so whoever fixes it sees the full list.
 */
@Component
public class AccountEventValidator {

    private static final Duration MAX_CLOCK_SKEW = Duration.ofHours(24);
    private static final BigDecimal MAX_AMOUNT = new BigDecimal("9999999999999999.99"); // DECIMAL(18,2)

    private final Clock clock;

    public AccountEventValidator(Clock clock) {
        this.clock = clock;
    }

    public void validate(DecodedEvent<AccountState> e) {
        List<String> problems = new ArrayList<>();
        AccountState s = e.state();

        require(problems, e.eventId() != null && !e.eventId().isBlank(), "header.eventId is blank");
        require(problems, e.eventId() == null || e.eventId().length() <= 100, "header.eventId longer than 100");
        require(problems, e.sourceVersion() >= 0, "header.sourceVersion is negative");
        require(problems, e.sourceSystem() != null && !e.sourceSystem().isBlank(), "header.sourceSystem is blank");
        require(problems, e.occurredAt() == null || !e.occurredAt().isAfter(clock.instant().plus(MAX_CLOCK_SKEW)),
                "header.occurredAt is more than 24h in the future");

        require(problems, s.accountNumber() != null && !s.accountNumber().isBlank(), "account.sourceAccountNumber is blank");
        require(problems, s.accountNumber() == null || s.accountNumber().length() <= 64, "account.sourceAccountNumber longer than 64");
        require(problems, s.accountingSystem() != null && !s.accountingSystem().isBlank(), "account.sourceAccountingSystem is blank");
        require(problems, s.accountingSystem() == null || s.accountingSystem().length() <= 64, "account.sourceAccountingSystem longer than 64");
        require(problems, s.currency() != null && s.currency().matches("[A-Z]{3}"), "account.currency is not an ISO 4217 code");
        require(problems, s.balance() != null, "account.accountBalance is missing");
        require(problems, s.balance() == null || s.balance().abs().compareTo(MAX_AMOUNT) <= 0, "account.accountBalance out of range");
        require(problems, s.limit() == null || s.limit().signum() >= 0, "account.accountLimit is negative");
        require(problems, s.limit() == null || s.limit().compareTo(MAX_AMOUNT) <= 0, "account.accountLimit out of range");
        require(problems, s.customerId() == null || s.customerId().length() <= 64, "account.sourceCustomerId longer than 64");
        require(problems, String.join(",", s.collateralIds()).length() <= 2000, "account.collateralIds too long");
        require(problems, s.forbearanceStart() == null || s.forbearanceEnd() == null
                || !s.forbearanceEnd().isBefore(s.forbearanceStart()), "forbearanceEndDate is before forbearanceStartDate");

        if (!problems.isEmpty()) {
            throw new ValidationException(String.join("; ", problems));
        }
    }

    private static void require(List<String> problems, boolean ok, String problem) {
        if (!ok) {
            problems.add(problem);
        }
    }
}
