package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.Materiality;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;
import org.springframework.stereotype.Component;

/**
 * "Only about 1 in 100 account changes matters to credit." This decides which.
 *
 * <p>DRAFT rule (version in {@code ioc.account.materiality.version}) — for the business to confirm:
 * <ul>
 *   <li>NEW_ACCOUNT / ACCOUNT_DELETED</li>
 *   <li>OVER_LIMIT_ENTERED / OVER_LIMIT_CLEARED — the account crosses its limit either way</li>
 *   <li>LIMIT_CHANGED</li>
 *   <li>UTILISATION_CROSSED_90PCT — crosses a configured utilisation threshold either way</li>
 *   <li>FORBEARANCE_CHANGED, STATUS_CHANGED</li>
 *   <li>COLLATERAL_LINKS_CHANGED, CUSTOMER_LINK_CHANGED — these move the account in the linkage graph (Tier 2)</li>
 * </ul>
 * NOT material: balance movements that stay on the same side of every threshold — the other ~99%.
 * They are still saved and still in the ledger; they just aren't announced.
 */
@Component
public class AccountMaterialityRule {

    private final AccountProperties.MaterialityRule cfg;

    public AccountMaterialityRule(AccountProperties props) {
        this.cfg = props.getMateriality();
    }

    public Materiality assess(CurrentState<AccountState> before, DecodedEvent<AccountState> after) {
        boolean existedBefore = before != null && !before.deleted();
        String changeType = "ACCOUNT_TIER1_" + (after.kind() == ChangeKind.DELETE ? "DELETED" : existedBefore ? "UPDATED" : "CREATED");
        List<String> reasons = new ArrayList<>();
        AccountState a = after.state();

        if (after.kind() == ChangeKind.DELETE) {
            if (cfg.isDeleted() && existedBefore) {
                reasons.add("ACCOUNT_DELETED");
            }
            return new Materiality(!reasons.isEmpty(), changeType, reasons);
        }
        if (!existedBefore) {
            if (cfg.isNewAccount()) {
                reasons.add("NEW_ACCOUNT");
            }
            if (cfg.isOverLimit() && a.overLimit()) {
                reasons.add("OVER_LIMIT_ENTERED");
            }
            return new Materiality(!reasons.isEmpty(), changeType, reasons);
        }

        AccountState b = before.state();
        if (cfg.isOverLimit() && !b.overLimit() && a.overLimit()) {
            reasons.add("OVER_LIMIT_ENTERED");
        }
        if (cfg.isOverLimit() && b.overLimit() && !a.overLimit()) {
            reasons.add("OVER_LIMIT_CLEARED");
        }
        if (cfg.isLimitChange() && !sameAmount(b.limit(), a.limit())) {
            reasons.add("LIMIT_CHANGED");
        }
        for (BigDecimal t : cfg.getUtilisationThresholds()) {
            if (crossed(b.utilisation(), a.utilisation(), t)) {
                reasons.add("UTILISATION_CROSSED_" + t.movePointRight(2).stripTrailingZeros().toPlainString() + "PCT");
            }
        }
        if (cfg.isForbearanceChange() && (!Objects.equals(b.forbearanceStart(), a.forbearanceStart())
                || !Objects.equals(b.forbearanceEnd(), a.forbearanceEnd()))) {
            reasons.add("FORBEARANCE_CHANGED");
        }
        if (cfg.isStatusChange() && !Objects.equals(b.status(), a.status())) {
            reasons.add("STATUS_CHANGED");
        }
        if (cfg.isCollateralChange() && !Objects.equals(b.collateralIds(), a.collateralIds())) {
            reasons.add("COLLATERAL_LINKS_CHANGED");
        }
        if (cfg.isCustomerChange() && !Objects.equals(b.customerId(), a.customerId())) {
            reasons.add("CUSTOMER_LINK_CHANGED");
        }
        return new Materiality(!reasons.isEmpty(), changeType, reasons);
    }

    public String version() {
        return cfg.getVersion();
    }

    private static boolean sameAmount(BigDecimal x, BigDecimal y) {
        return x == null ? y == null : y != null && x.compareTo(y) == 0;
    }

    /** True if utilisation moved from one side of the threshold to the other (either direction). */
    private static boolean crossed(BigDecimal before, BigDecimal after, BigDecimal threshold) {
        if (before == null || after == null) {
            return false;
        }
        return (before.compareTo(threshold) < 0) != (after.compareTo(threshold) < 0);
    }
}
