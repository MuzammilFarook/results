package ie.aib.ioc.account;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.TopicHandler.AppliedChange;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 * Repository: Tier 1 account state. Batched reads and writes — one round trip per batch, not per event.
 */
@Repository
public class AccountRepository {

    private final NamedParameterJdbcTemplate jdbc;
    private final Clock clock;

    public AccountRepository(NamedParameterJdbcTemplate jdbc, Clock clock) {
        this.jdbc = jdbc;
        this.clock = clock;
    }

    /**
     * Current state for these accounts, LOCKED until the transaction ends. HOLDLOCK also locks the
     * key range of accounts that don't exist yet, so a replay and the live consumer can't both
     * "create" the same account.
     */
    public Map<String, CurrentState<AccountState>> lockAndLoad(Collection<String> keys) {
        Map<String, CurrentState<AccountState>> out = new HashMap<>();
        for (List<String> chunk : Db.chunks(keys, Db.MAX_IN_LIST)) {
            jdbc.query("""
                    SELECT account_key, source_account_number, source_accounting_system, source_customer_id, currency,
                        account_limit, account_balance, account_status, facility_repayment_type, collateral_ids,
                        forbearance_start_date, forbearance_end_date, is_deleted, source_version, state_hash
                    FROM t1_account WITH (UPDLOCK, HOLDLOCK, ROWLOCK)
                    WHERE account_key IN (:keys)
                    """, new MapSqlParameterSource("keys", chunk), rs -> {
                out.put(rs.getString("account_key"), new CurrentState<>(rs.getLong("source_version"),
                        rs.getBytes("state_hash"), rs.getBoolean("is_deleted"), map(rs)));
            });
        }
        return out;
    }

    public void apply(List<AppliedChange<AccountState>> changes, java.util.function.Function<DecodedEvent<AccountState>, byte[]> hasher) {
        Instant now = clock.instant();
        List<SqlParameterSource> inserts = new ArrayList<>();
        List<SqlParameterSource> updates = new ArrayList<>();
        for (AppliedChange<AccountState> c : changes) {
            (c.isNew() ? inserts : updates).add(params(c, hasher.apply(c.event()), now));
        }
        if (!inserts.isEmpty()) {
            jdbc.batchUpdate("""
                    INSERT INTO t1_account (account_key, source_account_number, source_accounting_system, source_customer_id,
                        currency, account_limit, account_balance, account_status, facility_repayment_type, collateral_ids,
                        forbearance_start_date, forbearance_end_date, over_limit, is_deleted, source_version, state_hash,
                        source_system, source_event_id, source_occurred_at, source_topic, source_partition, source_offset,
                        trace_id, created_at, updated_at)
                    VALUES (:key, :number, :system, :customer, :currency, :limit, :balance, :status, :repayment, :collateral,
                        :fstart, :fend, :overLimit, :deleted, :version, :hash, :sourceSystem, :eventId, :occurred, :topic,
                        :partition, :offset, :trace, :now, :now)
                    """, inserts.toArray(SqlParameterSource[]::new));
        }
        if (!updates.isEmpty()) {
            jdbc.batchUpdate("""
                    UPDATE t1_account SET source_account_number = :number, source_accounting_system = :system,
                        source_customer_id = :customer, currency = :currency, account_limit = :limit,
                        account_balance = :balance, account_status = :status, facility_repayment_type = :repayment,
                        collateral_ids = :collateral, forbearance_start_date = :fstart, forbearance_end_date = :fend,
                        over_limit = :overLimit, is_deleted = :deleted, source_version = :version, state_hash = :hash,
                        source_system = :sourceSystem, source_event_id = :eventId, source_occurred_at = :occurred,
                        source_topic = :topic, source_partition = :partition, source_offset = :offset, trace_id = :trace,
                        updated_at = :now
                    WHERE account_key = :key AND source_version <= :version
                    """, updates.toArray(SqlParameterSource[]::new));
        }
    }

    private static SqlParameterSource params(AppliedChange<AccountState> c, byte[] hash, Instant now) {
        DecodedEvent<AccountState> e = c.event();
        AccountState s = e.state();
        return new MapSqlParameterSource()
                .addValue("key", e.entityKey()).addValue("number", s.accountNumber()).addValue("system", s.accountingSystem())
                .addValue("customer", s.customerId()).addValue("currency", s.currency()).addValue("limit", s.limit())
                .addValue("balance", s.balance()).addValue("status", s.status()).addValue("repayment", s.repaymentType())
                .addValue("collateral", s.collateralIds().isEmpty() ? null : String.join(",", s.collateralIds()))
                .addValue("fstart", s.forbearanceStart()).addValue("fend", s.forbearanceEnd())
                .addValue("overLimit", s.overLimit()).addValue("deleted", e.kind() == ChangeKind.DELETE)
                .addValue("version", e.sourceVersion()).addValue("hash", hash).addValue("sourceSystem", e.sourceSystem())
                .addValue("eventId", e.eventId()).addValue("occurred", Db.utc(e.occurredAt() == null ? now : e.occurredAt()))
                .addValue("topic", c.record().topic()).addValue("partition", c.record().partition())
                .addValue("offset", c.record().offset()).addValue("trace", c.traceId()).addValue("now", Db.utc(now));
    }

    private static AccountState map(ResultSet rs) throws SQLException {
        String collateral = rs.getString("collateral_ids");
        return new AccountState(rs.getString("account_key"), rs.getString("source_account_number"),
                rs.getString("source_accounting_system"), rs.getString("source_customer_id"), rs.getString("currency"),
                rs.getBigDecimal("account_limit"), rs.getBigDecimal("account_balance"), rs.getString("account_status"),
                rs.getString("facility_repayment_type"),
                collateral == null || collateral.isEmpty() ? List.of() : Arrays.asList(collateral.split(",")),
                rs.getObject("forbearance_start_date", LocalDate.class), rs.getObject("forbearance_end_date", LocalDate.class));
    }
}
