package ie.aib.ioc.account.domain;

import java.math.BigDecimal;
import java.math.MathContext;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

/**
 * IOC's own, stable model of an account. Source schema changes stop at the mapper; this does not change.
 *
 * <p>ASSUMPTION (to confirm with the Account Domain): {@code balance} is the credit utilised /
 * outstanding as a magnitude; sign conventions vary by accounting system, so utilisation uses |balance|.
 */
public record AccountState(
        String accountKey,
        String accountNumber,
        String accountingSystem,
        String customerId,
        String currency,
        BigDecimal limit,
        BigDecimal balance,
        String status,
        String repaymentType,
        List<String> collateralIds,
        LocalDate forbearanceStart,
        LocalDate forbearanceEnd) {

    public static String key(String accountingSystem, String accountNumber) {
        return accountingSystem.trim().toUpperCase(Locale.ROOT) + ":" + accountNumber.trim();
    }

    /** Drawn beyond the approved limit. No limit ⇒ never "over limit". */
    public boolean overLimit() {
        return limit != null && balance != null && balance.abs().compareTo(limit) > 0;
    }

    /** |balance| / limit, or null when there is no meaningful limit. */
    public BigDecimal utilisation() {
        if (limit == null || balance == null || limit.signum() <= 0) {
            return null;
        }
        return balance.abs().divide(limit, MathContext.DECIMAL64);
    }
}
