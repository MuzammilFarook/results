package ie.aib.ioc.account;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

import ie.aib.account.events.v1.AccountEvent;
import ie.aib.account.events.v1.AccountSnapshot;
import ie.aib.account.events.v1.ChangeType;
import ie.aib.account.events.v1.EventHeader;
import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.DecodedEvent;
import org.springframework.stereotype.Component;

/**
 * Mapper: Avro → IOC model. The only class that knows the source schema's shape.
 *
 * <pre>
 *   Avro generated class ──► Mapper ──► AccountState ──► Repository
 *        (changes)          (changes)    (stable)         (stable)
 * </pre>
 * A compatible schema change (e.g. the Account Domain adds {@code nextReviewDate} with a default)
 * touches only this class — or nothing at all, if IOC doesn't need the new field.
 */
@Component
public class AccountEventMapper {

    public DecodedEvent<AccountState> decode(AccountEvent event) {
        EventHeader h = Objects.requireNonNull(event.getHeader(), "header");
        AccountSnapshot a = Objects.requireNonNull(event.getAccount(), "account");
        String system = trim(a.getSourceAccountingSystem());
        String number = trim(a.getSourceAccountNumber());
        String key = system == null || number == null || system.isEmpty() || number.isEmpty()
                ? null : AccountState.key(system, number);
        List<String> collateral = a.getCollateralIds() == null ? List.of() : a.getCollateralIds().stream()
                .map(AccountEventMapper::trim).filter(s -> s != null && !s.isEmpty()).distinct().sorted().toList();

        AccountState state = new AccountState(
                key,
                number,
                system == null ? null : system.toUpperCase(Locale.ROOT),
                blankToNull(a.getSourceCustomerId()),
                a.getCurrency() == null ? null : a.getCurrency().trim().toUpperCase(Locale.ROOT),
                a.getAccountLimit(),
                a.getAccountBalance(),
                blankToNull(a.getAccountStatus()),
                blankToNull(a.getFacilityRepaymentType()),
                collateral,
                a.getForbearanceStartDate(),
                a.getForbearanceEndDate());

        return new DecodedEvent<>(
                trim(h.getEventId()),
                key,
                h.getEventType() == ChangeType.DELETED ? ChangeKind.DELETE : ChangeKind.UPSERT,
                h.getSourceVersion(),
                h.getOccurredAt(),
                trim(h.getSourceSystem()),
                blankToNull(h.getTraceId()),
                state);
    }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
