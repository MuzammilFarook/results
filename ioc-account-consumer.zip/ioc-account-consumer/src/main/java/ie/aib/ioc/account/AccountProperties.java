package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import ie.aib.ioc.platform.core.EvidenceLevel;
import org.springframework.boot.context.properties.ConfigurationProperties;

/** {@code ioc.account.*} */
@ConfigurationProperties(prefix = "ioc.account")
public class AccountProperties {

    /** Listener id, ledger scope, ops console name. */
    private String consumerName = "account-consumer";
    /** PLACEHOLDER until the Account Domain confirms the topic name. */
    private String topic = "credit.account.v1";
    /** ~20M events/day → keep a fingerprint in the ledger, not the payload (≈7 TB/yr otherwise). */
    private EvidenceLevel evidenceLevel = EvidenceLevel.METADATA;
    /** Empty = every accounting system is in scope. Otherwise others are FILTERED (valid, not needed). */
    private Set<String> inScopeAccountingSystems = new LinkedHashSet<>();
    private final MaterialityRule materiality = new MaterialityRule();

    /**
     * "Does this change matter?" — DRAFT. This must be written down and agreed by the business,
     * not invented by developers. Every switch is here so the agreed rule is configuration, and its
     * version is stamped on every Credit Change event.
     */
    public static class MaterialityRule {
        private String version = "ACC-MAT-0.1-DRAFT";
        private boolean newAccount = true;
        private boolean deleted = true;
        private boolean overLimit = true;
        private boolean limitChange = true;
        private List<BigDecimal> utilisationThresholds = new ArrayList<>(List.of(new BigDecimal("0.90")));
        private boolean forbearanceChange = true;
        private boolean statusChange = true;
        private boolean collateralChange = true;
        private boolean customerChange = true;

        public String getVersion() { return version; }
        public void setVersion(String version) { this.version = version; }
        public boolean isNewAccount() { return newAccount; }
        public void setNewAccount(boolean newAccount) { this.newAccount = newAccount; }
        public boolean isDeleted() { return deleted; }
        public void setDeleted(boolean deleted) { this.deleted = deleted; }
        public boolean isOverLimit() { return overLimit; }
        public void setOverLimit(boolean overLimit) { this.overLimit = overLimit; }
        public boolean isLimitChange() { return limitChange; }
        public void setLimitChange(boolean limitChange) { this.limitChange = limitChange; }
        public List<BigDecimal> getUtilisationThresholds() { return utilisationThresholds; }
        public void setUtilisationThresholds(List<BigDecimal> utilisationThresholds) { this.utilisationThresholds = utilisationThresholds; }
        public boolean isForbearanceChange() { return forbearanceChange; }
        public void setForbearanceChange(boolean forbearanceChange) { this.forbearanceChange = forbearanceChange; }
        public boolean isStatusChange() { return statusChange; }
        public void setStatusChange(boolean statusChange) { this.statusChange = statusChange; }
        public boolean isCollateralChange() { return collateralChange; }
        public void setCollateralChange(boolean collateralChange) { this.collateralChange = collateralChange; }
        public boolean isCustomerChange() { return customerChange; }
        public void setCustomerChange(boolean customerChange) { this.customerChange = customerChange; }
    }

    public String getConsumerName() { return consumerName; }
    public void setConsumerName(String consumerName) { this.consumerName = consumerName; }
    public String getTopic() { return topic; }
    public void setTopic(String topic) { this.topic = topic; }
    public EvidenceLevel getEvidenceLevel() { return evidenceLevel; }
    public void setEvidenceLevel(EvidenceLevel evidenceLevel) { this.evidenceLevel = evidenceLevel; }
    public Set<String> getInScopeAccountingSystems() { return inScopeAccountingSystems; }
    public void setInScopeAccountingSystems(Set<String> s) { this.inScopeAccountingSystems = s; }
    public MaterialityRule getMateriality() { return materiality; }
}
