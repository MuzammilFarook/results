-- =====================================================================================
-- Tier 1 Account — latest known state per account, as published by the Account Domain.
-- source_version + state_hash power the version guard ("only apply if newer").
-- Deletes are soft (is_deleted) so a late, older UPDATE can never resurrect the account.
-- =====================================================================================
CREATE TABLE t1_account (
    account_key              VARCHAR(255)   NOT NULL CONSTRAINT pk_t1_account PRIMARY KEY, -- {accountingSystem}:{accountNumber}
    source_account_number    VARCHAR(64)    NOT NULL,
    source_accounting_system VARCHAR(64)    NOT NULL,
    source_customer_id       VARCHAR(64)    NULL,
    currency                 CHAR(3)        NOT NULL,
    account_limit            DECIMAL(18,2)  NULL,
    account_balance          DECIMAL(18,2)  NOT NULL,
    account_status           VARCHAR(40)    NULL,
    facility_repayment_type  VARCHAR(60)    NULL,
    collateral_ids           VARCHAR(2000)  NULL,      -- sorted, comma separated
    forbearance_start_date   DATE           NULL,
    forbearance_end_date     DATE           NULL,
    over_limit               BIT            NOT NULL,
    is_deleted               BIT            NOT NULL CONSTRAINT df_t1_account_deleted DEFAULT 0,
    source_version           BIGINT         NOT NULL,
    state_hash               BINARY(32)     NOT NULL,
    source_system            VARCHAR(64)    NOT NULL,
    source_event_id          VARCHAR(100)   NOT NULL,
    source_occurred_at       DATETIME2(3)   NOT NULL,
    -- lineage: exactly which Kafka record produced this row
    source_topic             VARCHAR(249)   NOT NULL,
    source_partition         INT            NOT NULL,
    source_offset            BIGINT         NOT NULL,
    trace_id                 VARCHAR(64)    NOT NULL,
    created_at               DATETIME2(3)   NOT NULL,
    updated_at               DATETIME2(3)   NOT NULL
);
CREATE INDEX ix_t1_account_customer ON t1_account (source_customer_id);
