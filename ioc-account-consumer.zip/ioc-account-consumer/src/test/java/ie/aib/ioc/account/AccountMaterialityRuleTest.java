package ie.aib.ioc.account;

import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.Materiality;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;
import org.junit.jupiter.api.Test;

import static ie.aib.ioc.account.AccountEvents.asDelete;
import static ie.aib.ioc.account.AccountEvents.decoded;
import static org.assertj.core.api.Assertions.assertThat;

/** "Only about 1 in 100 account changes matters to credit." */
class AccountMaterialityRuleTest {

    private final AccountMaterialityRule rule = new AccountMaterialityRule(new AccountProperties());

    private static CurrentState<AccountState> stored(String limit, String balance) {
        return new CurrentState<>(10, new byte[32], false, decoded(10, limit, balance).state());
    }

    @Test
    void balanceMovementInsideTheLimitIsNotAnnounced() {
        Materiality m = rule.assess(stored("250000.00", "120000.00"), decoded(11, "250000.00", "121500.00"));
        assertThat(m.material()).isFalse();
        assertThat(m.changeType()).isEqualTo("ACCOUNT_TIER1_UPDATED");
    }

    @Test
    void goingOverTheLimitIsAnnounced() {
        Materiality m = rule.assess(stored("250000.00", "240000.00"), decoded(11, "250000.00", "251000.00"));
        assertThat(m.material()).isTrue();
        assertThat(m.reasons()).contains("OVER_LIMIT_ENTERED");
    }

    @Test
    void comingBackUnderTheLimitIsAnnounced() {
        Materiality m = rule.assess(stored("250000.00", "251000.00"), decoded(11, "250000.00", "200000.00"));
        assertThat(m.reasons()).contains("OVER_LIMIT_CLEARED");
    }

    @Test
    void crossingNinetyPercentUtilisationIsAnnounced() {
        Materiality m = rule.assess(stored("100000.00", "89000.00"), decoded(11, "100000.00", "91000.00"));
        assertThat(m.reasons()).containsExactly("UTILISATION_CROSSED_90PCT");
    }

    @Test
    void limitChangeIsAnnounced() {
        assertThat(rule.assess(stored("100000.00", "50000.00"), decoded(11, "150000.00", "50000.00")).reasons())
                .containsExactly("LIMIT_CHANGED");
    }

    @Test
    void sameLimitWithDifferentScaleIsNotAChange() {
        assertThat(rule.assess(stored("100000.00", "50000.00"), decoded(11, "100000.0", "50000.00")).material()).isFalse();
    }

    @Test
    void newAndDeletedAccountsAreAnnounced() {
        DecodedEvent<AccountState> e = decoded(1, "100000.00", "50000.00");
        assertThat(rule.assess(null, e).reasons()).containsExactly("NEW_ACCOUNT");
        assertThat(rule.assess(null, e).changeType()).isEqualTo("ACCOUNT_TIER1_CREATED");
        Materiality del = rule.assess(stored("100000.00", "50000.00"), asDelete(decoded(12, "100000.00", "50000.00")));
        assertThat(del.reasons()).containsExactly("ACCOUNT_DELETED");
        assertThat(del.changeType()).isEqualTo("ACCOUNT_TIER1_DELETED");
    }
}
