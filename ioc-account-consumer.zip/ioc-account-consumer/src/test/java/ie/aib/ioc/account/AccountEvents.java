package ie.aib.ioc.account;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import ie.aib.account.events.v1.AccountEvent;
import ie.aib.account.events.v1.AccountSnapshot;
import ie.aib.account.events.v1.ChangeType;
import ie.aib.account.events.v1.EventHeader;
import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.ChangeKind;
import ie.aib.ioc.platform.core.DecodedEvent;

/** Test data builders. */
final class AccountEvents {

    private AccountEvents() {
    }

    static AccountEvent avro(String number, long version, String limit, String balance) {
        return AccountEvent.newBuilder()
                .setHeader(EventHeader.newBuilder().setEventId(UUID.randomUUID().toString()).setEventType(ChangeType.UPDATED)
                        .setSourceSystem("TRANSACT").setSourceVersion(version).setOccurredAt(Instant.now()).setTraceId(null).build())
                .setAccount(AccountSnapshot.newBuilder().setSourceAccountNumber(number).setSourceAccountingSystem("TRANSACT")
                        .setSourceCustomerId("CIF482913").setCurrency("EUR")
                        .setAccountLimit(limit == null ? null : new BigDecimal(limit))
                        .setAccountBalance(new BigDecimal(balance)).setAccountStatus("ACTIVE").setFacilityRepaymentType(null)
                        .setCollateralIds(List.of("SIN58213")).setForbearanceStartDate(null).setForbearanceEndDate(null).build())
                .build();
    }

    static DecodedEvent<AccountState> decoded(long version, String limit, String balance) {
        return new AccountEventMapper().decode(avro("IE00412345", version, limit, balance));
    }

    static DecodedEvent<AccountState> withState(DecodedEvent<AccountState> e, AccountState s) {
        return new DecodedEvent<>(e.eventId(), e.entityKey(), e.kind(), e.sourceVersion(), e.occurredAt(), e.sourceSystem(),
                e.producerTraceId(), s);
    }

    static DecodedEvent<AccountState> asDelete(DecodedEvent<AccountState> e) {
        return new DecodedEvent<>(e.eventId(), e.entityKey(), ChangeKind.DELETE, e.sourceVersion(), e.occurredAt(),
                e.sourceSystem(), e.producerTraceId(), e.state());
    }
}
