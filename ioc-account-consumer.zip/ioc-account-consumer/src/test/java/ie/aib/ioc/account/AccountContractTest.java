package ie.aib.ioc.account;

import java.time.Clock;
import java.util.Arrays;

import ie.aib.account.events.v1.AccountEvent;
import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.ValidationException;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Mapper, validator and content fingerprint — the parts that decide DUPLICATE vs CONFLICT. */
class AccountContractTest {

    private final AccountEventMapper mapper = new AccountEventMapper();
    private final AccountEventValidator validator = new AccountEventValidator(Clock.systemUTC());
    private final AccountTopicHandler handler = new AccountTopicHandler(new AccountProperties(), mapper, validator, null,
            new AccountMaterialityRule(new AccountProperties()));

    @Test
    void mapsToAStableKeyAndFullState() {
        DecodedEvent<AccountState> e = mapper.decode(AccountEvents.avro(" IE00412345 ", 7, "250000.00", "120000.00"));
        assertThat(e.entityKey()).isEqualTo("TRANSACT:IE00412345");
        assertThat(e.sourceVersion()).isEqualTo(7);
        assertThat(e.state().collateralIds()).containsExactly("SIN58213");
        assertThat(e.state().overLimit()).isFalse();
    }

    @Test
    void validEventPasses() {
        validator.validate(AccountEvents.decoded(7, "250000.00", "120000.00"));
    }

    @Test
    void contractBreachListsEveryProblem() {
        AccountEvent bad = AccountEvents.avro("IE00412345", 7, "-1.00", "120000.00");
        bad.getAccount().setCurrency("EURO");
        assertThatThrownBy(() -> validator.validate(mapper.decode(bad)))
                .isInstanceOf(ValidationException.class)
                .hasMessageContaining("currency")
                .hasMessageContaining("accountLimit is negative");
    }

    @Test
    void sameContentUnderANewEventIdHasTheSameFingerprint() {
        byte[] a = handler.stateHash(AccountEvents.decoded(7, "250000.00", "120000.00"));
        byte[] b = handler.stateHash(AccountEvents.decoded(7, "250000.00", "120000.00"));
        assertThat(Arrays.equals(a, b)).as("republish with a new eventId → DUPLICATE").isTrue();
    }

    @Test
    void differentContentHasADifferentFingerprint() {
        byte[] a = handler.stateHash(AccountEvents.decoded(7, "250000.00", "120000.00"));
        byte[] b = handler.stateHash(AccountEvents.decoded(7, "250000.00", "120999.00"));
        assertThat(Arrays.equals(a, b)).as("same version, different content → CONFLICT").isFalse();
    }
}
