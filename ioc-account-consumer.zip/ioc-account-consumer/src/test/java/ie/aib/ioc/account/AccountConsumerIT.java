package ie.aib.ioc.account;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.github.dockerjava.api.DockerClient;
import ie.aib.account.events.v1.AccountEvent;
import ie.aib.account.events.v1.EventHeader;
import ie.aib.ioc.account.domain.AccountState;
import ie.aib.ioc.events.v1.CreditChangeEvent;
import ie.aib.ioc.platform.core.DecodedEvent;
import ie.aib.ioc.platform.core.DependencyMissingException;
import ie.aib.ioc.platform.ops.OpsException;
import ie.aib.ioc.platform.replay.ReplayModels.ReplayRequestView;
import ie.aib.ioc.platform.replay.ReplayModels.SingleReplayResult;
import ie.aib.ioc.platform.replay.ReplayService;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.DockerClientFactory;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.containers.MSSQLServerContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.awaitility.Awaitility.await;

/**
 * "Bulletproof has to be tested, not promised." One test per rule in section 12 of the design.
 * Real Kafka and real SQL Server (Testcontainers); Schema Registry is Confluent's in-JVM mock.
 *
 * <pre>
 *   Rule                                 Test
 *   Duplicates are harmless              duplicatesAreHarmless
 *   Every letter is accounted for        everyRecordHasExactlyOneLedgerLineAndOffsetsHaveNoHoles
 *   Bad letters don't block the belt     corruptBytesGoToTheTrayAndTheNextRecordIsProcessed
 *   Contract breach waits for a person   contractBreachWaitsForAPerson
 *   Database outage                      databaseOutagePausesTheConsumerAndNothingGoesToTheTray
 *   Replay is safe                       replayCanNeverOverwriteNewerData
 *   Announcements (evidence + trace)     materialChangeIsAnnouncedWithEvidenceAndTheSameTraceId
 *   Four-eyes                            bulkReplayNeedsASecondPerson
 * </pre>
 * Crash-between-commit-and-ack is covered by design (commit-after-transaction + redelivery skip) and by
 * the duplicates test; schema evolution is enforced by the Schema Registry compatibility check in CI;
 * 10× load is a separate performance run (see README).
 */
@SpringBootTest(properties = {
        "ioc.account.topic=it.account.v1",
        "ioc.platform.outbox.topic=it.credit.change.v1",
        "spring.kafka.properties.schema.registry.url=mock://ioc-it",
        "spring.kafka.properties.auto.register.schemas=true",
        "spring.kafka.consumer.properties.group.instance.id=it-account",
        "spring.kafka.listener.concurrency=1",
        "ioc.platform.auto-replay.enabled=false",
        "ioc.platform.transient-retry.backoff=10ms,10ms,10ms",
        "ioc.platform.pause.max-backoff=2s",
        "ioc.platform.outbox.poll-interval-ms=200",
        "ioc.platform.outbox.lease-renew-ms=500",
        "ioc.platform.manual-replay.approval-threshold=0",
        "ioc.platform.gap-check.enabled=false",
        "ioc.ops.security.mode=local"
})
@Testcontainers
class AccountConsumerIT {

    static final String TOPIC = "it.account.v1";
    static final String CC_TOPIC = "it.credit.change.v1";
    static final String SR = "mock://ioc-it";

    @Container
    static final KafkaContainer KAFKA = new KafkaContainer(DockerImageName.parse("confluentinc/cp-kafka:7.6.1"));

    @Container
    static final MSSQLServerContainer<?> SQL = new MSSQLServerContainer<>(
            DockerImageName.parse("mcr.microsoft.com/mssql/server:2022-latest")).acceptLicense();

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.kafka.bootstrap-servers", KAFKA::getBootstrapServers);
        // socketTimeout: a frozen DB must surface as an error, not hang a thread forever (recommended in prod too)
        r.add("spring.datasource.url", () -> SQL.getJdbcUrl() + ";socketTimeout=8000");
        r.add("spring.datasource.username", SQL::getUsername);
        r.add("spring.datasource.password", SQL::getPassword);
    }

    static KafkaProducer<String, Object> avro;
    static KafkaProducer<String, byte[]> raw;

    @Autowired
    JdbcTemplate jdbc;
    @Autowired
    ReplayService replay;
    @Autowired
    ToggleValidator toggle;

    @BeforeAll
    static void producers() {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers());
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        cfg.put("schema.registry.url", SR);
        cfg.put("avro.use.logical.type.converters", true);
        avro = new KafkaProducer<>(cfg);
        Map<String, Object> rawCfg = new HashMap<>(cfg);
        rawCfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer.class);
        raw = new KafkaProducer<>(rawCfg);
    }

    @AfterAll
    static void close() {
        avro.close();
        raw.close();
    }

    // ===================================================================== rules

    @Test
    void duplicatesAreHarmless() throws Exception {
        String acc = account();
        AccountEvent v1 = AccountEvents.avro(acc, 1, "100000.00", "50000.00");
        send(v1);
        send(v1);                // Kafka/producer redelivery: same eventId
        send(v1);
        send(withNewEventId(v1)); // source re-sends the same news under a new id
        send(withNewEventId(v1));

        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(key(acc)).size() == 5);
        List<String> outcomes = ledgerOutcomes(key(acc));
        assertThat(outcomes).containsOnlyOnce("PROCESSED");
        assertThat(outcomes.stream().filter("DUPLICATE"::equals)).hasSize(4);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM t1_account WHERE account_key = ?", Integer.class, key(acc))).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT source_version FROM t1_account WHERE account_key = ?", Long.class, key(acc))).isEqualTo(1L);
    }

    @Test
    void everyRecordHasExactlyOneLedgerLineAndOffsetsHaveNoHoles() throws Exception {
        String prefix = "IT" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        int accounts = 20, versions = 10;
        for (int v = 1; v <= versions; v++) {
            for (int a = 0; a < accounts; a++) {
                send(AccountEvents.avro(prefix + a, v, "100000.00", (40000 + v * 100) + ".00"));
            }
        }
        await().atMost(Duration.ofSeconds(90)).until(() -> jdbc.queryForObject(
                "SELECT COUNT(*) FROM event_ledger WHERE entity_key LIKE ?", Integer.class, "TRANSACT:" + prefix + "%") == accounts * versions);

        // Every offset that reached the consumer has exactly one line: per partition, count == max - min + 1
        List<Map<String, Object>> parts = jdbc.queryForList("""
                SELECT kafka_partition, COUNT(*) AS n, MIN(kafka_offset) AS lo, MAX(kafka_offset) AS hi
                FROM event_ledger WHERE topic = ? GROUP BY kafka_partition""", TOPIC);
        for (Map<String, Object> p : parts) {
            long n = ((Number) p.get("n")).longValue();
            long span = ((Number) p.get("hi")).longValue() - ((Number) p.get("lo")).longValue() + 1;
            assertThat(n).as("partition %s has no holes", p.get("kafka_partition")).isEqualTo(span);
        }
        assertThat(jdbc.queryForObject("SELECT MAX(source_version) FROM t1_account WHERE account_key LIKE ?", Long.class,
                "TRANSACT:" + prefix + "%")).isEqualTo((long) versions);
    }

    @Test
    void corruptBytesGoToTheTrayAndTheNextRecordIsProcessed() throws Exception {
        String acc = account();
        RecordMetadata bad = raw.send(new ProducerRecord<>(TOPIC, key(acc), "not avro at all".getBytes(StandardCharsets.UTF_8))).get();
        send(AccountEvents.avro(acc, 1, "100000.00", "50000.00"));

        await().atMost(Duration.ofSeconds(60)).until(() -> ledgerOutcomes(key(acc)).contains("PROCESSED"));
        Map<String, Object> f = jdbc.queryForMap("SELECT error_category, status, DATALENGTH(payload) AS bytes FROM event_failure"
                + " WHERE topic = ? AND kafka_partition = ? AND kafka_offset = ?", TOPIC, bad.partition(), bad.offset());
        assertThat(f.get("error_category")).isEqualTo("DESERIALISATION");
        assertThat(f.get("status")).isEqualTo("MANUAL");
        assertThat(((Number) f.get("bytes")).intValue()).as("raw bytes kept for replay").isEqualTo(15);
        assertThat(jdbc.queryForObject("SELECT outcome FROM event_ledger WHERE topic = ? AND kafka_partition = ? AND kafka_offset = ?",
                String.class, TOPIC, bad.partition(), bad.offset())).isEqualTo("FAILED");
    }

    @Test
    void contractBreachWaitsForAPerson() throws Exception {
        String acc = account();
        AccountEvent bad = AccountEvents.avro(acc, 1, "-1.00", "50000.00");
        bad.getAccount().setCurrency("EURO");
        send(bad);
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(key(acc)) == 1);
        Map<String, Object> f = jdbc.queryForMap("SELECT error_category, status, next_attempt_at FROM event_failure WHERE entity_key = ?", key(acc));
        assertThat(f.get("error_category")).isEqualTo("VALIDATION");
        assertThat(f.get("status")).isEqualTo("MANUAL");
        assertThat(f.get("next_attempt_at")).isNull();
    }

    @Test
    void databaseOutagePausesTheConsumerAndNothingGoesToTheTray() throws Exception {
        String acc = account();
        DockerClient docker = DockerClientFactory.instance().client();
        docker.pauseContainerCmd(SQL.getContainerId()).exec();
        try {
            for (int v = 1; v <= 20; v++) {
                send(AccountEvents.avro(acc, v, "100000.00", (50000 + v) + ".00"));
            }
            Thread.sleep(15_000); // consumer hits the frozen DB, classifies it as PLATFORM, pauses and probes
        } finally {
            docker.unpauseContainerCmd(SQL.getContainerId()).exec();
        }
        await().atMost(Duration.ofSeconds(120)).until(() -> ledgerOutcomes(key(acc)).size() == 20);
        assertThat(failureCount(key(acc))).as("a broken system must not fill the failure tray").isZero();
        assertThat(jdbc.queryForObject("SELECT source_version FROM t1_account WHERE account_key = ?", Long.class, key(acc))).isEqualTo(20L);
    }

    @Test
    void replayCanNeverOverwriteNewerData() throws Exception {
        String acc = account();
        AccountEvent v5 = AccountEvents.avro(acc, 5, "100000.00", "55555.00");
        toggle.failEventIds.add(v5.getHeader().getEventId());
        send(v5);
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(key(acc)) == 1);
        assertThat(jdbc.queryForObject("SELECT status FROM event_failure WHERE entity_key = ?", String.class, key(acc))).isEqualTo("AUTO_RETRY");

        send(AccountEvents.avro(acc, 6, "100000.00", "66666.00"));
        await().atMost(Duration.ofSeconds(60)).until(() -> versionOf(key(acc)) == 6L);

        toggle.failEventIds.clear(); // "the bug is fixed"
        long failureId = jdbc.queryForObject("SELECT failure_id FROM event_failure WHERE entity_key = ?", Long.class, key(acc));
        SingleReplayResult r = replay.replayFailure(failureId, "it-operator", "127.0.0.1");

        assertThat(r.result()).isEqualTo("SUCCEEDED");
        assertThat(r.outcome()).as("v5 is older than stored v6").isEqualTo("STALE");
        assertThat(versionOf(key(acc))).isEqualTo(6L);
        assertThat(jdbc.queryForObject("SELECT account_balance FROM t1_account WHERE account_key = ?", String.class, key(acc))).startsWith("66666");
        assertThat(jdbc.queryForObject("SELECT status FROM event_failure WHERE failure_id = ?", String.class, failureId)).isEqualTo("REPLAYED");
        assertThat(jdbc.queryForList("""
                SELECT t.to_outcome FROM event_ledger_transition t JOIN event_ledger l ON l.ledger_id = t.ledger_id
                WHERE l.entity_key = ? AND l.source_version = 5""", String.class, key(acc))).containsExactly("REPLAYED");
    }

    @Test
    void materialChangeIsAnnouncedWithEvidenceAndTheSameTraceId() throws Exception {
        String acc = account();
        send(AccountEvents.avro(acc, 1, "100000.00", "90000.00"));   // NEW_ACCOUNT
        send(AccountEvents.avro(acc, 2, "100000.00", "90500.00"));   // inside the limit: saved, not announced
        send(AccountEvents.avro(acc, 3, "100000.00", "101000.00"));  // OVER_LIMIT_ENTERED

        await().atMost(Duration.ofSeconds(60)).until(() -> jdbc.queryForObject(
                "SELECT COUNT(*) FROM outbox WHERE aggregate_key = ? AND status = 'SENT' AND sent_offset IS NOT NULL", Integer.class, key(acc)) == 2);
        assertThat(jdbc.queryForList("SELECT reasons FROM outbox WHERE aggregate_key = ? ORDER BY outbox_id", String.class, key(acc)))
                .containsExactly("NEW_ACCOUNT", "OVER_LIMIT_ENTERED");
        String trace = jdbc.queryForObject("SELECT trace_id FROM event_ledger WHERE entity_key = ? AND source_version = 3", String.class, key(acc));

        try (KafkaConsumer<String, Object> c = ccConsumer()) {
            c.subscribe(List.of(CC_TOPIC));
            ConsumerRecord<String, Object> found = null;
            long deadline = System.currentTimeMillis() + 30_000;
            while (found == null && System.currentTimeMillis() < deadline) {
                for (ConsumerRecord<String, Object> rec : c.poll(Duration.ofMillis(500))) {
                    CreditChangeEvent e = (CreditChangeEvent) rec.value();
                    if (e.getEntityKey().equals(key(acc)) && e.getReasons().contains("OVER_LIMIT_ENTERED")) {
                        found = rec;
                    }
                }
            }
            assertThat(found).isNotNull();
            assertThat(new String(found.headers().lastHeader("ioc-trace-id").value(), StandardCharsets.UTF_8)).isEqualTo(trace);
            assertThat(((CreditChangeEvent) found.value()).getEntityVersion()).isEqualTo(3L);
        }
    }

    @Test
    void bulkReplayNeedsASecondPerson() throws Exception {
        String acc = account();
        AccountEvent bad = AccountEvents.avro(acc, 1, "100000.00", "50000.00");
        bad.getAccount().setCurrency("XX");
        send(bad);
        await().atMost(Duration.ofSeconds(60)).until(() -> failureCount(key(acc)) == 1);

        ReplayRequestView req = replay.createRequest("account-consumer", "FAILURES", Map.of("entityKey", key(acc)),
                "currency mapping fixed", "alice", "127.0.0.1");
        assertThat(req.status()).isEqualTo("PENDING_APPROVAL");
        assertThatThrownBy(() -> replay.decide(req.requestId(), true, "alice", "self", "127.0.0.1"))
                .isInstanceOf(OpsException.class)
                .satisfies(e -> assertThat(((OpsException) e).status()).isEqualTo(HttpStatus.FORBIDDEN));
        assertThat(replay.decide(req.requestId(), true, "bob", "checked", "127.0.0.1").status()).isEqualTo("APPROVED");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM ops_audit WHERE target = ?", Integer.class,
                "replay-request:" + req.requestId())).isGreaterThanOrEqualTo(3);
    }

    // ===================================================================== helpers

    private static String account() {
        return "IT" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    private static String key(String account) {
        return "TRANSACT:" + account;
    }

    private static void send(AccountEvent e) throws Exception {
        avro.send(new ProducerRecord<>(TOPIC, key(e.getAccount().getSourceAccountNumber()), e)).get();
    }

    private static AccountEvent withNewEventId(AccountEvent e) {
        return AccountEvent.newBuilder(e)
                .setHeader(EventHeader.newBuilder(e.getHeader()).setEventId(UUID.randomUUID().toString()).build())
                .build();
    }

    private List<String> ledgerOutcomes(String key) {
        return jdbc.queryForList("SELECT outcome FROM event_ledger WHERE entity_key = ? ORDER BY kafka_offset", String.class, key);
    }

    private int failureCount(String key) {
        Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM event_failure WHERE entity_key = ?", Integer.class, key);
        return n == null ? 0 : n;
    }

    private Long versionOf(String key) {
        List<Long> v = jdbc.queryForList("SELECT source_version FROM t1_account WHERE account_key = ?", Long.class, key);
        return v.isEmpty() ? -1L : v.get(0);
    }

    private static KafkaConsumer<String, Object> ccConsumer() {
        Map<String, Object> cfg = new HashMap<>();
        cfg.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers());
        cfg.put(ConsumerConfig.GROUP_ID_CONFIG, "it-verify-" + UUID.randomUUID());
        cfg.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        cfg.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        cfg.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);
        cfg.put("schema.registry.url", SR);
        cfg.put("specific.avro.reader", true);
        return new KafkaConsumer<>(cfg);
    }

    /** Lets a test make specific events fail with a retryable error, then "fix the bug". */
    static class ToggleValidator extends AccountEventValidator {
        final Set<String> failEventIds = ConcurrentHashMap.newKeySet();

        ToggleValidator(Clock clock) {
            super(clock);
        }

        @Override
        public void validate(DecodedEvent<AccountState> e) {
            if (failEventIds.contains(e.eventId())) {
                throw new DependencyMissingException("Simulated: something this event needs has not arrived yet");
            }
            super.validate(e);
        }
    }

    @TestConfiguration
    static class Config {
        @Bean
        @Primary
        ToggleValidator toggleValidator(Clock clock) {
            return new ToggleValidator(clock);
        }
    }
}
