package ie.aib.ioc.platform.core;

/**
 * The SYSTEM is broken (database down, Schema Registry unreachable, sustained throttling) —
 * not the record. The consumer must stop and wait, NOT drain good records into the failure tray.
 *
 * <p>{@link #committedUpTo()} is the index in the current batch up to which work was already
 * committed (bisect commits left halves first), so only the rest is redelivered.
 */
public class PlatformUnavailableException extends RuntimeException {

    private final int committedUpTo;

    public PlatformUnavailableException(String message, Throwable cause) {
        this(message, cause, 0);
    }

    public PlatformUnavailableException(String message, Throwable cause, int committedUpTo) {
        super(message, cause);
        this.committedUpTo = committedUpTo;
    }

    public int committedUpTo() {
        return committedUpTo;
    }

    public PlatformUnavailableException withCommittedUpTo(int index) {
        return new PlatformUnavailableException(getMessage(), getCause(), index);
    }
}
