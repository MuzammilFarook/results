package ie.aib.ioc.platform.core;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** What happened to a batch (or a slice of one) — counts plus the notable individual events. */
public final class BatchResult {

    private final Map<Outcome, Long> counts = new EnumMap<>(Outcome.class);
    private long redelivered;
    private long material;
    private long consumed;
    private long retried;
    private final List<FailureNotice> failures = new ArrayList<>();
    private final List<ReplayNotice> replays = new ArrayList<>();

    public void count(Outcome outcome) {
        counts.merge(outcome, 1L, Long::sum);
    }

    public void markRedelivered() { redelivered++; }
    public void markMaterial() { material++; }
    public void consumed(long n) { consumed += n; }
    public void retried(long n) { retried += n; }
    public void failure(FailureNotice n) { failures.add(n); }
    public void replay(ReplayNotice n) { replays.add(n); }

    public void merge(BatchResult other) {
        other.counts.forEach((k, v) -> counts.merge(k, v, Long::sum));
        redelivered += other.redelivered;
        material += other.material;
        consumed += other.consumed;
        retried += other.retried;
        failures.addAll(other.failures);
        replays.addAll(other.replays);
    }

    public long get(Outcome o) { return counts.getOrDefault(o, 0L); }
    public Map<Outcome, Long> counts() { return counts; }
    public long redelivered() { return redelivered; }
    public long material() { return material; }
    public long consumed() { return consumed; }
    public long retried() { return retried; }
    public List<FailureNotice> failures() { return failures; }
    public List<ReplayNotice> replays() { return replays; }

    /** A record that (still) failed — for the per-failure Splunk line and the replay API response. */
    public record FailureNotice(String topic, int partition, long offset, String eventId, String entityKey,
                                String traceId, FailureCategory category, String errorClass, String message,
                                long failureId, int attempt, String nextStatus) {
    }

    /** A previously failed record that has now been handled. */
    public record ReplayNotice(String topic, int partition, long offset, String eventId, String entityKey,
                               String traceId, Outcome result, String detail, Long failureId) {
    }
}
