package ie.aib.ioc.platform.replay;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.BatchResult;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.InboundRecord;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.core.PlatformUnavailableException;
import ie.aib.ioc.platform.core.ReplayContext;
import ie.aib.ioc.platform.failure.FailureModels.FailureFilter;
import ie.aib.ioc.platform.failure.FailureModels.StoredFailure;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import ie.aib.ioc.platform.observability.EventLog;
import ie.aib.ioc.platform.ops.AuditService;
import ie.aib.ioc.platform.ops.OpsException;
import ie.aib.ioc.platform.replay.KafkaRangeReader.Plan;
import ie.aib.ioc.platform.replay.KafkaRangeReader.PartitionRange;
import ie.aib.ioc.platform.replay.ReplayModels.DryRun;
import ie.aib.ioc.platform.replay.ReplayModels.KafkaRangeFilter;
import ie.aib.ioc.platform.replay.ReplayModels.ReplayRequestView;
import ie.aib.ioc.platform.replay.ReplayModels.SingleReplayResult;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import static ie.aib.ioc.platform.replay.ReplayModels.TYPE_FAILURES;
import static ie.aib.ioc.platform.replay.ReplayModels.TYPE_KAFKA_RANGE;

/**
 * Manual replay, with the safety rules from the design:
 *
 * <table>
 *   <tr><td>Show the count first</td><td>{@link #dryRun} — nothing happens, you get a number</td></tr>
 *   <tr><td>A second person approves big replays</td><td>above the threshold a request waits in
 *       PENDING_APPROVAL; the DB itself refuses self-approval (CHECK constraint)</td></tr>
 *   <tr><td>Replay slowly</td><td>the executor is rate-limited</td></tr>
 *   <tr><td>Record who did what and when</td><td>every action → ops_audit + Splunk; every attempt →
 *       event_failure_attempt; every outcome change → event_ledger_transition</td></tr>
 * </table>
 *
 * And why replay can never damage data: it calls the same {@link EventPipeline} as the live consumer,
 * including "only apply if newer".
 */
@Service
public class ReplayService {

    private static final Logger log = LoggerFactory.getLogger(ReplayService.class);

    private final PipelineRegistry registry;
    private final FailureRepository failures;
    private final KafkaRangeReader reader;
    private final AuditService audit;
    private final EventLog eventLog;
    private final NamedParameterJdbcTemplate jdbc;
    private final ObjectMapper json;
    private final IocPlatformProperties props;
    private final Clock clock;

    public ReplayService(PipelineRegistry registry, FailureRepository failures, KafkaRangeReader reader,
                         AuditService audit, EventLog eventLog, NamedParameterJdbcTemplate jdbc, ObjectMapper json,
                         IocPlatformProperties props, Clock clock) {
        this.registry = registry;
        this.failures = failures;
        this.reader = reader;
        this.audit = audit;
        this.eventLog = eventLog;
        this.jdbc = jdbc;
        this.json = json;
        this.props = props;
        this.clock = clock;
    }

    // ===================================================================== single record

    public SingleReplayResult replayFailure(long failureId, String actor, String clientIp) {
        Instant until = clock.instant().plus(props.getAutoReplay().getClaimTimeout());
        StoredFailure f = failures.claimById(failureId, actor, until).orElseThrow(() -> {
            String status = failures.findView(failureId).map(v -> v.status()).orElse(null);
            if (status == null) {
                return OpsException.notFound("Failure " + failureId);
            }
            return OpsException.conflict("Failure " + failureId + " is " + status + " — only AUTO_RETRY or MANUAL rows can be replayed");
        });
        SingleReplayResult result;
        try {
            result = runClaimed(f, ReplayContext.manual(actor, null));
        } catch (PlatformUnavailableException e) {
            audit.record(actor, "REPLAY_FAILURE", "failure:" + failureId, Map.of("error", "platform unavailable"), "ERROR", clientIp);
            throw new OpsException(HttpStatus.SERVICE_UNAVAILABLE, "Database or Schema Registry unavailable — nothing was changed. Try again shortly.");
        }
        audit.record(actor, "REPLAY_FAILURE", "failure:" + failureId, Map.of("result", result.result(),
                "outcome", String.valueOf(result.outcome())), result.result(), clientIp);
        return result;
    }

    /** Run one already-claimed tray row through the pipeline. Used by manual, bulk and automatic replay. */
    public SingleReplayResult runClaimed(StoredFailure f, ReplayContext ctx) {
        InboundRecord rec = InboundRecord.of(f.topic(), f.partition(), f.offset(), f.kafkaTimestamp(), f.recordKey(),
                f.payload(), failures.headersFromJson(f.headersJson()), clock.instant());
        BatchResult r;
        try {
            r = registry.pipeline(f.consumerName()).process(List.of(rec), ctx);
        } catch (PlatformUnavailableException e) {
            failures.release(f.failureId()); // not the record's fault: hand it back untouched
            throw e;
        }
        if (!r.replays().isEmpty()) {
            BatchResult.ReplayNotice n = r.replays().get(0);
            return new SingleReplayResult(f.failureId(), "SUCCEEDED", n.result().name(), n.detail(), null, null, "REPLAYED");
        }
        if (!r.failures().isEmpty()) {
            BatchResult.FailureNotice n = r.failures().get(0);
            return new SingleReplayResult(f.failureId(), "FAILED", null, null, n.category().name(), n.message(), n.nextStatus());
        }
        failures.release(f.failureId());
        return new SingleReplayResult(f.failureId(), "UNCHANGED", null, "No ledger line found for this offset", null, null, f.status());
    }

    public boolean discard(long failureId, String actor, String reason, String clientIp) {
        if (reason == null || reason.isBlank()) {
            throw OpsException.badRequest("A reason is required to discard a failed event");
        }
        boolean ok = failures.discard(failureId, actor, reason, clock.instant());
        audit.record(actor, "DISCARD_FAILURE", "failure:" + failureId, Map.of("reason", reason), ok ? "OK" : "REJECTED", clientIp);
        if (!ok) {
            throw OpsException.conflict("Failure " + failureId + " is not in a discardable state");
        }
        return true;
    }

    // ===================================================================== bulk: dry run, request, approve

    public DryRun dryRun(String consumer, String type, Map<String, Object> filter) {
        List<String> warnings = new ArrayList<>();
        long count;
        if (TYPE_FAILURES.equals(type)) {
            count = failures.countReplayable(failureFilter(consumer, filter));
        } else if (TYPE_KAFKA_RANGE.equals(type)) {
            Plan plan = plan(consumer, rangeFilter(filter));
            count = plan.count();
            warnings.addAll(plan.warnings());
        } else {
            throw OpsException.badRequest("Unknown replay type " + type);
        }
        long threshold = props.getManualReplay().getApprovalThreshold();
        return new DryRun(type, count, count > threshold, threshold, warnings);
    }

    public ReplayRequestView createRequest(String consumer, String type, Map<String, Object> filter, String reason,
                                           String actor, String clientIp) {
        if (reason == null || reason.isBlank()) {
            throw OpsException.badRequest("A reason is required (it goes in the audit trail)");
        }
        registry.pipeline(consumer); // validates the consumer name
        DryRun dry = dryRun(consumer, type, filter);
        if (dry.count() == 0) {
            throw OpsException.badRequest("Nothing matches this filter — no request created");
        }
        String status = dry.needsSecondApprover() ? "PENDING_APPROVAL" : "APPROVED";
        Long id = jdbc.queryForObject("""
                INSERT INTO replay_request (consumer_name, request_type, filter_json, reason, expected_count, status,
                    requested_by, requested_at)
                OUTPUT INSERTED.request_id
                VALUES (:c, :type, :filter, :reason, :count, :status, :actor, :now)
                """, new MapSqlParameterSource("c", consumer).addValue("type", type).addValue("filter", toJson(filter))
                .addValue("reason", Db.truncate(reason, 1000)).addValue("count", dry.count()).addValue("status", status)
                .addValue("actor", actor).addValue("now", Db.utc(clock.instant())), Long.class);
        Map<String, Object> details = new LinkedHashMap<>();
        details.put("type", type);
        details.put("filter", filter);
        details.put("expectedCount", dry.count());
        details.put("status", status);
        details.put("reason", reason);
        audit.record(actor, "REPLAY_REQUESTED", "replay-request:" + id, details, "OK", clientIp);
        return find(id);
    }

    public ReplayRequestView decide(long requestId, boolean approve, String actor, String note, String clientIp) {
        ReplayRequestView r = find(requestId);
        if (!"PENDING_APPROVAL".equals(r.status())) {
            throw OpsException.conflict("Request " + requestId + " is " + r.status() + ", not PENDING_APPROVAL");
        }
        if (r.requestedBy().equalsIgnoreCase(actor)) {
            audit.record(actor, approve ? "REPLAY_APPROVE" : "REPLAY_REJECT", "replay-request:" + requestId,
                    Map.of("refused", "four-eyes: requester cannot decide"), "REJECTED", clientIp);
            throw OpsException.forbidden("Four-eyes rule: a different person must approve or reject this request");
        }
        int updated = jdbc.update("""
                UPDATE replay_request SET status = :status, decided_by = :actor, decided_at = :now, decision_note = :note
                WHERE request_id = :id AND status = 'PENDING_APPROVAL'
                """, new MapSqlParameterSource("status", approve ? "APPROVED" : "REJECTED").addValue("actor", actor)
                .addValue("now", Db.utc(clock.instant())).addValue("note", Db.truncate(note, 1000)).addValue("id", requestId));
        if (updated != 1) {
            throw OpsException.conflict("Request " + requestId + " changed while you were deciding — refresh and retry");
        }
        audit.record(actor, approve ? "REPLAY_APPROVE" : "REPLAY_REJECT", "replay-request:" + requestId,
                Map.of("note", note == null ? "" : note, "expectedCount", r.expectedCount()), "OK", clientIp);
        return find(requestId);
    }

    public ReplayRequestView cancel(long requestId, String actor, String clientIp) {
        int updated = jdbc.update("""
                UPDATE replay_request SET status = 'CANCELLED', decision_note = CONCAT(ISNULL(decision_note, ''), ' [cancelled by ', :actor, ']')
                WHERE request_id = :id AND status IN ('PENDING_APPROVAL', 'APPROVED', 'RUNNING')
                """, new MapSqlParameterSource("id", requestId).addValue("actor", actor));
        audit.record(actor, "REPLAY_CANCEL", "replay-request:" + requestId, Map.of(), updated == 1 ? "OK" : "REJECTED", clientIp);
        if (updated != 1) {
            throw OpsException.conflict("Request " + requestId + " can no longer be cancelled");
        }
        return find(requestId);
    }

    public ReplayRequestView find(long requestId) {
        return jdbc.query("SELECT * FROM replay_request WHERE request_id = :id", new MapSqlParameterSource("id", requestId),
                REQUEST_MAPPER).stream().findFirst().orElseThrow(() -> OpsException.notFound("Replay request " + requestId));
    }

    public Page<ReplayRequestView> list(String consumer, String status, int page, int size) {
        StringBuilder sql = new StringBuilder("SELECT * FROM replay_request WHERE consumer_name = :c");
        MapSqlParameterSource p = new MapSqlParameterSource("c", consumer);
        if (status != null) {
            sql.append(" AND status = :status");
            p.addValue("status", status);
        }
        sql.append(" ORDER BY request_id DESC OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY");
        p.addValue("skip", page * size).addValue("take", size + 1);
        return Page.of(jdbc.query(sql.toString(), p, REQUEST_MAPPER), page, size);
    }

    // ===================================================================== bulk: executor

    /** Picks up APPROVED requests (one at a time per pod; READPAST lets several pods share the queue). */
    @Scheduled(fixedDelayString = "${ioc.platform.manual-replay.executor-poll-ms:10000}")
    public void runApproved() {
        Optional<ReplayRequestView> claimed;
        try {
            // A pod that died mid-request stops heart-beating; put its RUNNING request back in the queue.
            jdbc.update("""
                    UPDATE replay_request SET status = 'APPROVED', claimed_by = NULL
                    WHERE status = 'RUNNING' AND claimed_by NOT IN (
                        SELECT instance_id FROM outbox_publisher_heartbeat WHERE heartbeat_at > :alive)
                    """, new MapSqlParameterSource("alive", Db.utc(clock.instant().minusSeconds(120))));
            claimed = jdbc.query("""
                    WITH next AS (
                        SELECT TOP (1) * FROM replay_request WITH (UPDLOCK, READPAST, ROWLOCK)
                        WHERE status = 'APPROVED' ORDER BY request_id
                    )
                    UPDATE next SET status = 'RUNNING', claimed_by = :me, started_at = ISNULL(started_at, :now)
                    OUTPUT INSERTED.*
                    """, new MapSqlParameterSource("me", props.getInstanceId()).addValue("now", Db.utc(clock.instant())),
                    REQUEST_MAPPER).stream().findFirst();
        } catch (RuntimeException e) {
            log.debug("Replay executor could not poll: {}", e.getMessage());
            return;
        }
        claimed.ifPresent(this::execute);
    }

    private void execute(ReplayRequestView req) {
        AtomicLong processed = new AtomicLong(req.processedCount());
        AtomicLong ok = new AtomicLong(req.succeededCount());
        AtomicLong bad = new AtomicLong(req.failedCount());
        RateLimiter limiter = new RateLimiter(props.getManualReplay().getRatePerSecond());
        eventLog.lifecycle("replay.request.started", Map.of("requestId", req.requestId(), "type", req.type(),
                "expectedCount", req.expectedCount(), "requestedBy", req.requestedBy(), "approvedBy", String.valueOf(req.decidedBy())));
        try {
            Map<String, Object> filter = fromJson(req.filterJson());
            if (TYPE_FAILURES.equals(req.type())) {
                FailureFilter ff = failureFilter(req.consumerName(), filter);
                ReplayContext ctx = ReplayContext.manual(req.requestedBy(), req.requestId());
                long after = 0;
                while (!isCancelled(req.requestId())) {
                    List<Long> ids = failures.replayableIds(ff, after, 100);
                    if (ids.isEmpty()) {
                        break;
                    }
                    for (Long id : ids) {
                        limiter.acquire();
                        Optional<StoredFailure> f = failures.claimById(id, props.getInstanceId(),
                                clock.instant().plus(props.getAutoReplay().getClaimTimeout()));
                        if (f.isEmpty()) {
                            continue; // someone else is on it
                        }
                        SingleReplayResult r = runClaimed(f.get(), ctx);
                        processed.incrementAndGet();
                        ("SUCCEEDED".equals(r.result()) ? ok : bad).incrementAndGet();
                    }
                    after = ids.get(ids.size() - 1);
                    progress(req.requestId(), processed.get(), ok.get(), bad.get());
                }
            } else {
                KafkaRangeFilter rf = rangeFilter(filter);
                ReplayContext ctx = ReplayContext.kafkaReread(req.requestedBy(), req.requestId(), rf.reprocess());
                EventPipeline<?, ?> pipeline = registry.pipeline(req.consumerName());
                for (PartitionRange range : plan(req.consumerName(), rf).ranges()) {
                    reader.read(range, props.getManualReplay().getKafkaRereadChunk(), chunk -> {
                        limiter.acquire(chunk.size());
                        Instant now = clock.instant();
                        List<InboundRecord> recs = new ArrayList<>(chunk.size());
                        for (ConsumerRecord<byte[], byte[]> c : chunk) {
                            recs.add(InboundRecord.from(c, now));
                        }
                        BatchResult r = pipeline.process(recs, ctx);
                        processed.addAndGet(chunk.size());
                        bad.addAndGet(r.failures().size());
                        ok.addAndGet(chunk.size() - r.failures().size());
                        progress(req.requestId(), processed.get(), ok.get(), bad.get());
                    }, () -> isCancelled(req.requestId()));
                }
            }
            finish(req.requestId(), isCancelled(req.requestId()) ? "CANCELLED" : "COMPLETED", null, processed.get(), ok.get(), bad.get());
        } catch (PlatformUnavailableException e) {
            // Not the request's fault: put it back in the queue; it resumes where the tray left off.
            finish(req.requestId(), "APPROVED", "Paused: platform unavailable — will resume", processed.get(), ok.get(), bad.get());
        } catch (RuntimeException e) {
            log.error("Replay request {} failed", req.requestId(), e);
            finish(req.requestId(), "FAILED", e.getClass().getSimpleName() + ": " + e.getMessage(), processed.get(), ok.get(), bad.get());
        }
        eventLog.lifecycle("replay.request.finished", Map.of("requestId", req.requestId(), "processed", processed.get(),
                "succeeded", ok.get(), "failed", bad.get()));
    }

    private boolean isCancelled(long requestId) {
        return "CANCELLED".equals(jdbc.queryForObject("SELECT status FROM replay_request WHERE request_id = :id",
                new MapSqlParameterSource("id", requestId), String.class));
    }

    private void progress(long id, long processed, long ok, long bad) {
        jdbc.update("""
                UPDATE replay_request SET processed_count = :p, succeeded_count = :ok, failed_count = :bad
                WHERE request_id = :id
                """, new MapSqlParameterSource("id", id).addValue("p", processed).addValue("ok", ok).addValue("bad", bad));
    }

    private void finish(long id, String status, String error, long processed, long ok, long bad) {
        try {
            jdbc.update("""
                    UPDATE replay_request SET status = CASE WHEN status = 'CANCELLED' THEN 'CANCELLED' ELSE :status END,
                        completed_at = CASE WHEN :status IN ('COMPLETED', 'FAILED', 'CANCELLED') THEN :now ELSE NULL END,
                        last_error = :err, processed_count = :p, succeeded_count = :ok, failed_count = :bad, claimed_by = NULL
                    WHERE request_id = :id
                    """, new MapSqlParameterSource("id", id).addValue("status", status).addValue("now", Db.utc(clock.instant()))
                    .addValue("err", Db.truncate(error, 1000)).addValue("p", processed).addValue("ok", ok).addValue("bad", bad));
        } catch (RuntimeException e) {
            log.warn("Could not record outcome of replay request {}: {}", id, e.getMessage());
        }
    }

    // ===================================================================== helpers

    private Plan plan(String consumer, KafkaRangeFilter f) {
        String topic = f.topic() != null ? f.topic() : registry.pipeline(consumer).settings().topic();
        if (f.fromOffset() == null && f.fromTime() == null) {
            throw OpsException.badRequest("KAFKA_RANGE needs fromOffset or fromTime");
        }
        if (f.fromOffset() != null && f.partition() == null) {
            throw OpsException.badRequest("Offsets are per partition — give a partition with fromOffset/toOffset");
        }
        return reader.plan(topic, f.partition(), f.fromOffset(), f.toOffset(), f.fromTime(), f.toTime());
    }

    private FailureFilter failureFilter(String consumer, Map<String, Object> m) {
        Map<String, Object> copy = new LinkedHashMap<>(m == null ? Map.of() : m);
        copy.put("consumer", consumer);
        return json.convertValue(copy, FailureFilter.class);
    }

    private KafkaRangeFilter rangeFilter(Map<String, Object> m) {
        return json.convertValue(m == null ? Map.of() : m, KafkaRangeFilter.class);
    }

    private String toJson(Object o) {
        try {
            return json.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw OpsException.badRequest("Unserialisable filter");
        }
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> fromJson(String s) {
        try {
            return json.readValue(s, Map.class);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Corrupt filter_json", e);
        }
    }

    private static final RowMapper<ReplayRequestView> REQUEST_MAPPER = (rs, i) -> new ReplayRequestView(
            rs.getLong("request_id"), rs.getString("consumer_name"), rs.getString("request_type"),
            rs.getString("filter_json"), rs.getString("reason"), rs.getLong("expected_count"), rs.getString("status"),
            rs.getString("requested_by"), Db.instant(rs, "requested_at"), rs.getString("decided_by"),
            Db.instant(rs, "decided_at"), rs.getString("decision_note"), Db.instant(rs, "started_at"),
            Db.instant(rs, "completed_at"), rs.getLong("processed_count"), rs.getLong("succeeded_count"),
            rs.getLong("failed_count"), rs.getString("last_error"));
}
