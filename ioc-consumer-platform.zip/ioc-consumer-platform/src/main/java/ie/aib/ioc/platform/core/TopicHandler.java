package ie.aib.ioc.platform.core;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Everything a topic team writes. The platform does the rest (ledger, dedup, version guard,
 * batching, bisect, failure tray, pause-on-outage, outbox, replay, logging, metrics, ops console).
 *
 * <p>Four things: a <b>mapper</b> ({@link #decode}), a <b>validator</b> ({@link #validate}),
 * a <b>repository</b> ({@link #lockAndLoad} + {@link #apply}), and a <b>materiality rule</b>
 * ({@link #assessMateriality}).
 *
 * @param <A> the Avro SpecificRecord type on the topic
 * @param <S> the stable internal domain state
 */
public interface TopicHandler<A, S> {

    ConsumerSettings settings();

    /** The Avro class this topic carries; anything else is a contract breach. */
    Class<A> avroType();

    /** Mapper: Avro → internal model. Pure, no I/O. */
    DecodedEvent<S> decode(A avro);

    /** Validator: topic contract checks. Throw {@link ValidationException} to reject. */
    void validate(DecodedEvent<S> event);

    /** Fingerprint of the business content only (not eventId/timestamps) — used to tell DUPLICATE from CONFLICT. */
    byte[] stateHash(DecodedEvent<S> event);

    /** Valid but not needed by IOC → FILTERED. Default: everything is in scope. */
    default Optional<String> filterReason(DecodedEvent<S> event) {
        return Optional.empty();
    }

    /**
     * Repository: load the current state for these keys and LOCK them for the rest of the
     * transaction (SQL Server: {@code WITH (UPDLOCK, HOLDLOCK)}), so a replay and the live
     * consumer can never interleave on the same entity.
     */
    Map<String, CurrentState<S>> lockAndLoad(Collection<String> entityKeys);

    /** Repository: write the changes (batched). Runs inside the platform's transaction. */
    void apply(List<AppliedChange<S>> changes);

    /** Materiality rule: does this change matter enough to announce on the Credit Change topic? */
    Materiality assessMateriality(CurrentState<S> before, DecodedEvent<S> after);

    /** Current stored state of one entity. {@code state} may be null for minimal implementations. */
    record CurrentState<S>(long sourceVersion, byte[] stateHash, boolean deleted, S state) {
    }

    /** One change to write, with the lineage of the Kafka record that caused it. */
    record AppliedChange<S>(DecodedEvent<S> event, InboundRecord record, String traceId, boolean isNew) {
    }
}
