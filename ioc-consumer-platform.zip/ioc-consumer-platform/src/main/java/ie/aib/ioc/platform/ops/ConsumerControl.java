package ie.aib.ioc.platform.ops;

import java.util.LinkedHashMap;
import java.util.Map;

import ie.aib.ioc.platform.core.PlatformHealth;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.kafka.listener.MessageListenerContainer;
import org.springframework.stereotype.Service;

/** Live state of a listener container, and the admin pause/resume switch. */
@Service
public class ConsumerControl {

    private final KafkaListenerEndpointRegistry containers;
    private final PlatformHealth health;

    public ConsumerControl(KafkaListenerEndpointRegistry containers, PlatformHealth health) {
        this.containers = containers;
        this.health = health;
    }

    public Map<String, Object> status(String consumer) {
        Map<String, Object> s = new LinkedHashMap<>();
        MessageListenerContainer c = containers.getListenerContainer(consumer);
        String state;
        if (c == null) {
            state = "NOT_REGISTERED";
        } else if (!c.isRunning()) {
            state = "STOPPED";
        } else if (health.isDown()) {
            state = "WAITING_FOR_PLATFORM";
        } else if (c.isPauseRequested() || c.isContainerPaused()) {
            state = "PAUSED_BY_OPERATOR";
        } else {
            state = "RUNNING";
        }
        s.put("state", state);
        s.put("platformDown", health.isDown());
        s.put("platformDownSince", health.downSince());
        s.put("platformReason", health.reason());
        s.put("currentBackoffMs", health.currentBackoff().toMillis());
        s.put("assignedPartitions", c == null || c.getAssignedPartitions() == null ? 0 : c.getAssignedPartitions().size());
        return s;
    }

    public void pause(String consumer) {
        container(consumer).pause();
    }

    public void resume(String consumer) {
        container(consumer).resume();
    }

    private MessageListenerContainer container(String consumer) {
        MessageListenerContainer c = containers.getListenerContainer(consumer);
        if (c == null) {
            throw OpsException.notFound("Listener container " + consumer);
        }
        return c;
    }
}
