package ie.aib.ioc.platform.core;

import java.util.List;

/**
 * A page of results. No total count: on a 20M-rows-a-day ledger, COUNT(*) per screen is too
 * expensive, so we fetch size+1 rows and report whether there is more.
 */
public record Page<T>(List<T> items, int page, int size, boolean hasMore) {

    public static <T> Page<T> of(List<T> fetched, int page, int size) {
        boolean more = fetched.size() > size;
        return new Page<>(more ? fetched.subList(0, size) : fetched, page, size, more);
    }
}
