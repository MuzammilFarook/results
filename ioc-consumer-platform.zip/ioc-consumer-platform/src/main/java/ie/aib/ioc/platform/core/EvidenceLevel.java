package ie.aib.ioc.platform.core;

/**
 * How much of each record the ledger keeps.
 * <ul>
 *   <li>FULL — metadata + full payload. Small, audit-sensitive topics (covenants, EB, collateral).</li>
 *   <li>METADATA — metadata + SHA-256 fingerprint only. High-volume topics (accounts, ~20M/day ≈ 7 TB/yr if full).</li>
 * </ul>
 * Failed records always keep their raw bytes in the failure tray, whatever the level.
 */
public enum EvidenceLevel {
    FULL,
    METADATA
}
