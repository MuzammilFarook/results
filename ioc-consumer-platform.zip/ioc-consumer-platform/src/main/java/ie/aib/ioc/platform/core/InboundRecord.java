package ie.aib.ioc.platform.core;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.record.TimestampType;

/**
 * A Kafka record exactly as it arrived — raw bytes, not a deserialised object.
 *
 * <p>Keeping the bytes is deliberate: deserialisation happens inside the pipeline, so a corrupt
 * record is just another categorised failure (it never poisons the partition), and every failure
 * can be replayed byte-for-byte after a fix.
 */
public record InboundRecord(
        String topic,
        int partition,
        long offset,
        Instant kafkaTimestamp,
        byte[] key,
        byte[] value,
        Map<String, byte[]> headers,
        Instant receivedAt,
        byte[] payloadSha256) {

    public static final String HEADER_TRACEPARENT = "traceparent";
    public static final String HEADER_TRACE_ID = "ioc-trace-id";

    public static InboundRecord from(ConsumerRecord<byte[], byte[]> rec, Instant receivedAt) {
        Map<String, byte[]> headers = new LinkedHashMap<>();
        for (Header h : rec.headers()) {
            headers.put(h.key(), h.value()); // last value wins for repeated keys
        }
        Instant ts = rec.timestampType() == TimestampType.NO_TIMESTAMP_TYPE ? null : Instant.ofEpochMilli(rec.timestamp());
        return of(rec.topic(), rec.partition(), rec.offset(), ts, rec.key(), rec.value(), headers, receivedAt);
    }

    public static InboundRecord of(String topic, int partition, long offset, Instant kafkaTimestamp, byte[] key,
                                   byte[] value, Map<String, byte[]> headers, Instant receivedAt) {
        return new InboundRecord(topic, partition, offset, kafkaTimestamp, key, value,
                headers == null ? Map.of() : headers, receivedAt, sha256(value));
    }

    public OffsetKey offsetKey() {
        return new OffsetKey(topic, partition, offset);
    }

    /** Confluent wire format: magic byte 0, then a 4-byte schema id. */
    public Integer schemaId() {
        if (value == null || value.length < 5 || value[0] != 0) {
            return null;
        }
        return ByteBuffer.wrap(value, 1, 4).getInt();
    }

    /** W3C traceparent ("00-{traceId}-{spanId}-{flags}") or our own header, if the producer sent one. */
    public String traceIdFromHeaders() {
        byte[] tp = headers.get(HEADER_TRACEPARENT);
        if (tp != null) {
            String[] parts = new String(tp, StandardCharsets.US_ASCII).split("-");
            if (parts.length >= 2 && parts[1].length() == 32) {
                return parts[1];
            }
        }
        byte[] own = headers.get(HEADER_TRACE_ID);
        return own == null ? null : new String(own, StandardCharsets.UTF_8);
    }

    /**
     * Deterministic trace id for records that arrive without one: derived from topic/partition/offset,
     * so a redelivery, an auto replay and a Kafka re-read of the same record all share one trace id.
     */
    public String derivedTraceId() {
        String seed = topic + "|" + partition + "|" + offset;
        return HexFormat.of().formatHex(sha256(seed.getBytes(StandardCharsets.UTF_8))).substring(0, 32);
    }

    public static byte[] sha256(byte[] data) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(data == null ? new byte[0] : data);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    public record OffsetKey(String topic, int partition, long offset) {
        @Override
        public String toString() {
            return topic + "/" + partition + "@" + offset;
        }
    }
}
