package ie.aib.ioc.platform.outbox;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.InboundRecord.OffsetKey;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.outbox.OutboxModels.NewOutboxNote;
import ie.aib.ioc.platform.outbox.OutboxModels.OutboxNote;
import ie.aib.ioc.platform.outbox.OutboxModels.SentEvidence;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class OutboxRepository {

    private static final String COLUMNS = """
            outbox_id, event_id, shard, aggregate_type, aggregate_key, aggregate_version, change_type, reasons, rule_version,
            consumer_name, source_system, source_topic, source_partition, source_offset, source_event_id, trace_id, status,
            attempts, last_error, created_at, sent_at, sent_topic, sent_partition, sent_offset""";

    private final NamedParameterJdbcTemplate jdbc;

    public OutboxRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    /** Called inside the consumer transaction: the note and the change are saved together or not at all. */
    public void insertBatch(List<NewOutboxNote> notes, Instant now) {
        if (notes.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = notes.stream().map(n -> new MapSqlParameterSource()
                .addValue("eid", n.eventId()).addValue("shard", n.shard()).addValue("atype", n.aggregateType())
                .addValue("akey", n.aggregateKey()).addValue("aver", n.aggregateVersion()).addValue("ctype", n.changeType())
                .addValue("reasons", Db.truncate(n.reasons(), 1000)).addValue("rule", n.ruleVersion())
                .addValue("consumer", n.consumerName()).addValue("ssys", n.sourceSystem()).addValue("stopic", n.sourceTopic())
                .addValue("spart", n.sourcePartition()).addValue("soff", n.sourceOffset()).addValue("seid", n.sourceEventId())
                .addValue("trace", n.traceId()).addValue("now", Db.utc(now))).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
                INSERT INTO outbox (event_id, shard, aggregate_type, aggregate_key, aggregate_version, change_type, reasons,
                    rule_version, consumer_name, source_system, source_topic, source_partition, source_offset, source_event_id,
                    trace_id, status, attempts, created_at)
                VALUES (:eid, :shard, :atype, :akey, :aver, :ctype, :reasons, :rule, :consumer, :ssys, :stopic, :spart, :soff,
                    :seid, :trace, 'PENDING', 0, :now)
                """, params);
    }

    /** Pending notes of one shard, oldest first. Only the shard's lease holder calls this, so no row locks needed. */
    public List<OutboxNote> pendingForShard(int shard, int limit) {
        return jdbc.query("SELECT TOP (:limit) " + COLUMNS + " FROM outbox WHERE shard = :shard AND status = 'PENDING'"
                + " ORDER BY outbox_id", new MapSqlParameterSource("shard", shard).addValue("limit", limit), MAPPER);
    }

    public void markSent(List<SentEvidence> sent) {
        if (sent.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = sent.stream().map(s -> new MapSqlParameterSource("id", s.outboxId())
                .addValue("topic", s.topic()).addValue("part", s.partition()).addValue("off", s.offset())
                .addValue("at", Db.utc(s.sentAt()))).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
                UPDATE outbox SET status = 'SENT', attempts = attempts + 1, sent_at = :at, sent_topic = :topic,
                    sent_partition = :part, sent_offset = :off, last_error = NULL
                WHERE outbox_id = :id AND status = 'PENDING'
                """, params);
    }

    public void markAttemptFailed(long outboxId, String error) {
        jdbc.update("UPDATE outbox SET attempts = attempts + 1, last_error = :err WHERE outbox_id = :id",
                new MapSqlParameterSource("id", outboxId).addValue("err", Db.truncate(error, 1000)));
    }

    /** Age of the oldest unsent note — the "stuck postman" alarm. */
    public Duration oldestPendingAge(Instant now) {
        Instant oldest = jdbc.query("SELECT MIN(created_at) AS oldest FROM outbox WHERE status = 'PENDING'",
                rs -> rs.next() ? Db.instant(rs, "oldest") : null);
        return oldest == null ? Duration.ZERO : Duration.between(oldest, now);
    }

    public Map<String, Long> countByStatus(String consumer) {
        Map<String, Long> out = new HashMap<>();
        jdbc.query("SELECT status, COUNT_BIG(*) AS n FROM outbox WHERE consumer_name = :c GROUP BY status",
                new MapSqlParameterSource("c", consumer), rs -> { out.put(rs.getString("status"), rs.getLong("n")); });
        return out;
    }

    public Page<OutboxNote> search(String consumer, String status, String aggregateKey, int page, int size) {
        StringBuilder sql = new StringBuilder("SELECT " + COLUMNS + " FROM outbox WHERE consumer_name = :c");
        MapSqlParameterSource p = new MapSqlParameterSource("c", consumer);
        if (status != null) { sql.append(" AND status = :status"); p.addValue("status", status); }
        if (aggregateKey != null) { sql.append(" AND aggregate_key = :key"); p.addValue("key", aggregateKey); }
        sql.append(" ORDER BY outbox_id DESC OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY");
        p.addValue("skip", page * size).addValue("take", size + 1);
        return Page.of(jdbc.query(sql.toString(), p, MAPPER), page, size);
    }

    public List<OutboxNote> findBySource(String consumer, OffsetKey source) {
        return jdbc.query("SELECT " + COLUMNS + " FROM outbox WHERE consumer_name = :c AND source_topic = :t"
                        + " AND source_partition = :p AND source_offset = :o ORDER BY outbox_id",
                new MapSqlParameterSource("c", consumer).addValue("t", source.topic()).addValue("p", source.partition())
                        .addValue("o", source.offset()), MAPPER);
    }

    public List<OutboxNote> findForTrace(String consumer, String term) {
        return jdbc.query("SELECT TOP (50) " + COLUMNS + " FROM outbox WHERE consumer_name = :c AND "
                        + "(trace_id = :term OR source_event_id = :term OR aggregate_key = :term OR event_id = :term)"
                        + " ORDER BY outbox_id DESC",
                new MapSqlParameterSource("c", consumer).addValue("term", term), MAPPER);
    }

    private static final RowMapper<OutboxNote> MAPPER = (rs, i) -> new OutboxNote(
            rs.getLong("outbox_id"), rs.getString("event_id"), rs.getInt("shard"), rs.getString("aggregate_type"),
            rs.getString("aggregate_key"), rs.getLong("aggregate_version"), rs.getString("change_type"),
            rs.getString("reasons"), rs.getString("rule_version"), rs.getString("consumer_name"),
            rs.getString("source_system"), rs.getString("source_topic"), rs.getInt("source_partition"),
            rs.getLong("source_offset"), rs.getString("source_event_id"), rs.getString("trace_id"), rs.getString("status"),
            rs.getInt("attempts"), rs.getString("last_error"), Db.instant(rs, "created_at"), Db.instant(rs, "sent_at"),
            rs.getString("sent_topic"), Db.nullableInt(rs, "sent_partition"), Db.nullableLong(rs, "sent_offset"));
}
