package ie.aib.ioc.platform.ops;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/** Serves the Ops console (a single static page shipped inside the platform jar) at /ops/. */
@Configuration
public class OpsWebConfig implements WebMvcConfigurer {

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addRedirectViewController("/", "/ops/");
        registry.addRedirectViewController("/ops", "/ops/");
        registry.addViewController("/ops/").setViewName("forward:/ops/index.html");
    }
}
