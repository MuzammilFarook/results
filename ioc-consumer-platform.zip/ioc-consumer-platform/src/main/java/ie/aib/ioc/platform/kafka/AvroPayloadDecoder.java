package ie.aib.ioc.platform.kafka;

import java.util.HashMap;
import java.util.Map;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;

/**
 * Turns raw bytes into the topic's Avro SpecificRecord, inside the pipeline.
 *
 * <p>Why not let Kafka deserialise? Because then a corrupt record throws before our code runs,
 * the offset never commits, and the partition is stuck forever ("poison pill"). Consuming bytes
 * and decoding here makes a bad record an ordinary DESERIALISATION failure, and lets replay use
 * exactly the same code on the bytes saved in the failure tray.
 *
 * <p>The underlying deserializer caches schemas by id, so this costs one registry call per schema,
 * not per record.
 */
public class AvroPayloadDecoder {

    private final KafkaAvroDeserializer deserializer = new KafkaAvroDeserializer();

    public AvroPayloadDecoder(Map<String, ?> kafkaProperties) {
        Map<String, Object> config = new HashMap<>(kafkaProperties);
        config.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);
        deserializer.configure(config, false);
    }

    public Object decode(String topic, byte[] value) {
        return deserializer.deserialize(topic, value);
    }
}
