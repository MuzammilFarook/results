package ie.aib.ioc.platform.ledger;

import java.time.Instant;
import java.time.LocalDate;

import ie.aib.ioc.platform.core.Outcome;
import ie.aib.ioc.platform.core.ProcessingMode;

/** One new line in the event ledger. */
public record LedgerRow(
        String consumerName,
        String topic,
        int partition,
        long offset,
        Instant kafkaTimestamp,
        String eventId,
        String entityKey,
        Long sourceVersion,
        Integer schemaId,
        byte[] payloadSha256,
        byte[] payload,
        String traceId,
        Outcome outcome,
        String outcomeDetail,
        boolean material,
        ProcessingMode mode,
        String instanceId,
        LocalDate businessDate,
        Instant receivedAt,
        Instant processedAt) {
}
