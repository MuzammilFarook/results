package ie.aib.ioc.platform.replay;

import java.time.Instant;
import java.util.List;

/** Data shapes for replay. */
public final class ReplayModels {

    private ReplayModels() {
    }

    public static final String TYPE_FAILURES = "FAILURES";
    public static final String TYPE_KAFKA_RANGE = "KAFKA_RANGE";

    /** Re-read a window straight from Kafka (offsets or times). */
    public record KafkaRangeFilter(String topic, Integer partition, Long fromOffset, Long toOffset,
                                   Instant fromTime, Instant toTime, boolean reprocess) {
    }

    /** "Show the count first." */
    public record DryRun(String type, long count, boolean needsSecondApprover, long approvalThreshold,
                         List<String> warnings) {
    }

    public record SingleReplayResult(long failureId, String result, String outcome, String detail,
                                     String errorCategory, String errorMessage, String nextStatus) {
    }

    public record ReplayRequestView(long requestId, String consumerName, String type, String filterJson, String reason,
                                    long expectedCount, String status, String requestedBy, Instant requestedAt,
                                    String decidedBy, Instant decidedAt, String decisionNote, Instant startedAt,
                                    Instant completedAt, long processedCount, long succeededCount, long failedCount,
                                    String lastError) {
    }
}
