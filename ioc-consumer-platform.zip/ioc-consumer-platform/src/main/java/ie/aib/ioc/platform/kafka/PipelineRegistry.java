package ie.aib.ioc.platform.kafka;

import java.time.Clock;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.PlatformHealth;
import ie.aib.ioc.platform.core.TopicHandler;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.EventLog;
import org.springframework.stereotype.Component;

/**
 * One pipeline + runtime per {@link TopicHandler} bean. Usually one per deployable
 * ("one clerk per type of letter"), but the platform does not assume it.
 */
@Component
public class PipelineRegistry {

    private final Map<String, EventPipeline<?, ?>> pipelines = new LinkedHashMap<>();
    private final Map<String, ConsumerRuntime> runtimes = new LinkedHashMap<>();

    public PipelineRegistry(List<TopicHandler<?, ?>> handlers, EventPipeline.Dependencies deps, PlatformHealth health,
                            ConsumerStats stats, EventLog eventLog, Clock clock) {
        for (TopicHandler<?, ?> handler : handlers) {
            EventPipeline<?, ?> pipeline = create(handler, deps);
            String name = pipeline.consumerName();
            if (pipelines.put(name, pipeline) != null) {
                throw new IllegalStateException("Two topic handlers share the consumer name " + name);
            }
            runtimes.put(name, new ConsumerRuntime(pipeline, health, stats, eventLog, clock));
            stats.register(name, pipeline.settings().topic());
        }
    }

    private static <A, S> EventPipeline<A, S> create(TopicHandler<A, S> handler, EventPipeline.Dependencies deps) {
        return new EventPipeline<>(handler, deps);
    }

    public EventPipeline<?, ?> pipeline(String consumer) {
        EventPipeline<?, ?> p = pipelines.get(consumer);
        if (p == null) {
            throw new NoSuchElementException("Unknown consumer: " + consumer);
        }
        return p;
    }

    public ConsumerRuntime runtime(String consumer) {
        ConsumerRuntime r = runtimes.get(consumer);
        if (r == null) {
            throw new NoSuchElementException("Unknown consumer: " + consumer);
        }
        return r;
    }

    public Collection<EventPipeline<?, ?>> all() {
        return pipelines.values();
    }
}
