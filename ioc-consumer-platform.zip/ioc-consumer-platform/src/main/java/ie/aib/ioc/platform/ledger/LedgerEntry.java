package ie.aib.ioc.platform.ledger;

import java.time.Instant;
import java.time.LocalDate;

/** A ledger line as shown to ops (no payload). */
public record LedgerEntry(
        long ledgerId,
        String consumerName,
        String topic,
        int partition,
        long offset,
        Instant kafkaTimestamp,
        String eventId,
        String entityKey,
        Long sourceVersion,
        Integer schemaId,
        String payloadSha256,
        String traceId,
        String outcome,
        String outcomeDetail,
        boolean material,
        String processingMode,
        String instanceId,
        LocalDate businessDate,
        Instant receivedAt,
        Instant processedAt,
        Instant lastChangedAt) {

    /** Current ledger state of an offset, as seen by the pipeline. */
    public record Ref(long ledgerId, String outcome, String traceId) {
    }

    /** One change of outcome (e.g. FAILED → REPLAYED), with who and how. */
    public record Transition(long transitionId, String fromOutcome, String toOutcome, String detail,
                             String processingMode, String actor, Long replayRequestId, Instant changedAt) {
    }
}
