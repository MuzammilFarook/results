package ie.aib.ioc.platform.outbox;

import java.time.Instant;

/** Data shapes for the outbox ("announcements waiting to be sent"). */
public final class OutboxModels {

    private OutboxModels() {
    }

    /** A note written in the same transaction as the state change. */
    public record NewOutboxNote(
            String eventId, int shard, String aggregateType, String aggregateKey, long aggregateVersion,
            String changeType, String reasons, String ruleVersion, String consumerName, String sourceSystem,
            String sourceTopic, int sourcePartition, long sourceOffset, String sourceEventId, String traceId) {
    }

    /** A note as stored — what the postman sends and what ops sees as evidence. */
    public record OutboxNote(
            long outboxId, String eventId, int shard, String aggregateType, String aggregateKey, long aggregateVersion,
            String changeType, String reasons, String ruleVersion, String consumerName, String sourceSystem,
            String sourceTopic, int sourcePartition, long sourceOffset, String sourceEventId, String traceId,
            String status, int attempts, String lastError, Instant createdAt, Instant sentAt, String sentTopic,
            Integer sentPartition, Long sentOffset) {
    }

    /** Where Kafka put it — the proof the announcement was sent. */
    public record SentEvidence(long outboxId, String topic, int partition, long offset, Instant sentAt) {
    }
}
