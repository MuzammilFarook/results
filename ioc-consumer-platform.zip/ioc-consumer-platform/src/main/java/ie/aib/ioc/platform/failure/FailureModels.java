package ie.aib.ioc.platform.failure;

import java.time.Instant;
import java.util.Map;

import ie.aib.ioc.platform.core.FailureCategory;

/** Data shapes for the failure tray. */
public final class FailureModels {

    private FailureModels() {
    }

    /** A record going into the tray for the first time. */
    public record NewFailure(
            String consumerName, String topic, int partition, long offset, Instant kafkaTimestamp,
            String eventId, String entityKey, Long sourceVersion, Integer schemaId,
            byte[] recordKey, Map<String, byte[]> headers, byte[] payload, String traceId,
            FailureCategory category, String errorClass, String errorMessage) {
    }

    /** A tray row including the raw bytes — what replay needs. */
    public record StoredFailure(
            long failureId, String consumerName, String topic, int partition, long offset, Instant kafkaTimestamp,
            String eventId, String entityKey, byte[] recordKey, String headersJson, byte[] payload, String traceId,
            String category, String status, int attemptCount, Instant nextAttemptAt) {
    }

    /** A tray row as shown in the console (no bytes). */
    public record FailureView(
            long failureId, String consumerName, String topic, int partition, long offset, Instant kafkaTimestamp,
            String eventId, String entityKey, Long sourceVersion, Integer schemaId, String traceId,
            String category, String errorClass, String errorMessage, int attemptCount, String status,
            Instant nextAttemptAt, Instant firstFailedAt, Instant lastFailedAt, Instant resolvedAt,
            String resolvedBy, String resolutionNote, int payloadBytes) {
    }

    /** One attempt (first failure, each retry, each manual replay). */
    public record FailureAttempt(
            long attemptId, int attemptNo, String processingMode, String actor, String result, String resultOutcome,
            String category, String errorClass, String errorMessage, Long replayRequestId, Instant attemptedAt) {
    }

    /** Filter used by the console list, dry-run counts and bulk replay requests. */
    public record FailureFilter(
            String consumer, String category, String status, String entityKey, String errorClassContains,
            String topic, Integer partition, Instant from, Instant to) {
    }
}
