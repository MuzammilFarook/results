package ie.aib.ioc.platform.observability;

import java.time.Clock;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.Db;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import static net.logstash.logback.argument.StructuredArguments.entries;

/**
 * Counts, never per-success log lines.
 *
 * <p>Every count goes to Micrometer (Prometheus / Azure Monitor) immediately, and once a minute
 * each consumer writes ONE summary line for Splunk plus one row in {@code consumer_stats_minute}
 * for the ops console. At 20M events/day that is 1,440 lines a day instead of 60–100 million.
 */
@Component
public class ConsumerStats {

    private static final Logger SPLUNK = LoggerFactory.getLogger("ioc.consumer.summary");

    public enum Counted {
        CONSUMED, PROCESSED, DUPLICATE, STALE, SUPERSEDED, FILTERED, FAILED, REPLAYED,
        RETRIED, REDELIVERED, PUBLISHED, MATERIAL
    }

    private final MeterRegistry registry;
    private final NamedParameterJdbcTemplate jdbc;
    private final IocPlatformProperties props;
    private final Clock clock;
    private final Map<String, Window> windows = new ConcurrentHashMap<>();
    private final Map<String, String> topics = new ConcurrentHashMap<>();

    public ConsumerStats(MeterRegistry registry, NamedParameterJdbcTemplate jdbc, IocPlatformProperties props, Clock clock) {
        this.registry = registry;
        this.jdbc = jdbc;
        this.props = props;
        this.clock = clock;
    }

    public void register(String consumer, String topic) {
        topics.put(consumer, topic);
        windows.computeIfAbsent(consumer, c -> new Window());
    }

    public void add(String consumer, Counted what, long n) {
        if (n <= 0) {
            return;
        }
        windows.computeIfAbsent(consumer, c -> new Window()).counts.get(what).add(n);
        Counter.builder("ioc.consumer.events")
                .description("Records by outcome / activity")
                .tag("consumer", consumer).tag("what", what.name().toLowerCase())
                .register(registry).increment(n);
    }

    public void batchDuration(String consumer, long millis, int size) {
        Window w = windows.computeIfAbsent(consumer, c -> new Window());
        synchronized (w.batchMillis) {
            w.batchMillis.add(millis);
        }
        Timer.builder("ioc.consumer.batch").tag("consumer", consumer).register(registry)
                .record(java.time.Duration.ofMillis(millis));
        registry.summary("ioc.consumer.batch.size", "consumer", consumer).record(size);
    }

    public void paused(String consumer, long millis) {
        windows.computeIfAbsent(consumer, c -> new Window()).pausedMs.add(millis);
    }

    /** Live view for the console (current, not-yet-flushed minute). */
    public Map<String, Long> currentMinute(String consumer) {
        Window w = windows.get(consumer);
        Map<String, Long> out = new LinkedHashMap<>();
        if (w != null) {
            w.counts.forEach((k, v) -> out.put(k.name().toLowerCase(), v.sum()));
        }
        return out;
    }

    /** Once a minute: one summary line per consumer to Splunk, one row to the stats table. */
    @Scheduled(cron = "0 * * * * *")
    public void flush() {
        Instant minute = clock.instant().truncatedTo(ChronoUnit.MINUTES).minus(1, ChronoUnit.MINUTES);
        for (Map.Entry<String, Window> e : windows.entrySet()) {
            String consumer = e.getKey();
            Snapshot s = e.getValue().drain();
            Map<String, Object> line = new LinkedHashMap<>();
            line.put("type", "consumer.summary");
            line.put("consumer", consumer);
            line.put("topic", topics.get(consumer));
            line.put("instance", props.getInstanceId());
            line.put("window", minute + "/PT1M");
            s.counts.forEach((k, v) -> line.put(k.name().toLowerCase(), v));
            line.put("pausedMs", s.pausedMs);
            line.put("p95BatchMs", s.p95BatchMs);
            line.put("lagMax", maxLag());
            SPLUNK.info("consumer.summary", entries(line));
            try {
                jdbc.update("""
                        INSERT INTO consumer_stats_minute (consumer_name, instance_id, minute_start, consumed, processed, duplicate,
                            stale, superseded, filtered, failed, replayed, retried, redelivered, published, material, paused_ms, p95_batch_ms)
                        VALUES (:c, :i, :m, :consumed, :processed, :duplicate, :stale, :superseded, :filtered, :failed, :replayed,
                            :retried, :redelivered, :published, :material, :paused, :p95)
                        """, new MapSqlParameterSource("c", consumer).addValue("i", props.getInstanceId())
                        .addValue("m", Db.utc(minute))
                        .addValue("consumed", s.get(Counted.CONSUMED)).addValue("processed", s.get(Counted.PROCESSED))
                        .addValue("duplicate", s.get(Counted.DUPLICATE)).addValue("stale", s.get(Counted.STALE))
                        .addValue("superseded", s.get(Counted.SUPERSEDED)).addValue("filtered", s.get(Counted.FILTERED))
                        .addValue("failed", s.get(Counted.FAILED)).addValue("replayed", s.get(Counted.REPLAYED))
                        .addValue("retried", s.get(Counted.RETRIED)).addValue("redelivered", s.get(Counted.REDELIVERED))
                        .addValue("published", s.get(Counted.PUBLISHED)).addValue("material", s.get(Counted.MATERIAL))
                        .addValue("paused", s.pausedMs).addValue("p95", s.p95BatchMs));
            } catch (RuntimeException ex) {
                // The Splunk line above is already out; losing one console row while the DB is down is acceptable.
                SPLUNK.warn("Could not persist stats minute for {}: {}", consumer, ex.getMessage());
            }
        }
    }

    /** Max consumer lag from the Kafka client metrics Spring Boot binds to Micrometer. */
    private Double maxLag() {
        double max = -1;
        for (Meter m : registry.getMeters()) {
            if (m.getId().getName().endsWith("records.lag.max")) {
                for (var measurement : m.measure()) {
                    if (!Double.isNaN(measurement.getValue())) {
                        max = Math.max(max, measurement.getValue());
                    }
                }
            }
        }
        return max < 0 ? null : max;
    }

    private static final class Window {
        final Map<Counted, LongAdder> counts = new EnumMap<>(Counted.class);
        final LongAdder pausedMs = new LongAdder();
        final List<Long> batchMillis = new ArrayList<>();

        Window() {
            for (Counted c : Counted.values()) {
                counts.put(c, new LongAdder());
            }
        }

        Snapshot drain() {
            Map<Counted, Long> snap = new EnumMap<>(Counted.class);
            counts.forEach((k, v) -> snap.put(k, v.sumThenReset()));
            long p95;
            synchronized (batchMillis) {
                List<Long> sorted = new ArrayList<>(batchMillis);
                batchMillis.clear();
                sorted.sort(Long::compare);
                p95 = sorted.isEmpty() ? 0 : sorted.get((int) Math.min(sorted.size() - 1, Math.ceil(sorted.size() * 0.95) - 1));
            }
            return new Snapshot(snap, pausedMs.sumThenReset(), p95);
        }
    }

    private record Snapshot(Map<Counted, Long> counts, long pausedMs, long p95BatchMs) {
        long get(Counted c) {
            return counts.getOrDefault(c, 0L);
        }
    }
}
