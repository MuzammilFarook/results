package ie.aib.ioc.platform.security;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.oauth2.core.oidc.user.OidcUserAuthority;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.web.csrf.CsrfTokenRequestAttributeHandler;
import org.springframework.security.web.header.writers.ReferrerPolicyHeaderWriter;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Who may do what in the Ops console / API.
 *
 * <table>
 *   <tr><th>Role</th><th>Can</th></tr>
 *   <tr><td>OPS_READ</td><td>see overview, ledger, trace, failures (no payloads), outbox, audit</td></tr>
 *   <tr><td>OPS_REPLAY</td><td>+ view payloads, replay/discard single events, request bulk replays</td></tr>
 *   <tr><td>OPS_APPROVE</td><td>+ approve/reject bulk replays requested by SOMEONE ELSE</td></tr>
 *   <tr><td>OPS_ADMIN</td><td>everything, + pause/resume consumers, resolve gaps, submit control totals</td></tr>
 * </table>
 *
 * Modes ({@code ioc.ops.security.mode}): {@code local} — form login with demo users;
 * {@code entra} — Microsoft Entra ID SSO for people (app roles in the "roles" claim) plus bearer
 * JWT for service principals (e.g. a source team's job posting control totals).
 */
@Configuration
@EnableWebSecurity
public class OpsSecurityConfig {

    static final String READ = "OPS_READ";
    static final String REPLAY = "OPS_REPLAY";
    static final String APPROVE = "OPS_APPROVE";
    static final String ADMIN = "OPS_ADMIN";
    static final String RECON = "RECON_SUBMIT";

    static HttpSecurity common(HttpSecurity http) throws Exception {
        CsrfTokenRequestAttributeHandler csrfHandler = new CsrfTokenRequestAttributeHandler();
        csrfHandler.setCsrfRequestAttributeName(null); // load the token on every request so the cookie is always there
        http.authorizeHttpRequests(a -> a
                        .requestMatchers("/actuator/health/**", "/actuator/info", "/actuator/prometheus", "/error", "/login").permitAll()
                        .requestMatchers(HttpMethod.GET, "/ops/api/consumers/*/failures/*/payload").hasAnyRole(REPLAY, ADMIN)
                        .requestMatchers(HttpMethod.GET, "/ops/api/**").hasAnyRole(READ, REPLAY, APPROVE, ADMIN)
                        .requestMatchers(HttpMethod.POST, "/ops/api/replay-requests/*/approve", "/ops/api/replay-requests/*/reject").hasAnyRole(APPROVE, ADMIN)
                        .requestMatchers(HttpMethod.POST, "/ops/api/replay-requests/*/cancel").hasAnyRole(REPLAY, APPROVE, ADMIN)
                        .requestMatchers(HttpMethod.POST, "/ops/api/consumers/*/control-totals").hasAnyRole(ADMIN, RECON)
                        .requestMatchers(HttpMethod.POST, "/ops/api/consumers/*/pause", "/ops/api/consumers/*/resume", "/ops/api/gaps/*/resolve").hasRole(ADMIN)
                        .requestMatchers(HttpMethod.POST, "/ops/api/consumers/*/failures/**", "/ops/api/consumers/*/replay/**",
                                "/ops/api/consumers/*/replay-requests").hasAnyRole(REPLAY, ADMIN)
                        .requestMatchers("/dev/**").hasRole(ADMIN)
                        .requestMatchers("/ops/**", "/").authenticated()
                        .anyRequest().denyAll())
                .csrf(c -> c
                        .csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
                        .csrfTokenRequestHandler(csrfHandler)
                        // bearer tokens are never sent automatically by a browser, so CSRF does not apply to them
                        .ignoringRequestMatchers(r -> r.getHeader("Authorization") != null && r.getHeader("Authorization").startsWith("Bearer ")))
                .addFilterAfter(new CsrfCookieFilter(), BasicAuthenticationFilter.class)
                .headers(h -> h
                        .contentSecurityPolicy(csp -> csp.policyDirectives(
                                "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; "
                                        + "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'"))
                        .referrerPolicy(r -> r.policy(ReferrerPolicyHeaderWriter.ReferrerPolicy.NO_REFERRER)));
        return http;
    }

    /** Local / dev: form login, demo users. Never enable in a shared environment. */
    @Configuration
    @ConditionalOnProperty(prefix = "ioc.ops.security", name = "mode", havingValue = "local", matchIfMissing = true)
    static class Local {

        @Bean
        SecurityFilterChain localChain(HttpSecurity http) throws Exception {
            return common(http).formLogin(f -> f.defaultSuccessUrl("/ops/", true)).httpBasic(Customizer.withDefaults()).build();
        }

        @Bean
        UserDetailsService demoUsers() {
            return new InMemoryUserDetailsManager(
                    User.withUsername("viewer").password("{noop}viewer").roles(READ).build(),
                    User.withUsername("alice").password("{noop}alice").roles(READ, REPLAY).build(),
                    User.withUsername("bob").password("{noop}bob").roles(READ, REPLAY, APPROVE).build(),
                    User.withUsername("admin").password("{noop}admin").roles(READ, REPLAY, APPROVE, ADMIN).build());
        }
    }

    /** Entra ID: SSO for people, bearer JWT for service principals. App roles arrive in the "roles" claim. */
    @Configuration
    @ConditionalOnProperty(prefix = "ioc.ops.security", name = "mode", havingValue = "entra")
    static class Entra {

        @Bean
        SecurityFilterChain entraChain(HttpSecurity http) throws Exception {
            JwtGrantedAuthoritiesConverter roles = new JwtGrantedAuthoritiesConverter();
            roles.setAuthoritiesClaimName("roles");
            roles.setAuthorityPrefix("ROLE_");
            JwtAuthenticationConverter jwt = new JwtAuthenticationConverter();
            jwt.setJwtGrantedAuthoritiesConverter(roles);
            return common(http)
                    .oauth2Login(Customizer.withDefaults())
                    .oauth2ResourceServer(rs -> rs.jwt(j -> j.jwtAuthenticationConverter(jwt)))
                    .build();
        }

        @Bean
        GrantedAuthoritiesMapper entraRoleMapper() {
            return authorities -> {
                Set<GrantedAuthority> out = new HashSet<>(authorities);
                for (GrantedAuthority a : authorities) {
                    if (a instanceof OidcUserAuthority oidc && oidc.getIdToken().getClaims().get("roles") instanceof Collection<?> roles) {
                        roles.forEach(r -> out.add(new SimpleGrantedAuthority("ROLE_" + r)));
                    }
                }
                return out;
            };
        }
    }

    /** Makes sure the XSRF-TOKEN cookie is written so the console can echo it in X-XSRF-TOKEN. */
    static final class CsrfCookieFilter extends OncePerRequestFilter {
        @Override
        protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
                throws ServletException, IOException {
            CsrfToken token = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
            if (token != null) {
                token.getToken();
            }
            chain.doFilter(request, response);
        }
    }
}
