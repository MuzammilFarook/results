package ie.aib.ioc.platform.core;

import java.io.IOException;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.sql.SQLException;
import java.sql.SQLTransientException;
import java.util.Set;

import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.PessimisticLockingFailureException;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.dao.TransientDataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.CannotCreateTransactionException;

/**
 * The single place that decides: is this the LETTER's fault, a TEMPORARY blip, or is the SYSTEM down?
 *
 * <pre>
 *   DATA      → failure tray (bad letter)              — the partition keeps moving
 *   TRANSIENT → retry quickly in memory, then tray      — deadlock, throttling, timeout
 *   PLATFORM  → pause the consumer, do NOT touch tray   — DB / Schema Registry unreachable
 * </pre>
 */
@Component
public class ErrorClassifier {

    public enum ErrorClass { DATA, TRANSIENT, PLATFORM }

    /** Azure SQL: database unavailable / cannot open — the platform is down. */
    private static final Set<Integer> SQL_PLATFORM_CODES = Set.of(4060, 40613, 18456);
    /** Azure SQL: deadlock, throttling, resource limits — temporary. */
    private static final Set<Integer> SQL_TRANSIENT_CODES = Set.of(1205, 40197, 40501, 49918, 49919, 49920, 10928, 10929, 4221, 10053, 10054, 10060);

    public ErrorClass classify(Throwable error) {
        ErrorClass result = ErrorClass.DATA;
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            if (t instanceof PlatformUnavailableException
                    || t instanceof CannotGetJdbcConnectionException
                    || t instanceof CannotCreateTransactionException
                    || t instanceof ConnectException
                    || t instanceof UnknownHostException) {
                return ErrorClass.PLATFORM;
            }
            if (t instanceof RestClientException rce) {
                // Schema Registry: 5xx/401/403 = registry or credentials broken; 404 = unknown schema id (bad letter)
                int status = rce.getStatus();
                if (status >= 500 || status == 401 || status == 403) {
                    return ErrorClass.PLATFORM;
                }
                return ErrorClass.DATA;
            }
            if (t instanceof SQLException sql) {
                String state = sql.getSQLState();
                if ((state != null && state.startsWith("08")) || SQL_PLATFORM_CODES.contains(sql.getErrorCode())) {
                    return ErrorClass.PLATFORM;
                }
                if (sql instanceof SQLTransientException || SQL_TRANSIENT_CODES.contains(sql.getErrorCode())) {
                    result = ErrorClass.TRANSIENT;
                }
            }
            if (t instanceof TransientDataAccessException
                    || t instanceof QueryTimeoutException
                    || t instanceof CannotAcquireLockException
                    || t instanceof PessimisticLockingFailureException
                    || t instanceof SocketTimeoutException) {
                result = ErrorClass.TRANSIENT;
            }
            if (t instanceof IOException && isSchemaRegistryIo(t)) {
                return ErrorClass.PLATFORM;
            }
        }
        return result;
    }

    /** Category for a DATA (or exhausted TRANSIENT) error. */
    public FailureCategory category(Throwable error, Phase phase, ErrorClass errorClass) {
        if (errorClass == ErrorClass.TRANSIENT) {
            return FailureCategory.TRANSIENT_EXHAUSTED;
        }
        for (Throwable t = error; t != null; t = t.getCause() == t ? null : t.getCause()) {
            if (t instanceof ValidationException) return FailureCategory.VALIDATION;
            if (t instanceof ConflictException) return FailureCategory.CONFLICT;
            if (t instanceof DependencyMissingException) return FailureCategory.DEPENDENCY_MISSING;
        }
        return switch (phase) {
            case DESERIALISE -> FailureCategory.DESERIALISATION;
            case MAP -> FailureCategory.VALIDATION;
            case PERSIST -> FailureCategory.UNKNOWN;
        };
    }

    private boolean isSchemaRegistryIo(Throwable t) {
        StackTraceElement[] st = t.getStackTrace();
        return st.length > 0 && st[0].getClassName().startsWith("io.confluent.kafka.schemaregistry");
    }

    /** Where in the pipeline the error happened. */
    public enum Phase { DESERIALISE, MAP, PERSIST }
}
