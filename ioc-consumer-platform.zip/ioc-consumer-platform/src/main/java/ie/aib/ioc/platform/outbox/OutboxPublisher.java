package ie.aib.ioc.platform.outbox;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import ie.aib.ioc.events.v1.CreditChangeEvent;
import ie.aib.ioc.events.v1.SourceRef;
import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.config.PlatformConfiguration;
import ie.aib.ioc.platform.core.InboundRecord;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.ConsumerStats.Counted;
import ie.aib.ioc.platform.observability.EventLog;
import ie.aib.ioc.platform.outbox.OutboxModels.OutboxNote;
import ie.aib.ioc.platform.outbox.OutboxModels.SentEvidence;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * The postman. Empties the outbox, sends each note to the Credit Change topic, and writes down
 * exactly where Kafka put it (topic / partition / offset) — that is the evidence the announcement
 * was produced at least once.
 *
 * <p>Order: per shard, notes are sent in outbox_id order and marked SENT in that order. If one send
 * fails, the shard stops there and retries next tick, so a later note for the same entity is never
 * marked sent ahead of an earlier one. Delivery is at-least-once: a crash between send and mark
 * re-sends the note with the SAME eventId, which downstream dedups.
 */
@Component
@ConditionalOnProperty(prefix = "ioc.platform.outbox", name = "publisher-enabled", havingValue = "true", matchIfMissing = true)
public class OutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(OutboxPublisher.class);

    private final OutboxRepository outbox;
    private final ShardLeaseManager leases;
    private final KafkaTemplate<String, Object> kafka;
    private final IocPlatformProperties props;
    private final ConsumerStats stats;
    private final EventLog eventLog;
    private final Clock clock;
    private volatile Duration oldestPending = Duration.ZERO;

    public OutboxPublisher(OutboxRepository outbox, ShardLeaseManager leases,
                           @Qualifier(PlatformConfiguration.CREDIT_CHANGE_TEMPLATE) KafkaTemplate<String, Object> kafka,
                           IocPlatformProperties props, ConsumerStats stats, EventLog eventLog, Clock clock,
                           MeterRegistry registry) {
        this.outbox = outbox;
        this.leases = leases;
        this.kafka = kafka;
        this.props = props;
        this.stats = stats;
        this.eventLog = eventLog;
        this.clock = clock;
        Gauge.builder("ioc.outbox.oldest.pending.seconds", this, p -> p.oldestPending.toSeconds())
                .description("Age of the oldest unsent Credit Change note").register(registry);
    }

    @Scheduled(fixedDelayString = "${ioc.platform.outbox.poll-interval-ms:500}")
    public void publish() {
        for (int shard : leases.ownedShards()) {
            try {
                publishShard(shard);
            } catch (RuntimeException e) {
                log.warn("Outbox shard {} publish round failed: {}", shard, e.getMessage());
            }
        }
    }

    private void publishShard(int shard) {
        List<OutboxNote> notes = outbox.pendingForShard(shard, props.getOutbox().getBatchSize());
        if (notes.isEmpty()) {
            return;
        }
        // Send the whole batch (idempotent producer keeps per-partition order), then confirm in order.
        List<CompletableFuture<SendResult<String, Object>>> futures = new ArrayList<>(notes.size());
        for (OutboxNote n : notes) {
            futures.add(kafka.send(toRecord(n)));
        }
        List<SentEvidence> sent = new ArrayList<>();
        long timeoutMs = props.getOutbox().getSendTimeout().toMillis();
        for (int i = 0; i < notes.size(); i++) {
            OutboxNote n = notes.get(i);
            try {
                RecordMetadata md = futures.get(i).get(timeoutMs, TimeUnit.MILLISECONDS).getRecordMetadata();
                sent.add(new SentEvidence(n.outboxId(), md.topic(), md.partition(), md.offset(), clock.instant()));
            } catch (Exception e) {
                if (e instanceof InterruptedException) {
                    Thread.currentThread().interrupt();
                }
                outbox.markAttemptFailed(n.outboxId(), e.getClass().getSimpleName() + ": " + e.getMessage());
                log.warn("Outbox note {} (shard {}) not confirmed; shard stops here this round: {}", n.outboxId(), shard, e.toString());
                break;
            }
        }
        outbox.markSent(sent);
        sent.forEach(s -> stats.add(consumerOf(notes, s.outboxId()), Counted.PUBLISHED, 1));
    }

    private ProducerRecord<String, Object> toRecord(OutboxNote n) {
        CreditChangeEvent event = CreditChangeEvent.newBuilder()
                .setEventId(n.eventId())
                .setChangeType(n.changeType())
                .setTier(1)
                .setEntityType(n.aggregateType())
                .setEntityKey(n.aggregateKey())
                .setEntityVersion(n.aggregateVersion())
                .setReasons(n.reasons() == null || n.reasons().isBlank() ? List.of() : Arrays.asList(n.reasons().split(",")))
                .setMaterialityRuleVersion(n.ruleVersion())
                .setSource(SourceRef.newBuilder().setSystem(n.sourceSystem()).setTopic(n.sourceTopic())
                        .setPartition(n.sourcePartition()).setOffset(n.sourceOffset()).setEventId(n.sourceEventId()).build())
                .setTraceId(n.traceId())
                .setOccurredAt(n.createdAt())
                .build();
        ProducerRecord<String, Object> rec = new ProducerRecord<>(props.getOutbox().getTopic(), n.aggregateKey(), event);
        // Same trace id at every step: source letter → ledger → outbox note → Credit Change event → CLM UI
        rec.headers().add(InboundRecord.HEADER_TRACEPARENT, ("00-" + n.traceId() + "-" + spanId(n.outboxId()) + "-01").getBytes(StandardCharsets.US_ASCII));
        rec.headers().add(InboundRecord.HEADER_TRACE_ID, n.traceId().getBytes(StandardCharsets.UTF_8));
        rec.headers().add("ioc-source-event-id", n.sourceEventId().getBytes(StandardCharsets.UTF_8));
        rec.headers().add("ioc-outbox-id", Long.toString(n.outboxId()).getBytes(StandardCharsets.UTF_8));
        return rec;
    }

    private static String spanId(long outboxId) {
        return String.format("%016x", outboxId);
    }

    private static String consumerOf(List<OutboxNote> notes, long id) {
        for (OutboxNote n : notes) {
            if (n.outboxId() == id) {
                return n.consumerName();
            }
        }
        return "unknown";
    }

    /** "If a note sits unsent for more than a few minutes, an alert fires." */
    @Scheduled(fixedDelayString = "${ioc.platform.outbox.stuck-check-ms:60000}")
    public void checkStuck() {
        try {
            oldestPending = outbox.oldestPendingAge(clock.instant());
            if (oldestPending.compareTo(props.getOutbox().getStuckAlertAfter()) > 0) {
                eventLog.alert("OUTBOX_STUCK", Map.of("oldestPendingSeconds", oldestPending.toSeconds(),
                        "ownedShards", leases.ownedShards().toString(), "instance", props.getInstanceId()));
            }
        } catch (RuntimeException e) {
            log.warn("Outbox stuck-check failed: {}", e.getMessage());
        }
    }
}
