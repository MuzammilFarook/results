package ie.aib.ioc.platform.core;

public enum ChangeKind {
    /** Created or updated — the event carries the full current state. */
    UPSERT,
    /** Deleted at source. Stored as a versioned tombstone so a late, older update can't resurrect it. */
    DELETE
}
