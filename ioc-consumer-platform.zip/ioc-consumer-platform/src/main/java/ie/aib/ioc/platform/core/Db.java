package ie.aib.ioc.platform.core;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Small JDBC helpers. All timestamps are stored as UTC in DATETIME2 (never JVM-local time).
 */
public final class Db {

    /** SQL Server allows 2,100 parameters per statement; stay well below it for IN lists. */
    public static final int MAX_IN_LIST = 1000;

    private Db() {
    }

    public static LocalDateTime utc(Instant instant) {
        return instant == null ? null : LocalDateTime.ofInstant(instant, ZoneOffset.UTC);
    }

    public static Instant instant(ResultSet rs, String column) throws SQLException {
        LocalDateTime ldt = rs.getObject(column, LocalDateTime.class);
        return ldt == null ? null : ldt.toInstant(ZoneOffset.UTC);
    }

    public static Long nullableLong(ResultSet rs, String column) throws SQLException {
        long v = rs.getLong(column);
        return rs.wasNull() ? null : v;
    }

    public static Integer nullableInt(ResultSet rs, String column) throws SQLException {
        int v = rs.getInt(column);
        return rs.wasNull() ? null : v;
    }

    public static <T> List<List<T>> chunks(Collection<T> values, int size) {
        List<List<T>> out = new ArrayList<>();
        List<T> current = new ArrayList<>(size);
        for (T v : values) {
            current.add(v);
            if (current.size() == size) {
                out.add(current);
                current = new ArrayList<>(size);
            }
        }
        if (!current.isEmpty()) {
            out.add(current);
        }
        return out;
    }

    public static String truncate(String s, int max) {
        if (s == null || s.length() <= max) {
            return s;
        }
        return s.substring(0, max - 1) + "…";
    }
}
