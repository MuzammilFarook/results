package ie.aib.ioc.platform.core;

/**
 * The one terminal result every Kafka record ends with in the event ledger.
 * "Every offset consumed maps to exactly one ledger row with exactly one outcome."
 */
public enum Outcome {
    /** Applied to the IOC tables. */
    PROCESSED,
    /** Already applied before (same eventId, or same version + same content under a new eventId). */
    DUPLICATE,
    /** Older than what IOC already holds — ignored by the version guard. */
    STALE,
    /** A newer version of the same entity arrived in the same batch, so only that one was applied. */
    SUPERSEDED,
    /** Valid, but not something IOC needs (e.g. out-of-scope accounting system). */
    FILTERED,
    /** Could not be handled; sits in the failure tray. */
    FAILED,
    /** Failed earlier, handled later by an automatic or manual replay. */
    REPLAYED
}
