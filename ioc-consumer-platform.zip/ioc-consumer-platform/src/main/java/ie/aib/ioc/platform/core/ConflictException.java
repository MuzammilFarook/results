package ie.aib.ioc.platform.core;

/** Same source version, different content. A person has to decide which is right. */
public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
