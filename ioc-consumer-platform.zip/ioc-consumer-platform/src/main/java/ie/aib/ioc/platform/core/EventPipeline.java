package ie.aib.ioc.platform.core;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.BatchResult.FailureNotice;
import ie.aib.ioc.platform.core.BatchResult.ReplayNotice;
import ie.aib.ioc.platform.core.ErrorClassifier.ErrorClass;
import ie.aib.ioc.platform.core.ErrorClassifier.Phase;
import ie.aib.ioc.platform.core.InboundRecord.OffsetKey;
import ie.aib.ioc.platform.core.TopicHandler.AppliedChange;
import ie.aib.ioc.platform.core.TopicHandler.CurrentState;
import ie.aib.ioc.platform.failure.FailureModels.NewFailure;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.AvroPayloadDecoder;
import ie.aib.ioc.platform.ledger.LedgerEntry;
import ie.aib.ioc.platform.ledger.LedgerRepository;
import ie.aib.ioc.platform.ledger.LedgerRow;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.ConsumerStats.Counted;
import ie.aib.ioc.platform.observability.EventLog;
import ie.aib.ioc.platform.outbox.OutboxModels.NewOutboxNote;
import ie.aib.ioc.platform.outbox.OutboxRepository;
import ie.aib.ioc.platform.replay.BackoffSchedule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * The rule book, in code. For every record:
 *
 * <ol>
 *   <li><b>Read</b> the bytes; decode, map and validate (a bad letter is rejected, never thrown).</li>
 *   <li><b>Seen this offset before?</b> (Kafka redelivery) → already done, skip.</li>
 *   <li><b>Seen this eventId before?</b> → DUPLICATE.</li>
 *   <li><b>Several versions of the same entity in this batch?</b> → keep the newest, others SUPERSEDED.</li>
 *   <li><b>Older than what we have?</b> → STALE. Same version + same content → DUPLICATE. Same version,
 *       different content → CONFLICT (failure tray).</li>
 *   <li><b>Save together, in one transaction:</b> the change + one ledger line per record + an outbox
 *       note if the change matters.</li>
 *   <li>The caller <b>ticks off</b> (commits offsets) only after that transaction committed.</li>
 * </ol>
 *
 * If something goes wrong:
 * <ul>
 *   <li><b>Bad letter</b> → failure tray, carry on. In a batch, the bad one is found by bisecting
 *       (500 → 250 → 125 …) so the other 499 are saved normally.</li>
 *   <li><b>Temporary problem</b> → retry quickly (1s, 2s, 4s), then failure tray.</li>
 *   <li><b>System down</b> → {@link PlatformUnavailableException}: the consumer pauses; nothing goes to the tray.</li>
 * </ul>
 * Replays run through this exact class, so the "only apply if newer" rule protects them too.
 */
public final class EventPipeline<A, S> {

    private static final Logger log = LoggerFactory.getLogger(EventPipeline.class);

    private final TopicHandler<A, S> handler;
    private final ConsumerSettings settings;
    private final String consumer;
    private final AvroPayloadDecoder decoder;
    private final LedgerRepository ledger;
    private final FailureRepository failures;
    private final OutboxRepository outbox;
    private final TransactionTemplate tx;
    private final ErrorClassifier classifier;
    private final PlatformHealth health;
    private final ConsumerStats stats;
    private final EventLog eventLog;
    private final BackoffSchedule backoff;
    private final IocPlatformProperties props;
    private final Clock clock;
    private final ZoneId businessZone;
    private final Sleeper sleeper;

    public EventPipeline(TopicHandler<A, S> handler, Dependencies d) {
        this.handler = handler;
        this.settings = handler.settings();
        this.consumer = settings.consumerName();
        this.decoder = d.decoder();
        this.ledger = d.ledger();
        this.failures = d.failures();
        this.outbox = d.outbox();
        this.tx = d.tx();
        this.classifier = d.classifier();
        this.health = d.health();
        this.stats = d.stats();
        this.eventLog = d.eventLog();
        this.backoff = d.backoff();
        this.props = d.props();
        this.clock = d.clock();
        this.businessZone = ZoneId.of(d.props().getBusinessZone());
        this.sleeper = d.sleeper();
    }

    public String consumerName() {
        return consumer;
    }

    public ConsumerSettings settings() {
        return settings;
    }

    /**
     * Process records (a live poll batch, or replayed records). Returns when every record has a
     * committed outcome; throws {@link PlatformUnavailableException} (with how far it got) otherwise.
     */
    public BatchResult process(List<InboundRecord> records, ReplayContext ctx) {
        List<Item<S>> items = new ArrayList<>(records.size());
        for (int i = 0; i < records.size(); i++) {
            items.add(prepare(records.get(i), i));
        }
        Progress progress = new Progress();
        BatchResult result = new BatchResult();
        persistWithBisect(items, ctx, progress, result);
        return result;
    }

    // ===================================================================== 1. decode, map, validate

    private Item<S> prepare(InboundRecord rec, int index) {
        Item<S> item = new Item<>(index, rec);
        String headerTrace = rec.traceIdFromHeaders();
        Object decoded;
        try {
            decoded = decoder.decode(rec.topic(), rec.value());
        } catch (RuntimeException ex) {
            if (classifier.classify(ex) == ErrorClass.PLATFORM) {
                throw new PlatformUnavailableException("Schema Registry unavailable while decoding " + rec.offsetKey(), ex);
            }
            item.traceId = traceOf(headerTrace, null, rec);
            return item.reject(ex, FailureCategory.DESERIALISATION);
        }
        try {
            if (decoded == null) {
                throw new ValidationException("Null value (tombstone) is not part of the topic contract");
            }
            if (!handler.avroType().isInstance(decoded)) {
                throw new ValidationException("Expected " + handler.avroType().getName() + " but got " + decoded.getClass().getName());
            }
            item.event = handler.decode(handler.avroType().cast(decoded));
            item.traceId = traceOf(headerTrace, item.event.producerTraceId(), rec);
            handler.validate(item.event);
            item.stateHash = handler.stateHash(item.event);
            return item;
        } catch (RuntimeException ex) {
            if (item.traceId == null) {
                item.traceId = traceOf(headerTrace, null, rec);
            }
            return item.reject(ex, classifier.category(ex, Phase.MAP, ErrorClass.DATA));
        }
    }

    private static String traceOf(String header, String payload, InboundRecord rec) {
        String t = header != null && !header.isBlank() ? header : payload != null && !payload.isBlank() ? payload : rec.derivedTraceId();
        return Db.truncate(t, 64);
    }

    // ===================================================================== 2. transaction + bisect

    private void persistWithBisect(List<Item<S>> slice, ReplayContext ctx, Progress progress, BatchResult result) {
        List<Duration> retryBackoff = props.getTransientRetry().getBackoff();
        int attempt = 0;
        while (true) {
            try {
                BatchResult r = tx.execute(status -> persist(slice, ctx));
                progress.advanceTo(slice.get(slice.size() - 1).index + 1);
                afterCommit(r, ctx, slice.size());
                result.merge(r);
                return;
            } catch (PlatformUnavailableException p) {
                throw p.withCommittedUpTo(progress.committedUpTo);
            } catch (RuntimeException ex) {
                ErrorClass cls = classifier.classify(ex);
                if (cls == ErrorClass.PLATFORM) {
                    throw new PlatformUnavailableException("Platform unavailable: " + ex.getMessage(), ex, progress.committedUpTo);
                }
                if (cls == ErrorClass.TRANSIENT) {
                    if (attempt < retryBackoff.size()) {
                        stats.add(consumer, Counted.RETRIED, slice.size());
                        result.retried(slice.size());
                        sleep(retryBackoff.get(attempt++));
                        continue;
                    }
                    if (slice.size() > 1) {
                        // Transient errors that survive retries across a whole batch are systemic, not one bad letter.
                        throw new PlatformUnavailableException("Transient errors persisted across the batch", ex, progress.committedUpTo);
                    }
                    if (health.recordTransientExhaustion()) {
                        throw new PlatformUnavailableException("Repeated transient failures across records", ex, progress.committedUpTo);
                    }
                    recordFailure(slice.get(0), ex, FailureCategory.TRANSIENT_EXHAUSTED, ctx, progress, result);
                    return;
                }
                if (slice.size() == 1) {
                    recordFailure(slice.get(0), ex, classifier.category(ex, Phase.PERSIST, ErrorClass.DATA), ctx, progress, result);
                    return;
                }
                int mid = slice.size() / 2;
                log.info("Bisecting slice of {} after data error at {}: {}", slice.size(),
                        slice.get(0).rec.offsetKey(), ex.toString());
                persistWithBisect(slice.subList(0, mid), ctx, progress, result);
                persistWithBisect(slice.subList(mid, slice.size()), ctx, progress, result);
                return;
            }
        }
    }

    // ===================================================================== 3. the transaction body

    private BatchResult persist(List<Item<S>> slice, ReplayContext ctx) {
        Instant now = clock.instant();
        Writer w = new Writer(ctx, now);

        Map<OffsetKey, LedgerEntry.Ref> existing = ledger.findByOffsets(consumer, slice.stream().map(i -> i.rec.offsetKey()).toList());
        Set<String> eventIds = new HashSet<>();
        for (Item<S> it : slice) {
            if (!it.rejected()) {
                eventIds.add(it.event.eventId());
            }
        }
        Set<String> alreadyDone = eventIds.isEmpty() || ctx.reprocess() ? Set.of() : ledger.findCompletedEventIds(consumer, eventIds);

        // --- dedup by offset and by eventId; rejects; filter
        Set<String> seenInSlice = new HashSet<>();
        List<Item<S>> candidates = new ArrayList<>();
        for (Item<S> it : slice) {
            it.existing = existing.get(it.rec.offsetKey());
            if (it.existing != null && ctx.mode() == ProcessingMode.LIVE) {
                w.result.markRedelivered(); // committed earlier; Kafka handed it over again after a crash/rebalance
                continue;
            }
            if (it.rejected()) {
                w.fail(it, it.rejectionCategory, it.rejection);
                continue;
            }
            String eid = it.event.eventId();
            if (!seenInSlice.add(eid)) {
                w.done(it, Outcome.DUPLICATE, "eventId repeated within the same batch", false);
                continue;
            }
            if (alreadyDone.contains(eid)) {
                w.done(it, Outcome.DUPLICATE, "eventId already processed", false);
                continue;
            }
            Optional<String> filtered = handler.filterReason(it.event);
            if (filtered.isPresent()) {
                w.done(it, Outcome.FILTERED, filtered.get(), false);
                continue;
            }
            candidates.add(it);
        }

        // --- skip the in-between versions: per entity, only the newest in this batch is applied
        Map<String, Item<S>> winners = new LinkedHashMap<>();
        for (Item<S> c : candidates) {
            String key = c.event.entityKey();
            Item<S> best = winners.get(key);
            if (best == null) {
                winners.put(key, c);
                continue;
            }
            int cmp = Long.compare(c.event.sourceVersion(), best.event.sourceVersion());
            if (cmp > 0) {
                w.done(best, Outcome.SUPERSEDED, "v" + best.event.sourceVersion() + " superseded in batch by v"
                        + c.event.sourceVersion() + " (offset " + c.rec.offset() + ")", false);
                winners.put(key, c);
            } else if (cmp < 0) {
                w.done(c, Outcome.SUPERSEDED, "v" + c.event.sourceVersion() + " older than v" + best.event.sourceVersion()
                        + " in the same batch (offset " + best.rec.offset() + ")", false);
            } else if (Arrays.equals(c.stateHash, best.stateHash)) {
                w.done(c, Outcome.DUPLICATE, "same version and content as offset " + best.rec.offset() + " in this batch", false);
            } else {
                w.fail(c, FailureCategory.CONFLICT, new ConflictException("v" + c.event.sourceVersion()
                        + " appears twice in the batch with different content (other offset " + best.rec.offset() + ")"));
            }
        }

        // --- version guard against stored state ("only apply if newer")
        Map<String, CurrentState<S>> current = winners.isEmpty() ? Map.of() : handler.lockAndLoad(winners.keySet());
        List<AppliedChange<S>> toApply = new ArrayList<>();
        List<Item<S>> applyItems = new ArrayList<>();
        for (Item<S> it : winners.values()) {
            CurrentState<S> cur = current.get(it.event.entityKey());
            it.before = cur;
            if (cur == null) {
                toApply.add(new AppliedChange<>(it.event, it.rec, it.traceId, true));
                applyItems.add(it);
                continue;
            }
            long in = it.event.sourceVersion();
            long stored = cur.sourceVersion();
            boolean sameContent = Arrays.equals(it.stateHash, cur.stateHash());
            if (in > stored || (in == stored && ctx.reprocess() && !sameContent)) {
                toApply.add(new AppliedChange<>(it.event, it.rec, it.traceId, false));
                applyItems.add(it);
            } else if (in == stored && sameContent) {
                w.done(it, Outcome.DUPLICATE, "v" + in + " already applied with identical content", false);
            } else if (in == stored) {
                w.fail(it, FailureCategory.CONFLICT, new ConflictException("Stored v" + stored
                        + " has different content from incoming v" + in));
            } else {
                w.done(it, Outcome.STALE, "incoming v" + in + " is older than stored v" + stored, false);
            }
        }
        if (!toApply.isEmpty()) {
            handler.apply(toApply);
        }

        // --- materiality → outbox note in the same transaction
        List<NewOutboxNote> notes = new ArrayList<>();
        for (int i = 0; i < toApply.size(); i++) {
            Item<S> it = applyItems.get(i);
            Materiality m = handler.assessMateriality(it.before, it.event);
            String detail = (it.event.kind() == ChangeKind.DELETE ? "deleted" : it.before == null ? "created" : "applied")
                    + " v" + it.event.sourceVersion()
                    + (it.before == null ? "" : " (was v" + it.before.sourceVersion() + ")");
            if (m.material()) {
                notes.add(note(it, m));
                w.result.markMaterial();
                detail += " · announced: " + String.join(",", m.reasons());
            }
            w.done(it, Outcome.PROCESSED, detail, m.material());
        }
        outbox.insertBatch(notes, now);
        ledger.insertBatch(w.newRows);
        return w.result;
    }

    private NewOutboxNote note(Item<S> it, Materiality m) {
        DecodedEvent<S> ev = it.event;
        int shard = Math.floorMod(ev.entityKey().hashCode(), props.getOutbox().getShards()); // String.hashCode is stable across JVMs
        return new NewOutboxNote(UUID.randomUUID().toString(), shard, settings.entityType(), ev.entityKey(),
                ev.sourceVersion(), m.changeType(), String.join(",", m.reasons()), settings.materialityRuleVersion(),
                consumer, ev.sourceSystem(), it.rec.topic(), it.rec.partition(), it.rec.offset(), ev.eventId(), it.traceId);
    }

    // ===================================================================== 4. single-record failure (own transaction)

    private void recordFailure(Item<S> it, Throwable ex, FailureCategory category, ReplayContext ctx,
                               Progress progress, BatchResult result) {
        BatchResult r;
        try {
            r = tx.execute(status -> {
                Writer w = new Writer(ctx, clock.instant());
                it.existing = ledger.findByOffsets(consumer, List.of(it.rec.offsetKey())).get(it.rec.offsetKey());
                w.fail(it, category, ex);
                ledger.insertBatch(w.newRows);
                return w.result;
            });
        } catch (RuntimeException writeError) {
            // We could not even put it in the tray. Never skip a record silently: stop and wait.
            eventLog.alert("FAILURE_TRAY_WRITE_FAILED", Map.of("consumer", consumer, "record", it.rec.offsetKey().toString(),
                    "error", String.valueOf(writeError.getMessage())));
            throw new PlatformUnavailableException("Could not write to the failure tray", writeError, progress.committedUpTo);
        }
        progress.advanceTo(it.index + 1);
        afterCommit(r, ctx, 1);
        result.merge(r);
    }

    // ===================================================================== 5. after commit: counts + Splunk lines

    private void afterCommit(BatchResult r, ReplayContext ctx, int sliceSize) {
        if (ctx.mode() == ProcessingMode.LIVE) {
            r.consumed(sliceSize);
            stats.add(consumer, Counted.CONSUMED, sliceSize);
        }
        r.counts().forEach((outcome, n) -> {
            // A replay that fails again is a retry, not a new failure: keeps "consumed = sum of outcomes" true.
            Counted what = outcome == Outcome.FAILED && ctx.mode().isReplay() ? Counted.RETRIED : Counted.valueOf(outcome.name());
            stats.add(consumer, what, n);
        });
        stats.add(consumer, Counted.REDELIVERED, r.redelivered());
        stats.add(consumer, Counted.MATERIAL, r.material());
        for (FailureNotice f : r.failures()) {
            eventLog.failed(consumer, f.topic(), f.partition(), f.offset(), f.eventId(), f.entityKey(), f.traceId(),
                    f.category().name(), f.errorClass(), f.message(), f.attempt(), f.failureId(), ctx.mode().name());
        }
        for (ReplayNotice n : r.replays()) {
            eventLog.replayed(consumer, n.topic(), n.partition(), n.offset(), n.eventId(), n.entityKey(), n.traceId(),
                    n.result().name(), ctx.mode().name(), ctx.actor(), n.failureId(), ctx.replayRequestId());
        }
    }

    // ===================================================================== helpers

    /** Collects the writes of one transaction and applies the replay rules to each outcome. */
    private final class Writer {
        final ReplayContext ctx;
        final Instant now;
        final BatchResult result = new BatchResult();
        final List<LedgerRow> newRows = new ArrayList<>();

        Writer(ReplayContext ctx, Instant now) {
            this.ctx = ctx;
            this.now = now;
        }

        /** The record reached a non-failure outcome. */
        void done(Item<S> it, Outcome outcome, String detail, boolean material) {
            LedgerEntry.Ref ex = it.existing;
            if (ex == null) {
                newRows.add(row(it, outcome, detail, material));
                result.count(outcome);
                return;
            }
            Outcome previous = Outcome.valueOf(ex.outcome());
            if (previous == Outcome.FAILED) {
                // Failed earlier, handled now → REPLAYED, remembering what the replay actually did.
                String d = "replay result " + outcome + ": " + detail;
                ledger.changeOutcome(ex.ledgerId(), previous, Outcome.REPLAYED, d, ctx.mode(), ctx.actor(),
                        ctx.replayRequestId(), now, material);
                Long failureId = failures.findIdByOffset(consumer, it.rec.offsetKey()).orElse(null);
                if (failureId != null) {
                    failures.markReplayed(failureId, ctx.mode(), ctx.actor(), ctx.replayRequestId(), outcome.name(), now);
                }
                result.count(Outcome.REPLAYED);
                result.replay(new ReplayNotice(it.rec.topic(), it.rec.partition(), it.rec.offset(), it.eventId(),
                        it.entityKey(), it.traceId, outcome, detail, failureId));
            } else {
                // A Kafka re-read of something already handled: never rewrite history, just note it.
                ledger.insertTransition(ex.ledgerId(), previous, previous, "re-read result " + outcome + ": " + detail,
                        ctx.mode(), ctx.actor(), ctx.replayRequestId(), now);
            }
        }

        /** The record goes to (or stays in) the failure tray. */
        void fail(Item<S> it, FailureCategory category, Throwable error) {
            String errorClass = error.getClass().getName();
            String message = rootMessage(error);
            long failureId;
            int attempt;
            String nextStatus;
            Optional<Long> inTray = ctx.mode().isReplay()
                    ? failures.findIdByOffset(consumer, it.rec.offsetKey()) : Optional.empty();
            if (inTray.isPresent()) {
                failureId = inTray.get();
                attempt = failures.attemptCount(failureId) + 1;
                BackoffSchedule.Decision d = backoff.next(category, attempt, ctx.mode(), now);
                failures.markAttemptFailed(failureId, category, errorClass, message, d.status(), d.nextAttemptAt(),
                        ctx.mode(), ctx.actor(), ctx.replayRequestId(), now);
                nextStatus = d.status();
            } else {
                attempt = 1;
                BackoffSchedule.Decision d = backoff.next(category, attempt, ctx.mode(), now);
                failureId = failures.insert(new NewFailure(consumer, it.rec.topic(), it.rec.partition(), it.rec.offset(),
                        it.rec.kafkaTimestamp(), it.eventId(), it.entityKey(), it.version(), it.rec.schemaId(),
                        it.rec.key(), it.rec.headers(), it.rec.value(), it.traceId, category, errorClass, message),
                        d.status(), d.nextAttemptAt(), ctx.mode(), ctx.actor(), ctx.replayRequestId(), now);
                nextStatus = d.status();
            }
            LedgerEntry.Ref ex = it.existing;
            String detail = category + ": " + message;
            if (ex == null) {
                newRows.add(row(it, Outcome.FAILED, detail, false));
            } else if (!Outcome.FAILED.name().equals(ex.outcome())) {
                Outcome prev = Outcome.valueOf(ex.outcome());
                ledger.insertTransition(ex.ledgerId(), prev, prev, "re-read failed (failure " + failureId + "): " + detail,
                        ctx.mode(), ctx.actor(), ctx.replayRequestId(), now);
            }
            result.count(Outcome.FAILED);
            result.failure(new FailureNotice(it.rec.topic(), it.rec.partition(), it.rec.offset(), it.eventId(),
                    it.entityKey(), it.traceId, category, errorClass, message, failureId, attempt, nextStatus));
        }

        private LedgerRow row(Item<S> it, Outcome outcome, String detail, boolean material) {
            Instant ts = it.rec.kafkaTimestamp() != null ? it.rec.kafkaTimestamp() : it.rec.receivedAt();
            byte[] payload = settings.evidenceLevel() == EvidenceLevel.FULL ? it.rec.value() : null;
            return new LedgerRow(consumer, it.rec.topic(), it.rec.partition(), it.rec.offset(), it.rec.kafkaTimestamp(),
                    it.eventId(), it.entityKey(), it.version(), it.rec.schemaId(), it.rec.payloadSha256(), payload,
                    it.traceId, outcome, detail, material, ctx.mode(), props.getInstanceId(),
                    LocalDate.ofInstant(ts, businessZone), it.rec.receivedAt(), now);
        }
    }

    private void sleep(Duration d) {
        try {
            sleeper.sleep(d);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PlatformUnavailableException("Interrupted during retry backoff (shutting down)", e);
        }
    }

    private static String rootMessage(Throwable t) {
        Throwable root = t;
        while (root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }
        String msg = root == t ? String.valueOf(t.getMessage()) : t.getMessage() + " | root: " + root;
        return Db.truncate(msg, 2000);
    }

    /** One record moving through the pipeline. */
    static final class Item<S> {
        final int index;
        final InboundRecord rec;
        String traceId;
        DecodedEvent<S> event;
        byte[] stateHash;
        Throwable rejection;
        FailureCategory rejectionCategory;
        LedgerEntry.Ref existing;
        CurrentState<S> before;

        Item(int index, InboundRecord rec) {
            this.index = index;
            this.rec = rec;
        }

        Item<S> reject(Throwable ex, FailureCategory category) {
            this.rejection = ex;
            this.rejectionCategory = category;
            return this;
        }

        boolean rejected() { return rejection != null; }
        String eventId() { return event == null ? null : Db.truncate(event.eventId(), 100); }
        String entityKey() { return event == null ? null : event.entityKey(); }
        Long version() { return event == null ? null : event.sourceVersion(); }
    }

    private static final class Progress {
        int committedUpTo;

        void advanceTo(int index) {
            committedUpTo = Math.max(committedUpTo, index);
        }
    }

    @FunctionalInterface
    public interface Sleeper {
        void sleep(Duration d) throws InterruptedException;

        Sleeper REAL = d -> Thread.sleep(d.toMillis());
    }

    /** Everything the pipeline needs from the platform. */
    public record Dependencies(AvroPayloadDecoder decoder, LedgerRepository ledger, FailureRepository failures,
                               OutboxRepository outbox, TransactionTemplate tx, ErrorClassifier classifier,
                               PlatformHealth health, ConsumerStats stats, EventLog eventLog, BackoffSchedule backoff,
                               IocPlatformProperties props, Clock clock, Sleeper sleeper) {
    }
}
