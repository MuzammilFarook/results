package ie.aib.ioc.platform.core;

/**
 * Something this event needs has not arrived yet (e.g. a covenant before its CCV).
 * Goes to the failure tray as DEPENDENCY_MISSING and is retried automatically with backoff.
 * (Tier 1 account events have no such dependency; Tier 2 linkage consumers will use this.)
 */
public class DependencyMissingException extends RuntimeException {
    public DependencyMissingException(String message) {
        super(message);
    }
}
