package ie.aib.ioc.platform.core;

/** The event breaks the topic contract. Goes to the failure tray as VALIDATION; not auto-retried. */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) {
        super(message);
    }
}
