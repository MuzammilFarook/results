package ie.aib.ioc.platform.kafka;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import ie.aib.ioc.platform.core.BatchResult;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.InboundRecord;
import ie.aib.ioc.platform.core.PlatformHealth;
import ie.aib.ioc.platform.core.PlatformUnavailableException;
import ie.aib.ioc.platform.core.ReplayContext;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.EventLog;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.support.Acknowledgment;

/**
 * The bridge between a {@code @KafkaListener} batch and the pipeline. It owns the "tick off" rule:
 *
 * <ul>
 *   <li>Batch committed in the DB → {@code ack.acknowledge()} — offsets committed only now.</li>
 *   <li>Platform down → {@code ack.nack(i, backoff)}: offsets before {@code i} (already committed by
 *       bisect) are ticked off, the rest are redelivered after the pause. The container is paused
 *       during the sleep, so the consumer keeps its partitions (no rebalance storm) and nothing
 *       goes to the failure tray.</li>
 *   <li>Anything unexpected (a bug) → nack the whole batch. Never skip a record silently;
 *       lag and the alert make the problem visible instead.</li>
 * </ul>
 */
public class ConsumerRuntime {

    private final EventPipeline<?, ?> pipeline;
    private final PlatformHealth health;
    private final ConsumerStats stats;
    private final EventLog eventLog;
    private final Clock clock;

    public ConsumerRuntime(EventPipeline<?, ?> pipeline, PlatformHealth health, ConsumerStats stats,
                           EventLog eventLog, Clock clock) {
        this.pipeline = pipeline;
        this.health = health;
        this.stats = stats;
        this.eventLog = eventLog;
        this.clock = clock;
    }

    public String consumerName() {
        return pipeline.consumerName();
    }

    public void onBatch(List<ConsumerRecord<byte[], byte[]>> records, Acknowledgment ack) {
        if (records.isEmpty()) {
            return;
        }
        long start = System.nanoTime();
        Instant receivedAt = clock.instant();
        List<InboundRecord> inbound = new ArrayList<>(records.size());
        for (ConsumerRecord<byte[], byte[]> r : records) {
            inbound.add(InboundRecord.from(r, receivedAt));
        }
        try {
            BatchResult result = pipeline.process(inbound, ReplayContext.LIVE);
            ack.acknowledge();
            if (health.markUp()) {
                eventLog.lifecycle("consumer.resumed", Map.of("consumer", consumerName()));
            }
            stats.batchDuration(consumerName(), (System.nanoTime() - start) / 1_000_000, records.size());
            if (result.consumed() != records.size()) {
                eventLog.alert("BATCH_COUNT_MISMATCH", Map.of("consumer", consumerName(),
                        "polled", records.size(), "accounted", result.consumed()));
            }
        } catch (PlatformUnavailableException e) {
            pauseAndRedeliver(records, ack, e.committedUpTo(), e);
        } catch (RuntimeException e) {
            eventLog.alert("CONSUMER_UNEXPECTED_ERROR", Map.of("consumer", consumerName(),
                    "error", e.getClass().getName() + ": " + e.getMessage(),
                    "firstOffset", inbound.get(0).offsetKey().toString()));
            pauseAndRedeliver(records, ack, 0, e);
        }
    }

    private void pauseAndRedeliver(List<ConsumerRecord<byte[], byte[]>> records, Acknowledgment ack,
                                   int committedUpTo, Throwable cause) {
        Duration backoff = health.markDown(cause);
        stats.paused(consumerName(), backoff.toMillis());
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("consumer", consumerName());
        fields.put("reason", health.reason());
        fields.put("backoffMs", backoff.toMillis());
        fields.put("downSince", String.valueOf(health.downSince()));
        fields.put("committedInBatch", committedUpTo);
        fields.put("redeliverFrom", committedUpTo < records.size() ? records.get(committedUpTo).topic() + "/"
                + records.get(committedUpTo).partition() + "@" + records.get(committedUpTo).offset() : "none");
        eventLog.lifecycle("consumer.paused", fields);
        if (committedUpTo >= records.size()) {
            ack.acknowledge();
        } else {
            ack.nack(committedUpTo, backoff);
        }
    }
}
