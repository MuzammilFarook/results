package ie.aib.ioc.platform.core;

/**
 * Per-topic settings a handler declares.
 *
 * @param consumerName           stable name; also the Kafka listener id and the key every table is scoped by
 * @param topic                  the inbound topic (used by gap checks, reconciliation and Kafka re-reads)
 * @param entityType             e.g. ACCOUNT — used in Credit Change events
 * @param evidenceLevel          FULL (keep payload in ledger) or METADATA (fingerprint only)
 * @param materialityRuleVersion recorded on every announcement, so "why was this announced?" is answerable later
 */
public record ConsumerSettings(
        String consumerName,
        String topic,
        String entityType,
        EvidenceLevel evidenceLevel,
        String materialityRuleVersion) {
}
