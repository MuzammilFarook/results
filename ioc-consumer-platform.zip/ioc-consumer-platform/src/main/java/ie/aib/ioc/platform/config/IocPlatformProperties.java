package ie.aib.ioc.platform.config;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All platform tunables, under {@code ioc.platform.*}. Defaults follow the consumer design doc.
 */
@ConfigurationProperties(prefix = "ioc.platform")
public class IocPlatformProperties {

    /** Unique per pod. Defaults to HOSTNAME (the pod name on AKS). */
    private String instanceId = System.getenv().getOrDefault("HOSTNAME", "local-instance");
    /** Business day boundary for control totals. */
    private String businessZone = "Europe/Dublin";

    private final TransientRetry transientRetry = new TransientRetry();
    private final Pause pause = new Pause();
    private final AutoReplay autoReplay = new AutoReplay();
    private final ManualReplay manualReplay = new ManualReplay();
    private final Outbox outbox = new Outbox();
    private final GapCheck gapCheck = new GapCheck();
    private final Reconciliation reconciliation = new Reconciliation();

    /** "Temporary problem → try 3 times quickly, then failure tray." */
    public static class TransientRetry {
        private List<Duration> backoff = new ArrayList<>(List.of(Duration.ofSeconds(1), Duration.ofSeconds(2), Duration.ofSeconds(4)));
        /** This many single records exhausting retries within the window ⇒ treat it as the platform being down. */
        private int escalateAfter = 5;
        private Duration escalationWindow = Duration.ofMinutes(1);

        public List<Duration> getBackoff() { return backoff; }
        public void setBackoff(List<Duration> backoff) { this.backoff = backoff; }
        public int getEscalateAfter() { return escalateAfter; }
        public void setEscalateAfter(int escalateAfter) { this.escalateAfter = escalateAfter; }
        public Duration getEscalationWindow() { return escalationWindow; }
        public void setEscalationWindow(Duration escalationWindow) { this.escalationWindow = escalationWindow; }
    }

    /** "Database down → the clerk stops and waits." Backoff between probes while paused. */
    public static class Pause {
        private Duration initialBackoff = Duration.ofSeconds(1);
        private Duration maxBackoff = Duration.ofSeconds(30);

        public Duration getInitialBackoff() { return initialBackoff; }
        public void setInitialBackoff(Duration initialBackoff) { this.initialBackoff = initialBackoff; }
        public Duration getMaxBackoff() { return maxBackoff; }
        public void setMaxBackoff(Duration maxBackoff) { this.maxBackoff = maxBackoff; }
    }

    /** "Retries get further apart: 1m, 5m, 15m, 1h, 4h. After that, a person looks at it." */
    public static class AutoReplay {
        private boolean enabled = true;
        /** Cadence of the replay timer (read by @Scheduled). */
        private long pollIntervalMs = 30_000;
        private int claimBatchSize = 50;
        private double ratePerSecond = 20;
        private Duration claimTimeout = Duration.ofMinutes(5);
        private List<Duration> schedule = new ArrayList<>(List.of(Duration.ofMinutes(1), Duration.ofMinutes(5),
                Duration.ofMinutes(15), Duration.ofHours(1), Duration.ofHours(4)));

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public long getPollIntervalMs() { return pollIntervalMs; }
        public void setPollIntervalMs(long pollIntervalMs) { this.pollIntervalMs = pollIntervalMs; }
        public int getClaimBatchSize() { return claimBatchSize; }
        public void setClaimBatchSize(int claimBatchSize) { this.claimBatchSize = claimBatchSize; }
        public double getRatePerSecond() { return ratePerSecond; }
        public void setRatePerSecond(double ratePerSecond) { this.ratePerSecond = ratePerSecond; }
        public Duration getClaimTimeout() { return claimTimeout; }
        public void setClaimTimeout(Duration claimTimeout) { this.claimTimeout = claimTimeout; }
        public List<Duration> getSchedule() { return schedule; }
        public void setSchedule(List<Duration> schedule) { this.schedule = schedule; }
    }

    /** Manual replay safety rules: count first, second person for big replays, replay slowly, audit. */
    public static class ManualReplay {
        /** Bulk replays affecting more than this many records need a second person to approve. */
        private long approvalThreshold = 100;
        private double ratePerSecond = 50;
        /** Cadence of the bulk replay executor (read by @Scheduled). */
        private long executorPollMs = 10_000;
        private int kafkaRereadChunk = 200;

        public long getApprovalThreshold() { return approvalThreshold; }
        public void setApprovalThreshold(long approvalThreshold) { this.approvalThreshold = approvalThreshold; }
        public double getRatePerSecond() { return ratePerSecond; }
        public void setRatePerSecond(double ratePerSecond) { this.ratePerSecond = ratePerSecond; }
        public long getExecutorPollMs() { return executorPollMs; }
        public void setExecutorPollMs(long executorPollMs) { this.executorPollMs = executorPollMs; }
        public int getKafkaRereadChunk() { return kafkaRereadChunk; }
        public void setKafkaRereadChunk(int kafkaRereadChunk) { this.kafkaRereadChunk = kafkaRereadChunk; }
    }

    /** The postman. */
    public static class Outbox {
        private boolean publisherEnabled = true;
        private String topic = "ioc.credit.change.v1";
        private int shards = 16;
        private Duration leaseDuration = Duration.ofSeconds(30);
        /** Postman cadence and lease renewal cadence (read by @Scheduled). */
        private long pollIntervalMs = 500;
        private long leaseRenewMs = 5_000;
        private int batchSize = 500;
        private Duration sendTimeout = Duration.ofSeconds(30);
        /** "If a note sits unsent for more than a few minutes, an alert fires." */
        private Duration stuckAlertAfter = Duration.ofMinutes(5);

        public boolean isPublisherEnabled() { return publisherEnabled; }
        public void setPublisherEnabled(boolean publisherEnabled) { this.publisherEnabled = publisherEnabled; }
        public String getTopic() { return topic; }
        public void setTopic(String topic) { this.topic = topic; }
        public int getShards() { return shards; }
        public void setShards(int shards) { this.shards = shards; }
        public Duration getLeaseDuration() { return leaseDuration; }
        public void setLeaseDuration(Duration leaseDuration) { this.leaseDuration = leaseDuration; }
        public long getPollIntervalMs() { return pollIntervalMs; }
        public void setPollIntervalMs(long pollIntervalMs) { this.pollIntervalMs = pollIntervalMs; }
        public long getLeaseRenewMs() { return leaseRenewMs; }
        public void setLeaseRenewMs(long leaseRenewMs) { this.leaseRenewMs = leaseRenewMs; }
        public int getBatchSize() { return batchSize; }
        public void setBatchSize(int batchSize) { this.batchSize = batchSize; }
        public Duration getSendTimeout() { return sendTimeout; }
        public void setSendTimeout(Duration sendTimeout) { this.sendTimeout = sendTimeout; }
        public Duration getStuckAlertAfter() { return stuckAlertAfter; }
        public void setStuckAlertAfter(Duration stuckAlertAfter) { this.stuckAlertAfter = stuckAlertAfter; }
    }

    /** "Spotting missing letters": per-partition offset continuity, checked during the day. */
    public static class GapCheck {
        private boolean enabled = true;
        private long intervalMs = 300_000;
        /** Verify each gap against Kafka: offsets with no data records (txn markers, compaction) are auto-explained. */
        private boolean verifyAgainstKafka = true;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public long getIntervalMs() { return intervalMs; }
        public void setIntervalMs(long intervalMs) { this.intervalMs = intervalMs; }
        public boolean isVerifyAgainstKafka() { return verifyAgainstKafka; }
        public void setVerifyAgainstKafka(boolean verifyAgainstKafka) { this.verifyAgainstKafka = verifyAgainstKafka; }
    }

    /** "SecDB says 1,204; IOC says 1,204 → match." */
    public static class Reconciliation {
        private boolean enabled = true;
        private String cron = "0 30 6 * * *";

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
        public String getCron() { return cron; }
        public void setCron(String cron) { this.cron = cron; }
    }

    public String getInstanceId() { return instanceId; }
    public void setInstanceId(String instanceId) { this.instanceId = instanceId; }
    public String getBusinessZone() { return businessZone; }
    public void setBusinessZone(String businessZone) { this.businessZone = businessZone; }
    public TransientRetry getTransientRetry() { return transientRetry; }
    public Pause getPause() { return pause; }
    public AutoReplay getAutoReplay() { return autoReplay; }
    public ManualReplay getManualReplay() { return manualReplay; }
    public Outbox getOutbox() { return outbox; }
    public GapCheck getGapCheck() { return gapCheck; }
    public Reconciliation getReconciliation() { return reconciliation; }
}
