package ie.aib.ioc.platform.ops;

import org.springframework.http.HttpStatus;

/** An ops action that can't be done, with the HTTP status the console should see. */
public class OpsException extends RuntimeException {

    private final HttpStatus status;

    public OpsException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus status() {
        return status;
    }

    public static OpsException notFound(String what) {
        return new OpsException(HttpStatus.NOT_FOUND, what + " not found");
    }

    public static OpsException conflict(String message) {
        return new OpsException(HttpStatus.CONFLICT, message);
    }

    public static OpsException badRequest(String message) {
        return new OpsException(HttpStatus.BAD_REQUEST, message);
    }

    public static OpsException forbidden(String message) {
        return new OpsException(HttpStatus.FORBIDDEN, message);
    }
}
