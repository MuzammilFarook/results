package ie.aib.ioc.platform.replay;

/**
 * "Replay slowly, not all at once — don't overload the database."
 * A minimal pacing limiter (one caller thread); good enough for replay, no extra dependency.
 */
public final class RateLimiter {

    private final long nanosPerPermit;
    private long next = System.nanoTime();

    public RateLimiter(double permitsPerSecond) {
        if (permitsPerSecond <= 0) {
            throw new IllegalArgumentException("permitsPerSecond must be > 0");
        }
        this.nanosPerPermit = (long) (1_000_000_000L / permitsPerSecond);
    }

    public void acquire(int permits) {
        long now = System.nanoTime();
        long wait = next - now;
        next = Math.max(next, now) + nanosPerPermit * permits;
        if (wait > 0) {
            try {
                Thread.sleep(wait / 1_000_000L, (int) (wait % 1_000_000L));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public void acquire() {
        acquire(1);
    }
}
