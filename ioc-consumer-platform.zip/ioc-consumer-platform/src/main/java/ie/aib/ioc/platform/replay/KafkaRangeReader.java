package ie.aib.ioc.platform.replay;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.consumer.OffsetAndTimestamp;
import org.apache.kafka.common.PartitionInfo;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.stereotype.Component;

/**
 * Reads an exact offset range straight from Kafka, outside the consumer group (assign + seek, no
 * commits). Used for "reprocess this window after a bug fix" and to verify offset gaps.
 * It never moves the live consumer group's offsets.
 */
@Component
public class KafkaRangeReader {

    private static final Duration POLL = Duration.ofMillis(500);
    private static final int MAX_EMPTY_POLLS = 10;

    private final ConsumerFactory<?, ?> consumerFactory;

    public KafkaRangeReader(ConsumerFactory<?, ?> consumerFactory) {
        this.consumerFactory = consumerFactory;
    }

    /** Resolve a request into exact per-partition ranges, and check they are still inside topic retention. */
    public Plan plan(String topic, Integer partition, Long fromOffset, Long toOffset, Instant fromTime, Instant toTime) {
        try (KafkaConsumer<byte[], byte[]> c = open()) {
            List<TopicPartition> tps = new ArrayList<>();
            if (partition != null) {
                tps.add(new TopicPartition(topic, partition));
            } else {
                for (PartitionInfo pi : c.partitionsFor(topic, Duration.ofSeconds(30))) {
                    tps.add(new TopicPartition(topic, pi.partition()));
                }
            }
            Map<TopicPartition, Long> begin = c.beginningOffsets(tps, Duration.ofSeconds(30));
            Map<TopicPartition, Long> end = c.endOffsets(tps, Duration.ofSeconds(30)); // exclusive
            Map<TopicPartition, OffsetAndTimestamp> startByTime = fromTime == null ? Map.of() : c.offsetsForTimes(times(tps, fromTime), Duration.ofSeconds(30));
            Map<TopicPartition, OffsetAndTimestamp> endByTime = toTime == null ? Map.of() : c.offsetsForTimes(times(tps, toTime), Duration.ofSeconds(30));

            List<PartitionRange> ranges = new ArrayList<>();
            List<String> warnings = new ArrayList<>();
            for (TopicPartition tp : tps) {
                long first = begin.get(tp);
                long lastExclusive = end.get(tp);
                long start = fromOffset != null ? fromOffset : fromTime != null
                        ? (startByTime.get(tp) == null ? lastExclusive : startByTime.get(tp).offset()) : first;
                long stopInclusive = toOffset != null ? toOffset : toTime != null
                        ? (endByTime.get(tp) == null ? lastExclusive - 1 : endByTime.get(tp).offset() - 1) : lastExclusive - 1;
                if (start < first) {
                    warnings.add("Partition " + tp.partition() + ": offsets " + start + "–" + (first - 1)
                            + " are no longer in Kafka (retention). Use the ledger archive for those.");
                    start = first;
                }
                stopInclusive = Math.min(stopInclusive, lastExclusive - 1);
                if (stopInclusive >= start) {
                    ranges.add(new PartitionRange(topic, tp.partition(), start, stopInclusive));
                }
            }
            long count = ranges.stream().mapToLong(r -> r.toInclusive() - r.from() + 1).sum();
            return new Plan(ranges, count, warnings);
        }
    }

    /** Stream a range in chunks to {@code sink}. Stops early if {@code cancelled} turns true. */
    public long read(PartitionRange range, int chunkSize, Consumer<List<ConsumerRecord<byte[], byte[]>>> sink,
                     BooleanSupplier cancelled) {
        long delivered = 0;
        try (KafkaConsumer<byte[], byte[]> c = open()) {
            TopicPartition tp = new TopicPartition(range.topic(), range.partition());
            c.assign(List.of(tp));
            c.seek(tp, range.from());
            List<ConsumerRecord<byte[], byte[]>> chunk = new ArrayList<>(chunkSize);
            int empty = 0;
            while (!cancelled.getAsBoolean() && c.position(tp) <= range.toInclusive() && empty < MAX_EMPTY_POLLS) {
                ConsumerRecords<byte[], byte[]> polled = c.poll(POLL);
                if (polled.isEmpty()) {
                    empty++;
                    continue;
                }
                empty = 0;
                for (ConsumerRecord<byte[], byte[]> r : polled.records(tp)) {
                    if (r.offset() > range.toInclusive()) {
                        break;
                    }
                    chunk.add(r);
                    if (chunk.size() >= chunkSize) {
                        sink.accept(chunk);
                        delivered += chunk.size();
                        chunk = new ArrayList<>(chunkSize);
                    }
                }
            }
            if (!chunk.isEmpty() && !cancelled.getAsBoolean()) {
                sink.accept(chunk);
                delivered += chunk.size();
            }
        }
        return delivered;
    }

    /** How many DATA records actually exist in [from, to]? 0 ⇒ the hole is transaction markers or compaction. */
    public long countDataRecords(String topic, int partition, long from, long toInclusive) {
        long[] n = {0};
        read(new PartitionRange(topic, partition, from, toInclusive), 500, chunk -> n[0] += chunk.size(), () -> false);
        return n[0];
    }

    public long earliestOffset(String topic, int partition) {
        try (KafkaConsumer<byte[], byte[]> c = open()) {
            TopicPartition tp = new TopicPartition(topic, partition);
            return c.beginningOffsets(List.of(tp), Duration.ofSeconds(30)).get(tp);
        }
    }

    private KafkaConsumer<byte[], byte[]> open() {
        Map<String, Object> cfg = new HashMap<>(consumerFactory.getConfigurationProperties());
        cfg.remove(ConsumerConfig.GROUP_ID_CONFIG);
        cfg.remove(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG);
        cfg.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        cfg.put(ConsumerConfig.CLIENT_ID_CONFIG, "ioc-range-reader-" + UUID.randomUUID());
        cfg.remove(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG);
        cfg.remove(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG);
        return new KafkaConsumer<>(cfg, new ByteArrayDeserializer(), new ByteArrayDeserializer());
    }

    private static Map<TopicPartition, Long> times(List<TopicPartition> tps, Instant t) {
        Map<TopicPartition, Long> m = new HashMap<>();
        tps.forEach(tp -> m.put(tp, t.toEpochMilli()));
        return m;
    }

    public record PartitionRange(String topic, int partition, long from, long toInclusive) {
    }

    public record Plan(List<PartitionRange> ranges, long count, List<String> warnings) {
    }
}
