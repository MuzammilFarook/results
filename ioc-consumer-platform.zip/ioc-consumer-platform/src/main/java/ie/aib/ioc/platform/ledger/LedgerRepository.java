package ie.aib.ioc.platform.ledger;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.InboundRecord.OffsetKey;
import ie.aib.ioc.platform.core.Outcome;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.core.ProcessingMode;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

/**
 * The event ledger: "one line per letter, saying what happened to it".
 *
 * <p>Write path is batched ({@code useBulkCopyForBatchInsert=true} on the JDBC URL turns the batch
 * insert into a TDS bulk copy on Azure SQL). Read path serves dedup, the ops console and reconciliation.
 */
@Repository
public class LedgerRepository {

    private static final String COLUMNS = """
            ledger_id, consumer_name, topic, kafka_partition, kafka_offset, kafka_timestamp, event_id, entity_key,
            source_version, schema_id, payload_sha256, trace_id, outcome, outcome_detail, material, processing_mode,
            instance_id, business_date, received_at, processed_at, last_changed_at""";

    private final NamedParameterJdbcTemplate jdbc;

    public LedgerRepository(NamedParameterJdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // ------------------------------------------------------------------ pipeline (write path)

    /** Which of these offsets already have a ledger line? (Kafka redelivery after a crash / rebalance.) */
    public Map<OffsetKey, LedgerEntry.Ref> findByOffsets(String consumer, Collection<OffsetKey> keys) {
        Map<OffsetKey, LedgerEntry.Ref> found = new HashMap<>();
        Map<String, List<OffsetKey>> byTopicPartition = keys.stream()
                .collect(Collectors.groupingBy(k -> k.topic() + "\u0000" + k.partition()));
        for (List<OffsetKey> group : byTopicPartition.values()) {
            OffsetKey first = group.get(0);
            long lo = group.stream().mapToLong(OffsetKey::offset).min().orElseThrow();
            long hi = group.stream().mapToLong(OffsetKey::offset).max().orElseThrow();
            Set<OffsetKey> wanted = new HashSet<>(group);
            jdbc.query("""
                    SELECT ledger_id, kafka_offset, outcome, trace_id FROM event_ledger
                    WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p AND kafka_offset BETWEEN :lo AND :hi
                    """, new MapSqlParameterSource().addValue("c", consumer).addValue("t", first.topic())
                    .addValue("p", first.partition()).addValue("lo", lo).addValue("hi", hi), rs -> {
                OffsetKey k = new OffsetKey(first.topic(), first.partition(), rs.getLong("kafka_offset"));
                if (wanted.contains(k)) {
                    found.put(k, new LedgerEntry.Ref(rs.getLong("ledger_id"), rs.getString("outcome"), rs.getString("trace_id")));
                }
            });
        }
        return found;
    }

    /** Event ids already handled (any outcome except FAILED) — producer retries / republish with the same id. */
    public Set<String> findCompletedEventIds(String consumer, Collection<String> eventIds) {
        Set<String> done = new HashSet<>();
        for (List<String> chunk : Db.chunks(new HashSet<>(eventIds), Db.MAX_IN_LIST)) {
            done.addAll(jdbc.queryForList("""
                    SELECT DISTINCT event_id FROM event_ledger
                    WHERE consumer_name = :c AND event_id IN (:ids) AND outcome <> 'FAILED'
                    """, new MapSqlParameterSource("c", consumer).addValue("ids", chunk), String.class));
        }
        return done;
    }

    public void insertBatch(List<LedgerRow> rows) {
        if (rows.isEmpty()) {
            return;
        }
        SqlParameterSource[] params = rows.stream().map(r -> new MapSqlParameterSource()
                .addValue("consumer", r.consumerName()).addValue("topic", r.topic())
                .addValue("partition", r.partition()).addValue("offset", r.offset())
                .addValue("kts", Db.utc(r.kafkaTimestamp())).addValue("eventId", r.eventId())
                .addValue("entityKey", r.entityKey()).addValue("version", r.sourceVersion())
                .addValue("schemaId", r.schemaId()).addValue("sha", r.payloadSha256())
                .addValue("payload", r.payload(), Types.VARBINARY).addValue("trace", r.traceId())
                .addValue("outcome", r.outcome().name()).addValue("detail", Db.truncate(r.outcomeDetail(), 400))
                .addValue("material", r.material()).addValue("mode", r.mode().name())
                .addValue("instance", r.instanceId()).addValue("bizDate", r.businessDate())
                .addValue("received", Db.utc(r.receivedAt())).addValue("processed", Db.utc(r.processedAt()))
        ).toArray(SqlParameterSource[]::new);
        jdbc.batchUpdate("""
                INSERT INTO event_ledger (consumer_name, topic, kafka_partition, kafka_offset, kafka_timestamp, event_id,
                    entity_key, source_version, schema_id, payload_sha256, payload, trace_id, outcome, outcome_detail, material,
                    processing_mode, instance_id, business_date, received_at, processed_at, last_changed_at)
                VALUES (:consumer, :topic, :partition, :offset, :kts, :eventId, :entityKey, :version, :schemaId, :sha,
                    :payload, :trace, :outcome, :detail, :material, :mode, :instance, :bizDate, :received, :processed, :processed)
                """, params);
    }

    /** Change the outcome of an existing line (e.g. FAILED → REPLAYED) and keep the history. */
    public void changeOutcome(long ledgerId, Outcome from, Outcome to, String detail, ProcessingMode mode,
                              String actor, Long requestId, Instant now, boolean material) {
        jdbc.update("""
                UPDATE event_ledger SET outcome = :to, outcome_detail = :detail, last_changed_at = :now,
                    material = CASE WHEN :material = 1 THEN 1 ELSE material END
                WHERE ledger_id = :id
                """, new MapSqlParameterSource("to", to.name()).addValue("detail", Db.truncate(detail, 400))
                .addValue("now", Db.utc(now)).addValue("id", ledgerId).addValue("material", material ? 1 : 0));
        insertTransition(ledgerId, from, to, detail, mode, actor, requestId, now);
    }

    /** Record that something happened to a line without changing its outcome (e.g. a re-read of a PROCESSED offset). */
    public void insertTransition(long ledgerId, Outcome from, Outcome to, String detail, ProcessingMode mode,
                                 String actor, Long requestId, Instant now) {
        jdbc.update("""
                INSERT INTO event_ledger_transition (ledger_id, from_outcome, to_outcome, detail, processing_mode, actor,
                    replay_request_id, changed_at)
                VALUES (:id, :from, :to, :detail, :mode, :actor, :req, :now)
                """, new MapSqlParameterSource("id", ledgerId).addValue("from", from.name()).addValue("to", to.name())
                .addValue("detail", Db.truncate(detail, 400)).addValue("mode", mode.name()).addValue("actor", actor)
                .addValue("req", requestId).addValue("now", Db.utc(now)));
    }

    // ------------------------------------------------------------------ ops console (read path)

    public Page<LedgerEntry> search(LedgerQuery q, int page, int size) {
        StringBuilder sql = new StringBuilder("SELECT " + COLUMNS + " FROM event_ledger WHERE consumer_name = :c");
        MapSqlParameterSource p = new MapSqlParameterSource("c", q.consumer());
        if (q.outcome() != null) { sql.append(" AND outcome = :outcome"); p.addValue("outcome", q.outcome()); }
        if (q.entityKey() != null) { sql.append(" AND entity_key = :ek"); p.addValue("ek", q.entityKey()); }
        if (q.eventId() != null) { sql.append(" AND event_id = :eid"); p.addValue("eid", q.eventId()); }
        if (q.traceId() != null) { sql.append(" AND trace_id = :tid"); p.addValue("tid", q.traceId()); }
        if (q.partition() != null) { sql.append(" AND kafka_partition = :part"); p.addValue("part", q.partition()); }
        if (q.offsetFrom() != null) { sql.append(" AND kafka_offset >= :ofrom"); p.addValue("ofrom", q.offsetFrom()); }
        if (q.offsetTo() != null) { sql.append(" AND kafka_offset <= :oto"); p.addValue("oto", q.offsetTo()); }
        if (q.from() != null) { sql.append(" AND received_at >= :from"); p.addValue("from", Db.utc(q.from())); }
        if (q.to() != null) { sql.append(" AND received_at < :to"); p.addValue("to", Db.utc(q.to())); }
        if (Boolean.TRUE.equals(q.materialOnly())) { sql.append(" AND material = 1"); }
        sql.append(" ORDER BY ledger_id DESC OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY");
        p.addValue("skip", page * size).addValue("take", size + 1);
        return Page.of(jdbc.query(sql.toString(), p, ENTRY_MAPPER), page, size);
    }

    /** Everything that matches an eventId, traceId, entity key or "topic/partition@offset" — the trace search. */
    public List<LedgerEntry> findForTrace(String consumer, String term) {
        MapSqlParameterSource p = new MapSqlParameterSource("c", consumer).addValue("term", term);
        OffsetKey ok = parseOffsetKey(term);
        if (ok != null) {
            p.addValue("t", ok.topic()).addValue("p", ok.partition()).addValue("o", ok.offset());
            return jdbc.query("SELECT " + COLUMNS + " FROM event_ledger WHERE consumer_name = :c AND topic = :t"
                    + " AND kafka_partition = :p AND kafka_offset = :o", p, ENTRY_MAPPER);
        }
        return jdbc.query("SELECT TOP (200) " + COLUMNS + " FROM event_ledger WHERE consumer_name = :c AND "
                + "(event_id = :term OR trace_id = :term OR entity_key = :term) ORDER BY ledger_id DESC", p, ENTRY_MAPPER);
    }

    public List<LedgerEntry.Transition> transitions(long ledgerId) {
        return jdbc.query("""
                SELECT transition_id, from_outcome, to_outcome, detail, processing_mode, actor, replay_request_id, changed_at
                FROM event_ledger_transition WHERE ledger_id = :id ORDER BY transition_id
                """, new MapSqlParameterSource("id", ledgerId), (rs, i) -> new LedgerEntry.Transition(
                rs.getLong("transition_id"), rs.getString("from_outcome"), rs.getString("to_outcome"),
                rs.getString("detail"), rs.getString("processing_mode"), rs.getString("actor"),
                Db.nullableLong(rs, "replay_request_id"), Db.instant(rs, "changed_at")));
    }

    /** Current outcome mix in a window (uses ix_ledger_received, which INCLUDEs outcome). */
    public Map<String, Long> outcomeCounts(String consumer, Instant from, Instant to) {
        Map<String, Long> out = new HashMap<>();
        jdbc.query("""
                SELECT outcome, COUNT_BIG(*) AS n FROM event_ledger
                WHERE consumer_name = :c AND received_at >= :from AND received_at < :to GROUP BY outcome
                """, new MapSqlParameterSource("c", consumer).addValue("from", Db.utc(from)).addValue("to", Db.utc(to)),
                rs -> { out.put(rs.getString("outcome"), rs.getLong("n")); });
        return out;
    }

    // ------------------------------------------------------------------ reconciliation

    public List<Integer> partitionsSeen(String consumer, String topic, Instant since) {
        return jdbc.queryForList("""
                SELECT DISTINCT kafka_partition FROM event_ledger
                WHERE consumer_name = :c AND topic = :t AND received_at >= :since
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("since", Db.utc(since)), Integer.class);
    }

    /** Offset holes after {@code fromOffset}: rows where the next offset is not offset+1. */
    public List<long[]> findGaps(String consumer, String topic, int partition, long fromOffset) {
        return jdbc.query("""
                SELECT kafka_offset, next_offset FROM (
                    SELECT kafka_offset, LEAD(kafka_offset) OVER (ORDER BY kafka_offset) AS next_offset
                    FROM event_ledger WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p AND kafka_offset >= :from
                ) x WHERE next_offset - kafka_offset > 1
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition)
                .addValue("from", fromOffset), (rs, i) -> new long[]{rs.getLong("kafka_offset") + 1, rs.getLong("next_offset") - 1});
    }

    public Long maxOffset(String consumer, String topic, int partition) {
        return jdbc.queryForObject("""
                SELECT MAX(kafka_offset) FROM event_ledger WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition), Long.class);
    }

    public Long minOffset(String consumer, String topic, int partition) {
        return jdbc.queryForObject("""
                SELECT MIN(kafka_offset) FROM event_ledger WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition), Long.class);
    }

    /** Distinct events received for a business day (producer retries of the same event count once). */
    public long countForBusinessDate(String consumer, String topic, LocalDate date) {
        Long n = jdbc.queryForObject("""
                SELECT COUNT(DISTINCT event_id) + SUM(CASE WHEN event_id IS NULL THEN 1 ELSE 0 END)
                FROM event_ledger WHERE consumer_name = :c AND topic = :t AND business_date = :d
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("d", date), Long.class);
        return n == null ? 0 : n;
    }

    public List<String> topicsSeen(String consumer, Instant since) {
        return jdbc.queryForList("""
                SELECT DISTINCT topic FROM event_ledger WHERE consumer_name = :c AND received_at >= :since
                """, new MapSqlParameterSource("c", consumer).addValue("since", Db.utc(since)), String.class);
    }

    // ------------------------------------------------------------------ helpers

    static OffsetKey parseOffsetKey(String term) {
        int slash = term.lastIndexOf('/');
        int at = term.lastIndexOf('@');
        if (slash <= 0 || at <= slash) {
            return null;
        }
        try {
            return new OffsetKey(term.substring(0, slash), Integer.parseInt(term.substring(slash + 1, at)),
                    Long.parseLong(term.substring(at + 1)));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static final RowMapper<LedgerEntry> ENTRY_MAPPER = LedgerRepository::mapEntry;

    private static LedgerEntry mapEntry(ResultSet rs, int i) throws SQLException {
        byte[] sha = rs.getBytes("payload_sha256");
        return new LedgerEntry(rs.getLong("ledger_id"), rs.getString("consumer_name"), rs.getString("topic"),
                rs.getInt("kafka_partition"), rs.getLong("kafka_offset"), Db.instant(rs, "kafka_timestamp"),
                rs.getString("event_id"), rs.getString("entity_key"), Db.nullableLong(rs, "source_version"),
                Db.nullableInt(rs, "schema_id"), sha == null ? null : HexFormat.of().formatHex(sha),
                rs.getString("trace_id"), rs.getString("outcome"), rs.getString("outcome_detail"),
                rs.getBoolean("material"), rs.getString("processing_mode"), rs.getString("instance_id"),
                rs.getObject("business_date", LocalDate.class), Db.instant(rs, "received_at"),
                Db.instant(rs, "processed_at"), Db.instant(rs, "last_changed_at"));
    }

    public record LedgerQuery(String consumer, String outcome, String entityKey, String eventId, String traceId,
                              Integer partition, Long offsetFrom, Long offsetTo, Instant from, Instant to,
                              Boolean materialOnly) {
    }
}
