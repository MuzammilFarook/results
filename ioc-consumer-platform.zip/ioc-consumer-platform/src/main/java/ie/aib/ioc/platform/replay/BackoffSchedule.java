package ie.aib.ioc.platform.replay;

import java.time.Duration;
import java.time.Instant;
import java.util.List;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.FailureCategory;
import ie.aib.ioc.platform.core.ProcessingMode;
import ie.aib.ioc.platform.failure.FailureRepository;
import org.springframework.stereotype.Component;

/**
 * Decides what happens to a failed record next.
 *
 * <pre>
 *   attempt 1 failed → retry in 1m      attempt 4 failed → retry in 1h
 *   attempt 2 failed → retry in 5m      attempt 5 failed → retry in 4h
 *   attempt 3 failed → retry in 15m     attempt 6 failed → MANUAL (a person looks at it)
 * </pre>
 * Broken letters (DESERIALISATION, VALIDATION, CONFLICT, UNKNOWN) go straight to MANUAL — they
 * would fail the same way every time. A failed MANUAL replay stays MANUAL.
 */
@Component
public class BackoffSchedule {

    private final IocPlatformProperties props;

    public BackoffSchedule(IocPlatformProperties props) {
        this.props = props;
    }

    public Decision next(FailureCategory category, int failuresSoFar, ProcessingMode mode, Instant now) {
        if (!category.autoRetry() || mode == ProcessingMode.MANUAL_REPLAY || mode == ProcessingMode.KAFKA_REREAD) {
            return new Decision(FailureRepository.MANUAL, null);
        }
        List<Duration> schedule = props.getAutoReplay().getSchedule();
        if (failuresSoFar < 1 || failuresSoFar > schedule.size()) {
            return new Decision(FailureRepository.MANUAL, null);
        }
        return new Decision(FailureRepository.AUTO_RETRY, now.plus(schedule.get(failuresSoFar - 1)));
    }

    public record Decision(String status, Instant nextAttemptAt) {
    }
}
