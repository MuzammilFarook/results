package ie.aib.ioc.platform.core;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.concurrent.atomic.AtomicLong;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

/**
 * Tracks whether the platform (DB / Schema Registry) is usable, and the pause backoff while it isn't.
 *
 * <p>Deliberately NOT wired into liveness/readiness probes: if Azure SQL is down, restarting pods
 * achieves nothing. Kafka holds the backlog; the consumer waits and resumes on its own.
 */
@Component
public class PlatformHealth {

    private final IocPlatformProperties props;
    private final Clock clock;

    private volatile boolean down;
    private volatile Instant downSince;
    private volatile String reason;
    private volatile Duration currentBackoff;
    private final AtomicLong pausedMillisTotal = new AtomicLong();
    private final Deque<Instant> transientExhaustions = new ArrayDeque<>();

    public PlatformHealth(IocPlatformProperties props, Clock clock, MeterRegistry registry) {
        this.props = props;
        this.clock = clock;
        this.currentBackoff = props.getPause().getInitialBackoff();
        Gauge.builder("ioc.consumer.platform.down", this, h -> h.down ? 1 : 0)
                .description("1 while the consumer is paused because the platform (DB / Schema Registry) is unavailable")
                .register(registry);
    }

    /** Marks the platform down and returns how long to pause before the next probe (exponential, capped). */
    public synchronized Duration markDown(Throwable cause) {
        Instant now = clock.instant();
        if (!down) {
            down = true;
            downSince = now;
            currentBackoff = props.getPause().getInitialBackoff();
        } else {
            Duration doubled = currentBackoff.multipliedBy(2);
            currentBackoff = doubled.compareTo(props.getPause().getMaxBackoff()) > 0 ? props.getPause().getMaxBackoff() : doubled;
        }
        reason = rootMessage(cause);
        pausedMillisTotal.addAndGet(currentBackoff.toMillis());
        return currentBackoff;
    }

    /** Returns true if this call changed the state from DOWN to UP. */
    public synchronized boolean markUp() {
        if (!down) {
            return false;
        }
        down = false;
        reason = null;
        currentBackoff = props.getPause().getInitialBackoff();
        return true;
    }

    /**
     * A single record exhausted its quick retries. If that keeps happening across records,
     * it is not one bad letter — the system is struggling. Returns true when we should escalate.
     */
    public synchronized boolean recordTransientExhaustion() {
        Instant now = clock.instant();
        Instant cutoff = now.minus(props.getTransientRetry().getEscalationWindow());
        transientExhaustions.addLast(now);
        while (!transientExhaustions.isEmpty() && transientExhaustions.peekFirst().isBefore(cutoff)) {
            transientExhaustions.pollFirst();
        }
        return transientExhaustions.size() >= props.getTransientRetry().getEscalateAfter();
    }

    public boolean isDown() { return down; }
    public Instant downSince() { return downSince; }
    public String reason() { return reason; }
    public Duration currentBackoff() { return currentBackoff; }
    public long pausedMillisTotal() { return pausedMillisTotal.get(); }

    private static String rootMessage(Throwable t) {
        Throwable root = t;
        while (root != null && root.getCause() != null && root.getCause() != root) {
            root = root.getCause();
        }
        return root == null ? "unknown" : root.getClass().getSimpleName() + ": " + root.getMessage();
    }
}
