package ie.aib.ioc.platform.core;

/**
 * Who is driving this run of the pipeline, and why — written to the ledger, the failure attempts
 * and the audit trail.
 *
 * @param reprocess re-derive state even when the stored version equals the incoming one (used after a
 *                  logic bug fix: same source version, corrected mapping). Older versions can still
 *                  NEVER overwrite newer ones.
 */
public record ReplayContext(ProcessingMode mode, String actor, Long replayRequestId, boolean reprocess) {

    public static final String SYSTEM = "system";
    public static final ReplayContext LIVE = new ReplayContext(ProcessingMode.LIVE, SYSTEM, null, false);
    public static final ReplayContext AUTO = new ReplayContext(ProcessingMode.AUTO_REPLAY, SYSTEM, null, false);

    public static ReplayContext manual(String actor, Long requestId) {
        return new ReplayContext(ProcessingMode.MANUAL_REPLAY, actor, requestId, false);
    }

    public static ReplayContext kafkaReread(String actor, Long requestId, boolean reprocess) {
        return new ReplayContext(ProcessingMode.KAFKA_REREAD, actor, requestId, reprocess);
    }
}
