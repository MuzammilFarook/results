package ie.aib.ioc.platform.observability;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import ie.aib.ioc.platform.ledger.LedgerRepository;
import ie.aib.ioc.platform.replay.KafkaRangeReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Proving nothing was lost.
 *
 * <ol>
 *   <li><b>Offset gaps (intraday)</b> — per partition, ledger offsets must run 4,810, 4,811, 4,812… A hole
 *       is checked against Kafka: if Kafka holds no data records there (transaction markers, compaction)
 *       it is auto-EXPLAINED; otherwise it stays OPEN and an alert fires.</li>
 *   <li><b>Control totals (EOD)</b> — "SecDB says: yesterday I sent 1,204. IOC says: I received 1,204 → match."
 *       The only check that proves nothing was lost BEFORE Kafka. Needs each source team to send their total.</li>
 * </ol>
 */
@Service
public class ReconciliationService {

    private static final Logger log = LoggerFactory.getLogger(ReconciliationService.class);

    private final PipelineRegistry registry;
    private final LedgerRepository ledger;
    private final KafkaRangeReader reader;
    private final NamedParameterJdbcTemplate jdbc;
    private final EventLog eventLog;
    private final IocPlatformProperties props;
    private final Clock clock;

    public ReconciliationService(PipelineRegistry registry, LedgerRepository ledger, KafkaRangeReader reader,
                                 NamedParameterJdbcTemplate jdbc, EventLog eventLog, IocPlatformProperties props, Clock clock) {
        this.registry = registry;
        this.ledger = ledger;
        this.reader = reader;
        this.jdbc = jdbc;
        this.eventLog = eventLog;
        this.props = props;
        this.clock = clock;
    }

    // ===================================================================== offset gaps

    @Scheduled(fixedDelayString = "${ioc.platform.gap-check.interval-ms:300000}", initialDelay = 60_000)
    public void checkGaps() {
        if (!props.getGapCheck().isEnabled()) {
            return;
        }
        for (EventPipeline<?, ?> p : registry.all()) {
            String consumer = p.consumerName();
            String topic = p.settings().topic();
            try {
                for (int partition : ledger.partitionsSeen(consumer, topic, clock.instant().minus(Duration.ofDays(2)))) {
                    checkPartition(consumer, topic, partition);
                }
            } catch (RuntimeException e) {
                log.warn("Gap check failed for {}: {}", consumer, e.getMessage());
            }
        }
    }

    private void checkPartition(String consumer, String topic, int partition) {
        Long checkpoint = jdbc.query("""
                SELECT checked_to_offset FROM gap_check_checkpoint WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition),
                rs -> rs.next() ? rs.getLong(1) : null);
        long from = checkpoint != null ? checkpoint : firstOffsetToCheck(consumer, topic, partition);
        Long max = ledger.maxOffset(consumer, topic, partition);
        if (max == null || max <= from) {
            return;
        }
        for (long[] gap : ledger.findGaps(consumer, topic, partition, from)) {
            recordGap(consumer, topic, partition, gap[0], gap[1]);
        }
        jdbc.update("""
                MERGE gap_check_checkpoint WITH (HOLDLOCK) AS t
                USING (SELECT :c AS consumer_name, :t AS topic, :p AS kafka_partition) AS s
                  ON t.consumer_name = s.consumer_name AND t.topic = s.topic AND t.kafka_partition = s.kafka_partition
                WHEN MATCHED THEN UPDATE SET checked_to_offset = :max, checked_at = :now
                WHEN NOT MATCHED THEN INSERT (consumer_name, topic, kafka_partition, checked_to_offset, checked_at)
                    VALUES (:c, :t, :p, :max, :now);
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition)
                .addValue("max", max).addValue("now", Db.utc(clock.instant())));
    }

    /** First run on a partition: start from the first offset the ledger has (earlier ones predate IOC). */
    private long firstOffsetToCheck(String consumer, String topic, int partition) {
        Long min = ledger.minOffset(consumer, topic, partition);
        return min == null ? 0 : min;
    }

    private void recordGap(String consumer, String topic, int partition, long from, long to) {
        String status = "OPEN";
        String note = null;
        if (props.getGapCheck().isVerifyAgainstKafka()) {
            try {
                long earliest = reader.earliestOffset(topic, partition);
                if (from < earliest) {
                    note = "Offsets before " + earliest + " are no longer in Kafka (retention) — cannot verify";
                } else {
                    long dataRecords = reader.countDataRecords(topic, partition, from, to);
                    if (dataRecords == 0) {
                        status = "EXPLAINED";
                        note = "Kafka holds no data records at these offsets (transaction markers / compaction)";
                    } else {
                        note = dataRecords + " data record(s) exist in Kafka but have no ledger line — create a KAFKA_RANGE replay";
                    }
                }
            } catch (RuntimeException e) {
                note = "Could not verify against Kafka: " + e.getMessage();
            }
        }
        int inserted = jdbc.update("""
                IF NOT EXISTS (SELECT 1 FROM offset_gap WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p AND from_offset = :from)
                INSERT INTO offset_gap (consumer_name, topic, kafka_partition, from_offset, to_offset, missing_count, status, note, detected_at)
                VALUES (:c, :t, :p, :from, :to, :n, :status, :note, :now)
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("p", partition)
                .addValue("from", from).addValue("to", to).addValue("n", to - from + 1).addValue("status", status)
                .addValue("note", Db.truncate(note, 1000)).addValue("now", Db.utc(clock.instant())));
        if (inserted > 0 && "OPEN".equals(status)) {
            Map<String, Object> f = new LinkedHashMap<>();
            f.put("consumer", consumer);
            f.put("topic", topic);
            f.put("partition", partition);
            f.put("fromOffset", from);
            f.put("toOffset", to);
            f.put("note", note);
            eventLog.alert("OFFSET_GAP", f);
        }
    }

    public List<Map<String, Object>> gaps(String consumer, String status) {
        return jdbc.queryForList("SELECT TOP (500) gap_id, topic, kafka_partition, from_offset, to_offset, missing_count, status,"
                + " note, detected_at FROM offset_gap WHERE consumer_name = :c" + (status == null ? "" : " AND status = :s")
                + " ORDER BY gap_id DESC", new MapSqlParameterSource("c", consumer).addValue("s", status));
    }

    public void resolveGap(long gapId, String status, String note) {
        jdbc.update("UPDATE offset_gap SET status = :s, note = :n WHERE gap_id = :id",
                new MapSqlParameterSource("id", gapId).addValue("s", status).addValue("n", Db.truncate(note, 1000)));
    }

    // ===================================================================== control totals

    /** Nightly: IOC's own count for yesterday, compared with whatever the producer has sent. */
    @Scheduled(cron = "${ioc.platform.reconciliation.cron:0 30 6 * * *}", zone = "${ioc.platform.business-zone:Europe/Dublin}")
    public void reconcileYesterday() {
        if (!props.getReconciliation().isEnabled()) {
            return;
        }
        LocalDate yesterday = LocalDate.now(clock.withZone(ZoneId.of(props.getBusinessZone()))).minusDays(1);
        for (EventPipeline<?, ?> p : registry.all()) {
            try {
                reconcile(p.consumerName(), p.settings().topic(), yesterday, null, null);
            } catch (RuntimeException e) {
                log.warn("Reconciliation failed for {}: {}", p.consumerName(), e.getMessage());
            }
        }
    }

    /** Called nightly, and when a source team submits its total (producerCount != null). */
    public Map<String, Object> reconcile(String consumer, String topic, LocalDate date, Long producerCount, String submittedBy) {
        long iocCount = ledger.countForBusinessDate(consumer, topic, date);
        jdbc.update("""
                MERGE control_total WITH (HOLDLOCK) AS t
                USING (SELECT :c AS consumer_name, :t AS topic, :d AS business_date) AS s
                  ON t.consumer_name = s.consumer_name AND t.topic = s.topic AND t.business_date = s.business_date
                WHEN MATCHED THEN UPDATE SET ioc_count = :ioc,
                    producer_count = ISNULL(:prod, t.producer_count),
                    submitted_by = ISNULL(:by, t.submitted_by), reconciled_at = :now
                WHEN NOT MATCHED THEN INSERT (consumer_name, topic, business_date, producer_count, ioc_count, status, submitted_by, reconciled_at)
                    VALUES (:c, :t, :d, :prod, :ioc, 'AWAITING_PRODUCER', :by, :now);
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("d", date)
                .addValue("ioc", iocCount).addValue("prod", producerCount).addValue("by", submittedBy)
                .addValue("now", Db.utc(clock.instant())));
        Map<String, Object> row = jdbc.queryForMap("""
                UPDATE control_total SET status = CASE WHEN producer_count IS NULL THEN 'AWAITING_PRODUCER'
                    WHEN producer_count = ioc_count THEN 'MATCHED' ELSE 'MISMATCH' END
                OUTPUT INSERTED.consumer_name, INSERTED.topic, INSERTED.business_date, INSERTED.producer_count,
                    INSERTED.ioc_count, INSERTED.status
                WHERE consumer_name = :c AND topic = :t AND business_date = :d
                """, new MapSqlParameterSource("c", consumer).addValue("t", topic).addValue("d", date));
        if ("MISMATCH".equals(row.get("status"))) {
            Map<String, Object> f = new LinkedHashMap<>(row);
            eventLog.alert("CONTROL_TOTAL_MISMATCH", f);
        }
        return row;
    }

    public List<Map<String, Object>> controlTotals(String consumer, int days) {
        return jdbc.queryForList("""
                SELECT topic, business_date, producer_count, ioc_count, status, submitted_by, reconciled_at
                FROM control_total WHERE consumer_name = :c AND business_date >= :since ORDER BY business_date DESC
                """, new MapSqlParameterSource("c", consumer)
                .addValue("since", LocalDate.now(clock.withZone(ZoneId.of(props.getBusinessZone()))).minusDays(days)));
    }

    public Instant now() {
        return clock.instant();
    }
}
