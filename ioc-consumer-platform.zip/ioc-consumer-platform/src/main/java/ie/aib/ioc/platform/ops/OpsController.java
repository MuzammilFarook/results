package ie.aib.ioc.platform.ops;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.InboundRecord.OffsetKey;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.core.PlatformUnavailableException;
import ie.aib.ioc.platform.failure.FailureModels.FailureFilter;
import ie.aib.ioc.platform.failure.FailureModels.FailureView;
import ie.aib.ioc.platform.failure.FailureModels.StoredFailure;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.AvroPayloadDecoder;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import ie.aib.ioc.platform.ledger.LedgerEntry;
import ie.aib.ioc.platform.ledger.LedgerRepository;
import ie.aib.ioc.platform.ledger.LedgerRepository.LedgerQuery;
import ie.aib.ioc.platform.observability.ReconciliationService;
import ie.aib.ioc.platform.outbox.OutboxModels.OutboxNote;
import ie.aib.ioc.platform.outbox.OutboxRepository;
import ie.aib.ioc.platform.replay.ReplayModels.DryRun;
import ie.aib.ioc.platform.replay.ReplayModels.ReplayRequestView;
import ie.aib.ioc.platform.replay.ReplayModels.SingleReplayResult;
import ie.aib.ioc.platform.replay.ReplayService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.core.env.Environment;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Ops API — the console is a thin skin over this, and everything here also works from curl or a
 * runbook script. Read endpoints need OPS_READ; replay needs OPS_REPLAY; approval needs OPS_APPROVE
 * (and a different person from the requester); pause/resume and control totals need OPS_ADMIN.
 * Rules are in {@code OpsSecurityConfig}.
 */
@RestController
@RequestMapping("/ops/api")
public class OpsController {

    private final PipelineRegistry registry;
    private final OverviewService overview;
    private final LedgerRepository ledger;
    private final FailureRepository failures;
    private final OutboxRepository outbox;
    private final ReplayService replay;
    private final ReconciliationService reconciliation;
    private final ConsumerControl control;
    private final AuditService audit;
    private final AvroPayloadDecoder decoder;
    private final IocPlatformProperties props;
    private final Environment env;

    public OpsController(PipelineRegistry registry, OverviewService overview, LedgerRepository ledger,
                         FailureRepository failures, OutboxRepository outbox, ReplayService replay,
                         ReconciliationService reconciliation, ConsumerControl control, AuditService audit,
                         AvroPayloadDecoder decoder, IocPlatformProperties props, Environment env) {
        this.registry = registry;
        this.overview = overview;
        this.ledger = ledger;
        this.failures = failures;
        this.outbox = outbox;
        this.replay = replay;
        this.reconciliation = reconciliation;
        this.control = control;
        this.audit = audit;
        this.decoder = decoder;
        this.props = props;
        this.env = env;
    }

    // ===================================================================== who am I / what's here

    @GetMapping("/whoami")
    public Map<String, Object> whoami(Authentication auth) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("user", auth.getName());
        m.put("roles", auth.getAuthorities().stream().map(GrantedAuthority::getAuthority)
                .filter(a -> a.startsWith("ROLE_")).map(a -> a.substring(5)).toList());
        List<Map<String, Object>> consumers = new ArrayList<>();
        for (EventPipeline<?, ?> p : registry.all()) {
            consumers.add(Map.of("name", p.consumerName(), "topic", p.settings().topic(),
                    "entityType", p.settings().entityType()));
        }
        m.put("consumers", consumers);
        m.put("approvalThreshold", props.getManualReplay().getApprovalThreshold());
        m.put("instance", props.getInstanceId());
        m.put("profiles", List.of(env.getActiveProfiles()));
        m.put("autoReplaySchedule", props.getAutoReplay().getSchedule().stream().map(Object::toString).toList());
        return m;
    }

    @GetMapping("/consumers/{c}/overview")
    public Map<String, Object> overview(@PathVariable String c, @RequestParam(defaultValue = "24") int hours) {
        return overview.overview(c, Math.max(1, Math.min(hours, 24 * 7)));
    }

    // ===================================================================== ledger + trace

    @GetMapping("/consumers/{c}/ledger")
    public Page<LedgerEntry> ledger(@PathVariable String c,
                                    @RequestParam(required = false) String outcome,
                                    @RequestParam(required = false) String entityKey,
                                    @RequestParam(required = false) String eventId,
                                    @RequestParam(required = false) String traceId,
                                    @RequestParam(required = false) Integer partition,
                                    @RequestParam(required = false) Long offsetFrom,
                                    @RequestParam(required = false) Long offsetTo,
                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                                    @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                                    @RequestParam(required = false) Boolean materialOnly,
                                    @RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "50") int size) {
        registry.pipeline(c);
        return ledger.search(new LedgerQuery(c, blank(outcome), blank(entityKey), blank(eventId), blank(traceId),
                partition, offsetFrom, offsetTo, from, to, materialOnly), Math.max(0, page), clamp(size));
    }

    @GetMapping("/consumers/{c}/ledger/{id}/transitions")
    public List<LedgerEntry.Transition> transitions(@PathVariable String c, @PathVariable long id) {
        return ledger.transitions(id);
    }

    /**
     * The end-to-end trail for an eventId, traceId, entity key, or "topic/partition@offset":
     * Kafka record → ledger line (+ outcome history) → failure tray (+ every attempt) → outbox note →
     * Credit Change topic partition/offset.
     */
    @GetMapping("/consumers/{c}/trace")
    public Map<String, Object> trace(@PathVariable String c, @RequestParam("q") String q) {
        registry.pipeline(c);
        String term = q.trim();
        List<LedgerEntry> lines = ledger.findForTrace(c, term);
        Map<Long, Object> transitions = new LinkedHashMap<>();
        List<OutboxNote> notes = new ArrayList<>(outbox.findForTrace(c, term));
        List<FailureView> tray = new ArrayList<>(failures.findForTrace(c, term));
        for (LedgerEntry l : lines) {
            transitions.put(l.ledgerId(), ledger.transitions(l.ledgerId()));
            OffsetKey key = new OffsetKey(l.topic(), l.partition(), l.offset());
            for (OutboxNote n : outbox.findBySource(c, key)) {
                if (notes.stream().noneMatch(x -> x.outboxId() == n.outboxId())) {
                    notes.add(n);
                }
            }
            failures.findViewByOffset(c, key).ifPresent(f -> {
                if (tray.stream().noneMatch(x -> x.failureId() == f.failureId())) {
                    tray.add(f);
                }
            });
        }
        Map<Long, Object> attempts = new LinkedHashMap<>();
        tray.forEach(f -> attempts.put(f.failureId(), failures.attempts(f.failureId())));
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("query", term);
        out.put("ledger", lines);
        out.put("transitions", transitions);
        out.put("failures", tray);
        out.put("attempts", attempts);
        out.put("outbox", notes);
        return out;
    }

    // ===================================================================== failure tray

    @GetMapping("/consumers/{c}/failures")
    public Page<FailureView> failures(@PathVariable String c,
                                      @RequestParam(required = false) String category,
                                      @RequestParam(required = false) String status,
                                      @RequestParam(required = false) String entityKey,
                                      @RequestParam(required = false) String errorClass,
                                      @RequestParam(required = false) Integer partition,
                                      @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
                                      @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
                                      @RequestParam(defaultValue = "0") int page,
                                      @RequestParam(defaultValue = "50") int size) {
        registry.pipeline(c);
        return failures.search(new FailureFilter(c, blank(category), blank(status), blank(entityKey), blank(errorClass),
                null, partition, from, to), Math.max(0, page), clamp(size));
    }

    @GetMapping("/consumers/{c}/failures/{id}")
    public Map<String, Object> failure(@PathVariable String c, @PathVariable long id) {
        FailureView v = failures.findView(id).filter(f -> f.consumerName().equals(c))
                .orElseThrow(() -> OpsException.notFound("Failure " + id));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("failure", v);
        m.put("attempts", failures.attempts(id));
        return m;
    }

    /** Decoded payload. Separate endpoint + stronger role: it contains customer data. Audited. */
    @GetMapping("/consumers/{c}/failures/{id}/payload")
    public Map<String, Object> payload(@PathVariable String c, @PathVariable long id, Authentication auth,
                                       HttpServletRequest http) {
        StoredFailure f = failures.findStored(id).filter(x -> x.consumerName().equals(c))
                .orElseThrow(() -> OpsException.notFound("Failure " + id));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("failureId", id);
        m.put("bytes", f.payload() == null ? 0 : f.payload().length);
        m.put("headers", failures.headersFromJson(f.headersJson()).keySet());
        try {
            Object decoded = decoder.decode(f.topic(), f.payload());
            m.put("decoded", decoded == null ? null : decoded.toString());
        } catch (RuntimeException e) {
            m.put("decodeError", e.getClass().getSimpleName() + ": " + e.getMessage());
            byte[] p = f.payload() == null ? new byte[0] : f.payload();
            m.put("hexPreview", HexFormat.of().formatHex(p, 0, Math.min(p.length, 256)));
        }
        audit.record(auth.getName(), "VIEW_PAYLOAD", "failure:" + id, Map.of(), "OK", http.getRemoteAddr());
        return m;
    }

    @PostMapping("/consumers/{c}/failures/{id}/replay")
    public SingleReplayResult replayOne(@PathVariable String c, @PathVariable long id, Authentication auth,
                                        HttpServletRequest http) {
        failures.findView(id).filter(f -> f.consumerName().equals(c)).orElseThrow(() -> OpsException.notFound("Failure " + id));
        return replay.replayFailure(id, auth.getName(), http.getRemoteAddr());
    }

    @PostMapping("/consumers/{c}/failures/{id}/discard")
    public Map<String, Object> discard(@PathVariable String c, @PathVariable long id, @RequestBody ReasonBody body,
                                       Authentication auth, HttpServletRequest http) {
        failures.findView(id).filter(f -> f.consumerName().equals(c)).orElseThrow(() -> OpsException.notFound("Failure " + id));
        replay.discard(id, auth.getName(), body.reason(), http.getRemoteAddr());
        return Map.of("failureId", id, "status", "DISCARDED");
    }

    // ===================================================================== bulk replay

    @PostMapping("/consumers/{c}/replay/dry-run")
    public DryRun dryRun(@PathVariable String c, @RequestBody ReplayBody body) {
        registry.pipeline(c);
        return replay.dryRun(c, body.type(), body.filter());
    }

    @PostMapping("/consumers/{c}/replay-requests")
    public ReplayRequestView createRequest(@PathVariable String c, @RequestBody ReplayBody body, Authentication auth,
                                           HttpServletRequest http) {
        return replay.createRequest(c, body.type(), body.filter(), body.reason(), auth.getName(), http.getRemoteAddr());
    }

    @GetMapping("/consumers/{c}/replay-requests")
    public Page<ReplayRequestView> requests(@PathVariable String c, @RequestParam(required = false) String status,
                                            @RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "50") int size) {
        return replay.list(c, blank(status), Math.max(0, page), clamp(size));
    }

    @GetMapping("/replay-requests/{id}")
    public ReplayRequestView request(@PathVariable long id) {
        return replay.find(id);
    }

    @PostMapping("/replay-requests/{id}/approve")
    public ReplayRequestView approve(@PathVariable long id, @RequestBody(required = false) NoteBody body,
                                     Authentication auth, HttpServletRequest http) {
        return replay.decide(id, true, auth.getName(), body == null ? null : body.note(), http.getRemoteAddr());
    }

    @PostMapping("/replay-requests/{id}/reject")
    public ReplayRequestView reject(@PathVariable long id, @RequestBody(required = false) NoteBody body,
                                    Authentication auth, HttpServletRequest http) {
        return replay.decide(id, false, auth.getName(), body == null ? null : body.note(), http.getRemoteAddr());
    }

    @PostMapping("/replay-requests/{id}/cancel")
    public ReplayRequestView cancel(@PathVariable long id, Authentication auth, HttpServletRequest http) {
        return replay.cancel(id, auth.getName(), http.getRemoteAddr());
    }

    // ===================================================================== outbox evidence

    @GetMapping("/consumers/{c}/outbox")
    public Page<OutboxNote> outbox(@PathVariable String c, @RequestParam(required = false) String status,
                                   @RequestParam(required = false) String key,
                                   @RequestParam(defaultValue = "0") int page,
                                   @RequestParam(defaultValue = "50") int size) {
        return outbox.search(c, blank(status), blank(key), Math.max(0, page), clamp(size));
    }

    // ===================================================================== reconciliation

    @GetMapping("/consumers/{c}/gaps")
    public List<Map<String, Object>> gaps(@PathVariable String c, @RequestParam(required = false) String status) {
        return reconciliation.gaps(c, blank(status));
    }

    @PostMapping("/gaps/{id}/resolve")
    public Map<String, Object> resolveGap(@PathVariable long id, @RequestBody GapBody body, Authentication auth,
                                          HttpServletRequest http) {
        if (!List.of("EXPLAINED", "RESOLVED").contains(body.status())) {
            throw OpsException.badRequest("status must be EXPLAINED or RESOLVED");
        }
        reconciliation.resolveGap(id, body.status(), auth.getName() + ": " + body.note());
        audit.record(auth.getName(), "GAP_" + body.status(), "gap:" + id, Map.of("note", String.valueOf(body.note())), "OK", http.getRemoteAddr());
        return Map.of("gapId", id, "status", body.status());
    }

    @GetMapping("/consumers/{c}/control-totals")
    public List<Map<String, Object>> controlTotals(@PathVariable String c, @RequestParam(defaultValue = "30") int days) {
        return reconciliation.controlTotals(c, Math.min(days, 400));
    }

    /** A source team (or its batch job) submits "yesterday I sent N". */
    @PostMapping("/consumers/{c}/control-totals")
    public Map<String, Object> submitControlTotal(@PathVariable String c, @RequestBody ControlTotalBody body,
                                                  Authentication auth, HttpServletRequest http) {
        EventPipeline<?, ?> p = registry.pipeline(c);
        Map<String, Object> row = reconciliation.reconcile(c, p.settings().topic(), body.businessDate(),
                body.producerCount(), auth.getName());
        audit.record(auth.getName(), "CONTROL_TOTAL_SUBMITTED", c + ":" + body.businessDate(),
                Map.of("producerCount", body.producerCount()), String.valueOf(row.get("status")), http.getRemoteAddr());
        return row;
    }

    // ===================================================================== consumer control + audit

    @PostMapping("/consumers/{c}/pause")
    public Map<String, Object> pause(@PathVariable String c, Authentication auth, HttpServletRequest http) {
        control.pause(c);
        audit.record(auth.getName(), "CONSUMER_PAUSE", c, Map.of(), "OK", http.getRemoteAddr());
        return control.status(c);
    }

    @PostMapping("/consumers/{c}/resume")
    public Map<String, Object> resume(@PathVariable String c, Authentication auth, HttpServletRequest http) {
        control.resume(c);
        audit.record(auth.getName(), "CONSUMER_RESUME", c, Map.of(), "OK", http.getRemoteAddr());
        return control.status(c);
    }

    @GetMapping("/audit")
    public Page<AuditService.AuditEntry> audit(@RequestParam(required = false) String actor,
                                               @RequestParam(required = false) String action,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "50") int size) {
        return audit.search(blank(actor), blank(action), Math.max(0, page), clamp(size));
    }

    // ===================================================================== errors

    @ExceptionHandler(OpsException.class)
    public ResponseEntity<Map<String, Object>> opsError(OpsException e) {
        return ResponseEntity.status(e.status()).body(Map.of("error", e.getMessage()));
    }

    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<Map<String, Object>> notFound(NoSuchElementException e) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", String.valueOf(e.getMessage())));
    }

    @ExceptionHandler(PlatformUnavailableException.class)
    public ResponseEntity<Map<String, Object>> platform(PlatformUnavailableException e) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(Map.of("error", "Database or Schema Registry unavailable — nothing was changed"));
    }

    private static String blank(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }

    private static int clamp(int size) {
        return Math.max(1, Math.min(size, 500));
    }

    public record ReasonBody(String reason) { }
    public record NoteBody(String note) { }
    public record GapBody(String status, String note) { }
    public record ControlTotalBody(LocalDate businessDate, long producerCount) { }
    public record ReplayBody(String type, Map<String, Object> filter, String reason) { }
}
