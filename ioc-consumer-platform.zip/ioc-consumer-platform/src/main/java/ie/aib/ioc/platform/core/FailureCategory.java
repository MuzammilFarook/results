package ie.aib.ioc.platform.core;

/**
 * Why a record is in the failure tray. The category decides what happens next.
 */
public enum FailureCategory {
    /** Bytes could not be turned into an Avro object (corrupt, unknown schema id). Needs a person. */
    DESERIALISATION(false),
    /** Decoded fine but breaks the topic contract (missing id, negative limit...). Needs a person. */
    VALIDATION(false),
    /** Something it needs has not arrived yet (e.g. covenant before its CCV). Retry later. */
    DEPENDENCY_MISSING(true),
    /** Same version number, different content. Needs a person to decide. */
    CONFLICT(false),
    /** A temporary problem that survived the quick in-memory retries. Retry later. */
    TRANSIENT_EXHAUSTED(true),
    /** Anything else (usually a bug or a DB rejecting the data). Needs a person. */
    UNKNOWN(false);

    private final boolean autoRetry;

    FailureCategory(boolean autoRetry) {
        this.autoRetry = autoRetry;
    }

    /** Whether the replay timer retries this automatically. Broken letters are never auto-retried. */
    public boolean autoRetry() {
        return autoRetry;
    }
}
