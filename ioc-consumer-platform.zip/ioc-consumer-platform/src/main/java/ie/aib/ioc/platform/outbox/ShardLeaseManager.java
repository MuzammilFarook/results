package ie.aib.ioc.platform.outbox;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.Db;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * "Each borrower's notes always go to the same postman."
 *
 * <p>The outbox is split into N shards by entity key. Each publisher pod holds a time-limited lease
 * on a fair share of shards (16 shards / 3 pods ≈ 6 each) and is the only one sending them, in
 * outbox_id order — so announcements for one entity are never reordered, and publishing still
 * scales out. A dead pod's leases expire and are picked up by the others.
 */
@Component
@ConditionalOnProperty(prefix = "ioc.platform.outbox", name = "publisher-enabled", havingValue = "true", matchIfMissing = true)
public class ShardLeaseManager {

    private static final Logger log = LoggerFactory.getLogger(ShardLeaseManager.class);

    private final NamedParameterJdbcTemplate jdbc;
    private final IocPlatformProperties props;
    private final Clock clock;
    private final Map<Integer, Instant> owned = new ConcurrentHashMap<>();

    public ShardLeaseManager(NamedParameterJdbcTemplate jdbc, IocPlatformProperties props, Clock clock) {
        this.jdbc = jdbc;
        this.props = props;
        this.clock = clock;
    }

    @PostConstruct
    void ensureShardRows() {
        for (int s = 0; s < props.getOutbox().getShards(); s++) {
            try {
                jdbc.update("""
                        IF NOT EXISTS (SELECT 1 FROM outbox_shard_lease WHERE shard = :s)
                            INSERT INTO outbox_shard_lease (shard, owner_id, lease_until, epoch) VALUES (:s, NULL, '2000-01-01', 0)
                        """, new MapSqlParameterSource("s", s));
            } catch (DuplicateKeyException race) {
                // another pod inserted it first
            }
        }
    }

    /** Shards this instance may publish right now (lease valid with a safety margin). */
    public Set<Integer> ownedShards() {
        Instant safe = clock.instant().plus(props.getOutbox().getLeaseDuration().dividedBy(5));
        Set<Integer> out = new TreeSet<>();
        owned.forEach((shard, until) -> {
            if (until.isAfter(safe)) {
                out.add(shard);
            }
        });
        return out;
    }

    @Scheduled(fixedDelayString = "${ioc.platform.outbox.lease-renew-ms:5000}")
    public void renewAndRebalance() {
        try {
            doRenewAndRebalance();
        } catch (RuntimeException e) {
            owned.clear(); // can't prove we hold anything → publish nothing
            log.warn("Outbox lease renewal failed: {}", e.getMessage());
        }
    }

    private void doRenewAndRebalance() {
        Instant now = clock.instant();
        Instant until = now.plus(props.getOutbox().getLeaseDuration());
        String me = props.getInstanceId();
        int shards = props.getOutbox().getShards();

        jdbc.update("""
                MERGE outbox_publisher_heartbeat WITH (HOLDLOCK) AS t
                USING (SELECT :me AS instance_id) AS s ON t.instance_id = s.instance_id
                WHEN MATCHED THEN UPDATE SET heartbeat_at = :now
                WHEN NOT MATCHED THEN INSERT (instance_id, heartbeat_at) VALUES (:me, :now);
                """, new MapSqlParameterSource("me", me).addValue("now", Db.utc(now)));
        Integer active = jdbc.queryForObject("SELECT COUNT(*) FROM outbox_publisher_heartbeat WHERE heartbeat_at > :since",
                new MapSqlParameterSource("since", Db.utc(now.minus(props.getOutbox().getLeaseDuration()))), Integer.class);
        int fair = (int) Math.ceil((double) shards / Math.max(1, active == null ? 1 : active));

        // renew what we hold
        jdbc.update("UPDATE outbox_shard_lease SET lease_until = :until WHERE owner_id = :me AND lease_until > :now",
                new MapSqlParameterSource("me", me).addValue("until", Db.utc(until)).addValue("now", Db.utc(now)));
        List<Integer> mine = jdbc.queryForList("SELECT shard FROM outbox_shard_lease WHERE owner_id = :me AND lease_until > :now ORDER BY shard",
                new MapSqlParameterSource("me", me).addValue("now", Db.utc(now)), Integer.class);

        if (mine.size() > fair) {
            List<Integer> release = new ArrayList<>(mine.subList(fair, mine.size()));
            jdbc.update("UPDATE outbox_shard_lease SET owner_id = NULL, lease_until = :now WHERE owner_id = :me AND shard IN (:shards)",
                    new MapSqlParameterSource("me", me).addValue("now", Db.utc(now)).addValue("shards", release));
            mine = new ArrayList<>(mine.subList(0, fair));
            log.info("Released outbox shards {} to rebalance ({} active publishers)", release, active);
        } else if (mine.size() < fair) {
            List<Integer> got = jdbc.queryForList("""
                    WITH free AS (
                        SELECT TOP (:n) * FROM outbox_shard_lease WITH (UPDLOCK, READPAST, ROWLOCK)
                        WHERE owner_id IS NULL OR lease_until < :now
                        ORDER BY shard
                    )
                    UPDATE free SET owner_id = :me, lease_until = :until, epoch = epoch + 1
                    OUTPUT INSERTED.shard
                    """, new MapSqlParameterSource("n", fair - mine.size()).addValue("me", me)
                    .addValue("until", Db.utc(until)).addValue("now", Db.utc(now)), Integer.class);
            if (!got.isEmpty()) {
                log.info("Acquired outbox shards {}", got);
            }
            mine = new ArrayList<>(mine);
            mine.addAll(got);
        }
        owned.clear();
        mine.forEach(s -> owned.put(s, until));
    }

    @PreDestroy
    void releaseAll() {
        try {
            jdbc.update("UPDATE outbox_shard_lease SET owner_id = NULL, lease_until = :now WHERE owner_id = :me",
                    new MapSqlParameterSource("me", props.getInstanceId()).addValue("now", Db.utc(clock.instant())));
            jdbc.update("DELETE FROM outbox_publisher_heartbeat WHERE instance_id = :me",
                    new MapSqlParameterSource("me", props.getInstanceId()));
        } catch (RuntimeException e) {
            log.warn("Could not release outbox leases on shutdown (they will expire): {}", e.getMessage());
        }
        owned.clear();
    }
}
