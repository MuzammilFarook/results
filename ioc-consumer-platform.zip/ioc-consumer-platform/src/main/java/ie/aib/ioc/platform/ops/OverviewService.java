package ie.aib.ioc.platform.ops;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import ie.aib.ioc.platform.ledger.LedgerRepository;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.outbox.OutboxRepository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

/** Everything the console's Overview screen shows, in one call. */
@Service
public class OverviewService {

    private final PipelineRegistry registry;
    private final ConsumerControl control;
    private final ConsumerStats stats;
    private final LedgerRepository ledger;
    private final FailureRepository failures;
    private final OutboxRepository outbox;
    private final NamedParameterJdbcTemplate jdbc;
    private final IocPlatformProperties props;
    private final Clock clock;

    public OverviewService(PipelineRegistry registry, ConsumerControl control, ConsumerStats stats, LedgerRepository ledger,
                           FailureRepository failures, OutboxRepository outbox, NamedParameterJdbcTemplate jdbc,
                           IocPlatformProperties props, Clock clock) {
        this.registry = registry;
        this.control = control;
        this.stats = stats;
        this.ledger = ledger;
        this.failures = failures;
        this.outbox = outbox;
        this.jdbc = jdbc;
        this.props = props;
        this.clock = clock;
    }

    public Map<String, Object> overview(String consumer, int hours) {
        var pipeline = registry.pipeline(consumer);
        Instant now = clock.instant();
        Instant since = now.minus(Duration.ofHours(hours));
        int bucket = hours <= 2 ? 1 : hours <= 24 ? 15 : 60;

        Map<String, Object> o = new LinkedHashMap<>();
        o.put("consumer", consumer);
        o.put("topic", pipeline.settings().topic());
        o.put("entityType", pipeline.settings().entityType());
        o.put("evidenceLevel", pipeline.settings().evidenceLevel());
        o.put("materialityRuleVersion", pipeline.settings().materialityRuleVersion());
        o.put("instance", props.getInstanceId());
        o.put("generatedAt", now);
        o.put("windowHours", hours);
        o.put("bucketMinutes", bucket);
        o.put("status", control.status(consumer));
        o.put("currentMinute", stats.currentMinute(consumer));
        o.put("totals", totals(consumer, since));
        o.put("series", series(consumer, since, bucket));
        o.put("ledgerOutcomes", ledger.outcomeCounts(consumer, since, now));
        o.put("openFailuresByCategory", failures.openByCategory(consumer));
        o.put("failuresByStatus", failures.countByStatus(consumer));
        o.put("outboxByStatus", outbox.countByStatus(consumer));
        o.put("oldestPendingOutboxSeconds", outbox.oldestPendingAge(now).toSeconds());
        o.put("pendingApprovals", jdbc.queryForObject(
                "SELECT COUNT(*) FROM replay_request WHERE consumer_name = :c AND status = 'PENDING_APPROVAL'",
                new MapSqlParameterSource("c", consumer), Integer.class));
        o.put("runningReplays", jdbc.queryForObject(
                "SELECT COUNT(*) FROM replay_request WHERE consumer_name = :c AND status IN ('APPROVED', 'RUNNING')",
                new MapSqlParameterSource("c", consumer), Integer.class));
        o.put("openGaps", jdbc.queryForObject("SELECT COUNT(*) FROM offset_gap WHERE consumer_name = :c AND status = 'OPEN'",
                new MapSqlParameterSource("c", consumer), Integer.class));
        return o;
    }

    private Map<String, Object> totals(String consumer, Instant since) {
        return jdbc.queryForMap("""
                SELECT ISNULL(SUM(consumed), 0) AS consumed, ISNULL(SUM(processed), 0) AS processed,
                    ISNULL(SUM(duplicate), 0) AS duplicate, ISNULL(SUM(stale), 0) AS stale,
                    ISNULL(SUM(superseded), 0) AS superseded, ISNULL(SUM(filtered), 0) AS filtered,
                    ISNULL(SUM(failed), 0) AS failed, ISNULL(SUM(replayed), 0) AS replayed,
                    ISNULL(SUM(retried), 0) AS retried, ISNULL(SUM(redelivered), 0) AS redelivered,
                    ISNULL(SUM(published), 0) AS published, ISNULL(SUM(material), 0) AS material,
                    ISNULL(SUM(paused_ms), 0) AS paused_ms
                FROM consumer_stats_minute WHERE consumer_name = :c AND minute_start >= :since
                """, new MapSqlParameterSource("c", consumer).addValue("since", Db.utc(since)));
    }

    /** Per-bucket totals across all pods. */
    private List<Map<String, Object>> series(String consumer, Instant since, int bucketMinutes) {
        return jdbc.queryForList("""
                SELECT bucket, SUM(consumed) AS consumed, SUM(processed) AS processed,
                    SUM(duplicate + stale + superseded) AS skipped, SUM(filtered) AS filtered, SUM(failed) AS failed,
                    SUM(replayed) AS replayed, SUM(published) AS published, MAX(p95_batch_ms) AS p95_batch_ms,
                    SUM(paused_ms) AS paused_ms
                FROM (
                    SELECT DATEADD(MINUTE, (DATEDIFF(MINUTE, '2000-01-01', minute_start) / :b) * :b, '2000-01-01') AS bucket, *
                    FROM consumer_stats_minute WHERE consumer_name = :c AND minute_start >= :since
                ) x
                GROUP BY bucket
                ORDER BY bucket
                """, new MapSqlParameterSource("c", consumer).addValue("since", Db.utc(since)).addValue("b", bucketMinutes));
    }
}
