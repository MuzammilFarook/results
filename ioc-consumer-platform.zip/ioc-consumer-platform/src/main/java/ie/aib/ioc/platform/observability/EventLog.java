package ie.aib.ioc.platform.observability;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import static net.logstash.logback.argument.StructuredArguments.entries;

/**
 * The only place that writes per-event log lines — and only for the interesting ones: failures,
 * replays, pauses, alerts and ops actions. Every consumer logs the same fields, so ONE Splunk
 * search works for all topics:
 *
 * <pre>
 *   index=ioc type=consumer.event outcome=FAILED | stats count by consumer, errorCategory
 *   index=ioc type=consumer.summary | timechart span=15m sum(consumed) sum(failed) sum(retried) by consumer
 *   index=ioc traceId=4bf92f3577b34da6a3ce929d0e0e4736
 * </pre>
 */
@Component
public class EventLog {

    private static final Logger LOG = LoggerFactory.getLogger("ioc.consumer.event");

    public void failed(String consumer, String topic, int partition, long offset, String eventId, String entityKey,
                       String traceId, String category, String errorClass, String message, int attempt,
                       Long failureId, String mode) {
        Map<String, Object> m = base("consumer.event", consumer, topic, partition, offset, eventId, entityKey, traceId);
        m.put("outcome", "FAILED");
        m.put("errorCategory", category);
        m.put("errorClass", errorClass);
        m.put("errorMessage", message);
        m.put("attempt", attempt);
        m.put("failureId", failureId);
        m.put("mode", mode);
        LOG.warn("consumer.event FAILED", entries(m));
    }

    public void replayed(String consumer, String topic, int partition, long offset, String eventId, String entityKey,
                         String traceId, String resultOutcome, String mode, String actor, Long failureId, Long requestId) {
        Map<String, Object> m = base("consumer.event", consumer, topic, partition, offset, eventId, entityKey, traceId);
        m.put("outcome", "REPLAYED");
        m.put("replayResult", resultOutcome);
        m.put("mode", mode);
        m.put("actor", actor);
        m.put("failureId", failureId);
        m.put("replayRequestId", requestId);
        LOG.info("consumer.event REPLAYED", entries(m));
    }

    public void conflictOrStale(String consumer, String topic, int partition, long offset, String eventId,
                                String entityKey, String traceId, String outcome, String detail) {
        Map<String, Object> m = base("consumer.event", consumer, topic, partition, offset, eventId, entityKey, traceId);
        m.put("outcome", outcome);
        m.put("detail", detail);
        LOG.info("consumer.event " + outcome, entries(m));
    }

    public void lifecycle(String type, Map<String, Object> fields) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.putAll(fields);
        LOG.warn(type, entries(m));
    }

    public void alert(String alert, Map<String, Object> fields) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", "ioc.alert");
        m.put("alert", alert);
        m.putAll(fields);
        LOG.error("ioc.alert " + alert, entries(m));
    }

    private static Map<String, Object> base(String type, String consumer, String topic, int partition, long offset,
                                            String eventId, String entityKey, String traceId) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("consumer", consumer);
        m.put("topic", topic);
        m.put("partition", partition);
        m.put("offset", offset);
        m.put("eventId", eventId);
        m.put("entityKey", entityKey);
        m.put("traceId", traceId);
        return m;
    }
}
