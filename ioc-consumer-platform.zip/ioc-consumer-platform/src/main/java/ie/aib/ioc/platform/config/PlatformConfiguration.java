package ie.aib.ioc.platform.config;

import java.time.Clock;
import java.util.HashMap;
import java.util.Map;

import ie.aib.ioc.platform.core.ErrorClassifier;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.PlatformHealth;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.AvroPayloadDecoder;
import ie.aib.ioc.platform.ledger.LedgerRepository;
import ie.aib.ioc.platform.observability.ConsumerStats;
import ie.aib.ioc.platform.observability.EventLog;
import ie.aib.ioc.platform.outbox.OutboxRepository;
import ie.aib.ioc.platform.replay.BackoffSchedule;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.ssl.SslBundles;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.listener.ContainerProperties.AckMode;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
@EnableScheduling
@EnableConfigurationProperties(IocPlatformProperties.class)
public class PlatformConfiguration {

    /** The container factory every IOC listener uses. */
    public static final String BATCH_FACTORY = "iocBatchContainerFactory";
    public static final String CREDIT_CHANGE_TEMPLATE = "creditChangeKafkaTemplate";

    @Bean
    Clock clock() {
        return Clock.systemUTC();
    }

    @Bean
    AvroPayloadDecoder avroPayloadDecoder(KafkaProperties kafka) {
        // spring.kafka.properties.* carries schema.registry.url and its credentials
        return new AvroPayloadDecoder(kafka.getProperties());
    }

    /** One transaction = state change + ledger lines + outbox notes. Azure SQL default isolation (RCSI). */
    @Bean
    TransactionTemplate iocTransactionTemplate(PlatformTransactionManager txManager) {
        TransactionTemplate t = new TransactionTemplate(txManager);
        t.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
        t.setTimeout(60);
        return t;
    }

    @Bean
    EventPipeline.Dependencies pipelineDependencies(AvroPayloadDecoder decoder, LedgerRepository ledger,
                                                    FailureRepository failures, OutboxRepository outbox,
                                                    TransactionTemplate iocTransactionTemplate, ErrorClassifier classifier,
                                                    PlatformHealth health, ConsumerStats stats, EventLog eventLog,
                                                    BackoffSchedule backoff, IocPlatformProperties props, Clock clock) {
        return new EventPipeline.Dependencies(decoder, ledger, failures, outbox, iocTransactionTemplate, classifier,
                health, stats, eventLog, backoff, props, clock, EventPipeline.Sleeper.REAL);
    }

    /**
     * Batch listener, manual acks, raw bytes in.
     * <ul>
     *   <li>MANUAL_IMMEDIATE — offsets are committed only by {@code ConsumerRuntime} after the DB commit.</li>
     *   <li>Error handler retries forever and never "recovers" (skips). The runtime catches everything,
     *       so this is a last line of defence against silently losing a batch.</li>
     * </ul>
     */
    @Bean(BATCH_FACTORY)
    @SuppressWarnings("unchecked")
    ConcurrentKafkaListenerContainerFactory<byte[], byte[]> iocBatchContainerFactory(ConsumerFactory<?, ?> consumerFactory,
                                                                                    KafkaProperties kafka) {
        ConcurrentKafkaListenerContainerFactory<byte[], byte[]> f = new ConcurrentKafkaListenerContainerFactory<>();
        f.setConsumerFactory((ConsumerFactory<byte[], byte[]>) consumerFactory);
        f.setBatchListener(true);
        f.getContainerProperties().setAckMode(AckMode.MANUAL_IMMEDIATE);
        f.getContainerProperties().setShutdownTimeout(30_000L);
        f.getContainerProperties().setMicrometerEnabled(true);
        if (kafka.getListener().getConcurrency() != null) {
            f.setConcurrency(kafka.getListener().getConcurrency());
        }
        f.setCommonErrorHandler(new DefaultErrorHandler(new FixedBackOff(5_000L, FixedBackOff.UNLIMITED_ATTEMPTS)));
        return f;
    }

    /**
     * The postman's producer: idempotent, acks=all, so a broker acknowledgement really means
     * "written to all in-sync replicas" and retries never duplicate inside Kafka.
     */
    @Bean(CREDIT_CHANGE_TEMPLATE)
    KafkaTemplate<String, Object> creditChangeKafkaTemplate(KafkaProperties kafka, ObjectProvider<SslBundles> sslBundles) {
        Map<String, Object> cfg = new HashMap<>(kafka.buildProducerProperties(sslBundles.getIfAvailable()));
        cfg.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        cfg.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class);
        cfg.put(ProducerConfig.ACKS_CONFIG, "all");
        cfg.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        cfg.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        cfg.putIfAbsent(ProducerConfig.CLIENT_ID_CONFIG, "ioc-outbox-publisher");
        return new KafkaTemplate<>(new DefaultKafkaProducerFactory<>(cfg));
    }
}
