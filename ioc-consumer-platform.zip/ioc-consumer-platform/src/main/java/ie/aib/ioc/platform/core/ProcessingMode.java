package ie.aib.ioc.platform.core;

/** How a record reached the pipeline. Replays go through exactly the same steps as live records. */
public enum ProcessingMode {
    /** Read from the topic by the Kafka listener. */
    LIVE,
    /** Retried by the failure-tray timer (1m, 5m, 15m, 1h, 4h). */
    AUTO_REPLAY,
    /** Replayed by an ops user from the console / API. */
    MANUAL_REPLAY,
    /** Re-read straight from Kafka offsets (e.g. reprocessing after a logic bug). */
    KAFKA_REREAD;

    public boolean isReplay() {
        return this != LIVE;
    }
}
