package ie.aib.ioc.platform.core;

import java.util.List;

/**
 * Result of a topic's materiality rule. Only material changes get an outbox note
 * (for accounts, roughly 1 in 100 changes).
 *
 * @param material   announce on the Credit Change topic?
 * @param changeType e.g. ACCOUNT_TIER1_UPDATED
 * @param reasons    machine-readable reasons, e.g. OVER_LIMIT_ENTERED, LIMIT_CHANGED
 */
public record Materiality(boolean material, String changeType, List<String> reasons) {

    public static Materiality notMaterial(String changeType) {
        return new Materiality(false, changeType, List.of());
    }
}
