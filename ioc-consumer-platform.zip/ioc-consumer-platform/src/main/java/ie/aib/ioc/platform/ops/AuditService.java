package ie.aib.ioc.platform.ops;

import java.time.Clock;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.observability.EventLog;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Service;

/** "Record who did what and when." Every ops action is written to the DB and to Splunk. */
@Service
public class AuditService {

    private final NamedParameterJdbcTemplate jdbc;
    private final ObjectMapper json;
    private final EventLog eventLog;
    private final Clock clock;

    public AuditService(NamedParameterJdbcTemplate jdbc, ObjectMapper json, EventLog eventLog, Clock clock) {
        this.jdbc = jdbc;
        this.json = json;
        this.eventLog = eventLog;
        this.clock = clock;
    }

    public void record(String actor, String action, String target, Map<String, ?> details, String result, String clientIp) {
        Instant now = clock.instant();
        String detailsJson;
        try {
            detailsJson = details == null ? null : json.writeValueAsString(details);
        } catch (JsonProcessingException e) {
            detailsJson = String.valueOf(details);
        }
        jdbc.update("""
                INSERT INTO ops_audit (actor, action, target, details_json, result, client_ip, occurred_at)
                VALUES (:actor, :action, :target, :details, :result, :ip, :now)
                """, new MapSqlParameterSource("actor", actor).addValue("action", action).addValue("target", target)
                .addValue("details", Db.truncate(detailsJson, 4000)).addValue("result", result)
                .addValue("ip", clientIp).addValue("now", Db.utc(now)));
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("actor", actor);
        m.put("action", action);
        m.put("target", target);
        m.put("result", result);
        m.put("details", details);
        eventLog.lifecycle("ops.action", m);
    }

    public Page<AuditEntry> search(String actor, String action, int page, int size) {
        StringBuilder sql = new StringBuilder("SELECT audit_id, actor, action, target, details_json, result, client_ip, occurred_at FROM ops_audit WHERE 1 = 1");
        MapSqlParameterSource p = new MapSqlParameterSource();
        if (actor != null) { sql.append(" AND actor = :actor"); p.addValue("actor", actor); }
        if (action != null) { sql.append(" AND action = :action"); p.addValue("action", action); }
        sql.append(" ORDER BY audit_id DESC OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY");
        p.addValue("skip", page * size).addValue("take", size + 1);
        List<AuditEntry> rows = jdbc.query(sql.toString(), p, (rs, i) -> new AuditEntry(rs.getLong("audit_id"),
                rs.getString("actor"), rs.getString("action"), rs.getString("target"), rs.getString("details_json"),
                rs.getString("result"), rs.getString("client_ip"), Db.instant(rs, "occurred_at")));
        return Page.of(rows, page, size);
    }

    public record AuditEntry(long auditId, String actor, String action, String target, String detailsJson,
                             String result, String clientIp, Instant occurredAt) {
    }
}
