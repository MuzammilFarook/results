package ie.aib.ioc.platform.core;

import java.time.Instant;

/**
 * What a topic's mapper turns an Avro event into. The internal domain state {@code S} is stable;
 * when the source schema changes, only the mapper changes.
 *
 * @param eventId         unique per business change (dedup)
 * @param entityKey       the record the event is about (version guard, coalescing, outbox ordering)
 * @param kind            upsert or delete
 * @param sourceVersion   monotonic per entity — "only apply if newer"
 * @param occurredAt      when the change happened at source
 * @param sourceSystem    e.g. Transact, Loan Accounting
 * @param producerTraceId trace id carried in the payload, if any
 * @param state           the full current state (a snapshot, never a delta)
 */
public record DecodedEvent<S>(
        String eventId,
        String entityKey,
        ChangeKind kind,
        long sourceVersion,
        Instant occurredAt,
        String sourceSystem,
        String producerTraceId,
        S state) {
}
