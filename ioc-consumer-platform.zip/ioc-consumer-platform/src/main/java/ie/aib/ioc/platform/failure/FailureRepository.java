package ie.aib.ioc.platform.failure;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import ie.aib.ioc.platform.core.Db;
import ie.aib.ioc.platform.core.FailureCategory;
import ie.aib.ioc.platform.core.InboundRecord.OffsetKey;
import ie.aib.ioc.platform.core.Page;
import ie.aib.ioc.platform.core.ProcessingMode;
import ie.aib.ioc.platform.failure.FailureModels.FailureAttempt;
import ie.aib.ioc.platform.failure.FailureModels.FailureFilter;
import ie.aib.ioc.platform.failure.FailureModels.FailureView;
import ie.aib.ioc.platform.failure.FailureModels.NewFailure;
import ie.aib.ioc.platform.failure.FailureModels.StoredFailure;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * The failure tray — one table for all topics, same process, same screen.
 *
 * <p>Claiming uses {@code UPDLOCK, READPAST} so several pods can run the replay timer without ever
 * replaying the same row twice (SQL Server's equivalent of {@code FOR UPDATE SKIP LOCKED}).
 */
@Repository
public class FailureRepository {

    public static final String AUTO_RETRY = "AUTO_RETRY";
    public static final String MANUAL = "MANUAL";
    public static final String IN_PROGRESS = "IN_PROGRESS";
    public static final String REPLAYED = "REPLAYED";
    public static final String DISCARDED = "DISCARDED";

    private static final String VIEW_COLUMNS = """
            failure_id, consumer_name, topic, kafka_partition, kafka_offset, kafka_timestamp, event_id, entity_key,
            source_version, schema_id, trace_id, error_category, error_class, error_message, attempt_count, status,
            next_attempt_at, first_failed_at, last_failed_at, resolved_at, resolved_by, resolution_note,
            DATALENGTH(payload) AS payload_bytes""";

    private static final String STORED_COLUMNS = """
            failure_id, consumer_name, topic, kafka_partition, kafka_offset, kafka_timestamp, event_id, entity_key,
            record_key, headers_json, payload, trace_id, error_category, status, attempt_count, next_attempt_at""";

    private final NamedParameterJdbcTemplate jdbc;
    private final ObjectMapper json;

    public FailureRepository(NamedParameterJdbcTemplate jdbc, ObjectMapper json) {
        this.jdbc = jdbc;
        this.json = json;
    }

    // ------------------------------------------------------------------ writes

    public long insert(NewFailure f, String status, Instant nextAttemptAt, ProcessingMode mode, String actor,
                       Long requestId, Instant now) {
        Long id = jdbc.queryForObject("""
                INSERT INTO event_failure (consumer_name, topic, kafka_partition, kafka_offset, kafka_timestamp, event_id,
                    entity_key, source_version, schema_id, record_key, headers_json, payload, trace_id, error_category,
                    error_class, error_message, attempt_count, status, next_attempt_at, first_failed_at, last_failed_at)
                OUTPUT INSERTED.failure_id
                VALUES (:c, :t, :p, :o, :kts, :eid, :ek, :ver, :sid, :key, :headers, :payload, :trace, :cat,
                    :eclass, :emsg, 1, :status, :next, :now, :now)
                """, new MapSqlParameterSource("c", f.consumerName()).addValue("t", f.topic())
                .addValue("p", f.partition()).addValue("o", f.offset()).addValue("kts", Db.utc(f.kafkaTimestamp()))
                .addValue("eid", f.eventId()).addValue("ek", f.entityKey()).addValue("ver", f.sourceVersion())
                .addValue("sid", f.schemaId()).addValue("key", f.recordKey(), Types.VARBINARY).addValue("headers", headersToJson(f.headers()))
                .addValue("payload", f.payload(), Types.VARBINARY).addValue("trace", f.traceId()).addValue("cat", f.category().name())
                .addValue("eclass", Db.truncate(f.errorClass(), 255)).addValue("emsg", Db.truncate(f.errorMessage(), 2000))
                .addValue("status", status).addValue("next", Db.utc(nextAttemptAt)).addValue("now", Db.utc(now)), Long.class);
        insertAttempt(id, 1, mode, actor, "FAILED", null, f.category().name(), f.errorClass(), f.errorMessage(), requestId, now);
        return id;
    }

    public void markReplayed(long failureId, ProcessingMode mode, String actor, Long requestId, String resultOutcome, Instant now) {
        Integer attemptNo = jdbc.queryForObject("""
                UPDATE event_failure SET status = 'REPLAYED', attempt_count = attempt_count + 1, resolved_at = :now,
                    resolved_by = :actor, resolution_note = :note, next_attempt_at = NULL, claimed_by = NULL, claim_expires_at = NULL
                OUTPUT INSERTED.attempt_count
                WHERE failure_id = :id
                """, new MapSqlParameterSource("id", failureId).addValue("now", Db.utc(now)).addValue("actor", actor)
                .addValue("note", "Replayed (" + mode + "): " + resultOutcome), Integer.class);
        insertAttempt(failureId, attemptNo, mode, actor, "SUCCEEDED", resultOutcome, null, null, null, requestId, now);
    }

    public void markAttemptFailed(long failureId, FailureCategory category, String errorClass, String errorMessage,
                                  String status, Instant nextAttemptAt, ProcessingMode mode, String actor,
                                  Long requestId, Instant now) {
        Integer attemptNo = jdbc.queryForObject("""
                UPDATE event_failure SET attempt_count = attempt_count + 1, status = :status, next_attempt_at = :next,
                    error_category = :cat, error_class = :eclass, error_message = :emsg, last_failed_at = :now,
                    claimed_by = NULL, claim_expires_at = NULL
                OUTPUT INSERTED.attempt_count
                WHERE failure_id = :id
                """, new MapSqlParameterSource("id", failureId).addValue("status", status)
                .addValue("next", Db.utc(nextAttemptAt)).addValue("cat", category.name())
                .addValue("eclass", Db.truncate(errorClass, 255)).addValue("emsg", Db.truncate(errorMessage, 2000))
                .addValue("now", Db.utc(now)), Integer.class);
        insertAttempt(failureId, attemptNo, mode, actor, "FAILED", null, category.name(), errorClass, errorMessage, requestId, now);
    }

    public boolean discard(long failureId, String actor, String reason, Instant now) {
        return jdbc.update("""
                UPDATE event_failure SET status = 'DISCARDED', resolved_at = :now, resolved_by = :actor,
                    resolution_note = :reason, next_attempt_at = NULL
                WHERE failure_id = :id AND status IN ('AUTO_RETRY', 'MANUAL')
                """, new MapSqlParameterSource("id", failureId).addValue("now", Db.utc(now)).addValue("actor", actor)
                .addValue("reason", Db.truncate(reason, 1000))) == 1;
    }

    // ------------------------------------------------------------------ claiming (replay)

    /** Claim one row for a manual replay. Empty if it is not in a replayable state. */
    public Optional<StoredFailure> claimById(long failureId, String owner, Instant until) {
        List<StoredFailure> rows = jdbc.query("""
                UPDATE event_failure WITH (ROWLOCK) SET status = 'IN_PROGRESS', claimed_by = :owner, claim_expires_at = :until
                OUTPUT %s
                WHERE failure_id = :id AND status IN ('AUTO_RETRY', 'MANUAL')
                """.formatted(inserted(STORED_COLUMNS)), new MapSqlParameterSource("id", failureId)
                .addValue("owner", owner).addValue("until", Db.utc(until)), STORED_MAPPER);
        return rows.stream().findFirst();
    }

    /** Claim the rows whose retry time has come. Safe with many pods (READPAST skips rows others hold). */
    public List<StoredFailure> claimDue(String consumer, String owner, Instant now, Instant until, int limit) {
        return jdbc.query("""
                WITH due AS (
                    SELECT TOP (:limit) * FROM event_failure WITH (UPDLOCK, READPAST, ROWLOCK)
                    WHERE consumer_name = :c AND status = 'AUTO_RETRY' AND next_attempt_at <= :now
                    ORDER BY next_attempt_at
                )
                UPDATE due SET status = 'IN_PROGRESS', claimed_by = :owner, claim_expires_at = :until
                OUTPUT %s
                """.formatted(inserted(STORED_COLUMNS)), new MapSqlParameterSource("c", consumer).addValue("owner", owner)
                .addValue("now", Db.utc(now)).addValue("until", Db.utc(until)).addValue("limit", limit), STORED_MAPPER);
    }

    /** A pod died mid-replay: hand its claims back. */
    public int releaseExpiredClaims(Instant now) {
        return jdbc.update("""
                UPDATE event_failure SET status = CASE WHEN next_attempt_at IS NULL THEN 'MANUAL' ELSE 'AUTO_RETRY' END,
                    claimed_by = NULL, claim_expires_at = NULL
                WHERE status = 'IN_PROGRESS' AND claim_expires_at < :now
                """, new MapSqlParameterSource("now", Db.utc(now)));
    }

    /** Give a claim back unchanged (e.g. the platform went down mid-replay — not the record's fault). */
    public void release(long failureId) {
        jdbc.update("""
                UPDATE event_failure SET status = CASE WHEN next_attempt_at IS NULL THEN 'MANUAL' ELSE 'AUTO_RETRY' END,
                    claimed_by = NULL, claim_expires_at = NULL
                WHERE failure_id = :id AND status = 'IN_PROGRESS'
                """, new MapSqlParameterSource("id", failureId));
    }

    // ------------------------------------------------------------------ reads

    public Optional<Long> findIdByOffset(String consumer, OffsetKey key) {
        return jdbc.queryForList("""
                SELECT failure_id FROM event_failure WHERE consumer_name = :c AND topic = :t AND kafka_partition = :p AND kafka_offset = :o
                """, new MapSqlParameterSource("c", consumer).addValue("t", key.topic()).addValue("p", key.partition())
                .addValue("o", key.offset()), Long.class).stream().findFirst();
    }

    public int attemptCount(long failureId) {
        Integer n = jdbc.queryForObject("SELECT attempt_count FROM event_failure WHERE failure_id = :id",
                new MapSqlParameterSource("id", failureId), Integer.class);
        return n == null ? 0 : n;
    }

    public Optional<FailureView> findView(long failureId) {
        return jdbc.query("SELECT " + VIEW_COLUMNS + " FROM event_failure WHERE failure_id = :id",
                new MapSqlParameterSource("id", failureId), VIEW_MAPPER).stream().findFirst();
    }

    public Optional<StoredFailure> findStored(long failureId) {
        return jdbc.query("SELECT " + STORED_COLUMNS + " FROM event_failure WHERE failure_id = :id",
                new MapSqlParameterSource("id", failureId), STORED_MAPPER).stream().findFirst();
    }

    public List<FailureAttempt> attempts(long failureId) {
        return jdbc.query("""
                SELECT attempt_id, attempt_no, processing_mode, actor, result, result_outcome, error_category, error_class,
                    error_message, replay_request_id, attempted_at
                FROM event_failure_attempt WHERE failure_id = :id ORDER BY attempt_no, attempt_id
                """, new MapSqlParameterSource("id", failureId), (rs, i) -> new FailureAttempt(rs.getLong("attempt_id"),
                rs.getInt("attempt_no"), rs.getString("processing_mode"), rs.getString("actor"), rs.getString("result"),
                rs.getString("result_outcome"), rs.getString("error_category"), rs.getString("error_class"),
                rs.getString("error_message"), Db.nullableLong(rs, "replay_request_id"), Db.instant(rs, "attempted_at")));
    }

    public Page<FailureView> search(FailureFilter f, int page, int size) {
        MapSqlParameterSource p = new MapSqlParameterSource();
        String where = where(f, p, false);
        p.addValue("skip", page * size).addValue("take", size + 1);
        return Page.of(jdbc.query("SELECT " + VIEW_COLUMNS + " FROM event_failure WHERE " + where
                + " ORDER BY failure_id DESC OFFSET :skip ROWS FETCH NEXT :take ROWS ONLY", p, VIEW_MAPPER), page, size);
    }

    /** Dry-run count: how many rows a bulk replay with this filter would touch (only replayable rows). */
    public long countReplayable(FailureFilter f) {
        MapSqlParameterSource p = new MapSqlParameterSource();
        Long n = jdbc.queryForObject("SELECT COUNT_BIG(*) FROM event_failure WHERE " + where(f, p, true), p, Long.class);
        return n == null ? 0 : n;
    }

    /** Keyset paging over replayable ids for bulk replay. */
    public List<Long> replayableIds(FailureFilter f, long afterId, int limit) {
        MapSqlParameterSource p = new MapSqlParameterSource();
        String where = where(f, p, true);
        p.addValue("after", afterId).addValue("limit", limit);
        return jdbc.queryForList("SELECT TOP (:limit) failure_id FROM event_failure WHERE " + where
                + " AND failure_id > :after ORDER BY failure_id", p, Long.class);
    }

    public Map<String, Long> openByCategory(String consumer) {
        Map<String, Long> out = new LinkedHashMap<>();
        jdbc.query("""
                SELECT error_category, COUNT_BIG(*) AS n FROM event_failure
                WHERE consumer_name = :c AND status IN ('AUTO_RETRY', 'MANUAL', 'IN_PROGRESS') GROUP BY error_category
                """, new MapSqlParameterSource("c", consumer), rs -> { out.put(rs.getString("error_category"), rs.getLong("n")); });
        return out;
    }

    public Map<String, Long> countByStatus(String consumer) {
        Map<String, Long> out = new HashMap<>();
        jdbc.query("SELECT status, COUNT_BIG(*) AS n FROM event_failure WHERE consumer_name = :c GROUP BY status",
                new MapSqlParameterSource("c", consumer), rs -> { out.put(rs.getString("status"), rs.getLong("n")); });
        return out;
    }

    public List<FailureView> findForTrace(String consumer, String term) {
        return jdbc.query("SELECT TOP (50) " + VIEW_COLUMNS + " FROM event_failure WHERE consumer_name = :c AND "
                        + "(event_id = :term OR trace_id = :term OR entity_key = :term) ORDER BY failure_id DESC",
                new MapSqlParameterSource("c", consumer).addValue("term", term), VIEW_MAPPER);
    }

    public Optional<FailureView> findViewByOffset(String consumer, OffsetKey key) {
        return jdbc.query("SELECT " + VIEW_COLUMNS + " FROM event_failure WHERE consumer_name = :c AND topic = :t"
                        + " AND kafka_partition = :p AND kafka_offset = :o",
                new MapSqlParameterSource("c", consumer).addValue("t", key.topic()).addValue("p", key.partition())
                        .addValue("o", key.offset()), VIEW_MAPPER).stream().findFirst();
    }

    // ------------------------------------------------------------------ helpers

    public Map<String, byte[]> headersFromJson(String headersJson) {
        if (headersJson == null || headersJson.isBlank()) {
            return Map.of();
        }
        try {
            Map<String, String> encoded = json.readValue(headersJson, new TypeReference<LinkedHashMap<String, String>>() { });
            Map<String, byte[]> out = new LinkedHashMap<>();
            encoded.forEach((k, v) -> out.put(k, v == null ? null : Base64.getDecoder().decode(v)));
            return out;
        } catch (JsonProcessingException e) {
            throw new IllegalStateException("Unreadable headers_json", e);
        }
    }

    private String headersToJson(Map<String, byte[]> headers) {
        if (headers == null || headers.isEmpty()) {
            return null;
        }
        Map<String, String> encoded = new LinkedHashMap<>();
        headers.forEach((k, v) -> encoded.put(k, v == null ? null : Base64.getEncoder().encodeToString(v)));
        try {
            return json.writeValueAsString(encoded);
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(e);
        }
    }

    private void insertAttempt(long failureId, Integer attemptNo, ProcessingMode mode, String actor, String result,
                               String resultOutcome, String category, String errorClass, String errorMessage,
                               Long requestId, Instant now) {
        jdbc.update("""
                INSERT INTO event_failure_attempt (failure_id, attempt_no, processing_mode, actor, result, result_outcome,
                    error_category, error_class, error_message, replay_request_id, attempted_at)
                VALUES (:id, :no, :mode, :actor, :result, :ro, :cat, :eclass, :emsg, :req, :now)
                """, new MapSqlParameterSource("id", failureId).addValue("no", attemptNo == null ? 0 : attemptNo)
                .addValue("mode", mode.name()).addValue("actor", actor).addValue("result", result)
                .addValue("ro", resultOutcome).addValue("cat", category).addValue("eclass", Db.truncate(errorClass, 255))
                .addValue("emsg", Db.truncate(errorMessage, 2000)).addValue("req", requestId).addValue("now", Db.utc(now)));
    }

    private static String where(FailureFilter f, MapSqlParameterSource p, boolean replayableOnly) {
        StringBuilder w = new StringBuilder("consumer_name = :c");
        p.addValue("c", f.consumer());
        if (replayableOnly) {
            w.append(" AND status IN ('AUTO_RETRY', 'MANUAL')");
            if (f.status() != null && (AUTO_RETRY.equals(f.status()) || MANUAL.equals(f.status()))) {
                w.append(" AND status = :status");
                p.addValue("status", f.status());
            }
        } else if (f.status() != null) {
            w.append(" AND status = :status");
            p.addValue("status", f.status());
        }
        if (f.category() != null) { w.append(" AND error_category = :cat"); p.addValue("cat", f.category()); }
        if (f.entityKey() != null) { w.append(" AND entity_key = :ek"); p.addValue("ek", f.entityKey()); }
        if (f.errorClassContains() != null) { w.append(" AND error_class LIKE :ecl"); p.addValue("ecl", "%" + f.errorClassContains() + "%"); }
        if (f.topic() != null) { w.append(" AND topic = :topic"); p.addValue("topic", f.topic()); }
        if (f.partition() != null) { w.append(" AND kafka_partition = :part"); p.addValue("part", f.partition()); }
        if (f.from() != null) { w.append(" AND first_failed_at >= :from"); p.addValue("from", Db.utc(f.from())); }
        if (f.to() != null) { w.append(" AND first_failed_at < :to"); p.addValue("to", Db.utc(f.to())); }
        return w.toString();
    }

    private static String inserted(String columns) {
        StringBuilder sb = new StringBuilder();
        for (String c : columns.split(",")) {
            if (!sb.isEmpty()) {
                sb.append(", ");
            }
            sb.append("INSERTED.").append(c.trim());
        }
        return sb.toString();
    }

    private static final RowMapper<StoredFailure> STORED_MAPPER = (rs, i) -> new StoredFailure(
            rs.getLong("failure_id"), rs.getString("consumer_name"), rs.getString("topic"), rs.getInt("kafka_partition"),
            rs.getLong("kafka_offset"), Db.instant(rs, "kafka_timestamp"), rs.getString("event_id"),
            rs.getString("entity_key"), rs.getBytes("record_key"), rs.getString("headers_json"), rs.getBytes("payload"),
            rs.getString("trace_id"), rs.getString("error_category"), rs.getString("status"),
            rs.getInt("attempt_count"), Db.instant(rs, "next_attempt_at"));

    private static final RowMapper<FailureView> VIEW_MAPPER = FailureRepository::mapView;

    private static FailureView mapView(ResultSet rs, int i) throws SQLException {
        return new FailureView(rs.getLong("failure_id"), rs.getString("consumer_name"), rs.getString("topic"),
                rs.getInt("kafka_partition"), rs.getLong("kafka_offset"), Db.instant(rs, "kafka_timestamp"),
                rs.getString("event_id"), rs.getString("entity_key"), Db.nullableLong(rs, "source_version"),
                Db.nullableInt(rs, "schema_id"), rs.getString("trace_id"), rs.getString("error_category"),
                rs.getString("error_class"), rs.getString("error_message"), rs.getInt("attempt_count"),
                rs.getString("status"), Db.instant(rs, "next_attempt_at"), Db.instant(rs, "first_failed_at"),
                Db.instant(rs, "last_failed_at"), Db.instant(rs, "resolved_at"), rs.getString("resolved_by"),
                rs.getString("resolution_note"), rs.getInt("payload_bytes"));
    }
}
