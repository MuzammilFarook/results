package ie.aib.ioc.platform.replay;

import java.time.Clock;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.EventPipeline;
import ie.aib.ioc.platform.core.PlatformHealth;
import ie.aib.ioc.platform.core.PlatformUnavailableException;
import ie.aib.ioc.platform.core.ReplayContext;
import ie.aib.ioc.platform.failure.FailureModels.StoredFailure;
import ie.aib.ioc.platform.failure.FailureRepository;
import ie.aib.ioc.platform.kafka.PipelineRegistry;
import ie.aib.ioc.platform.observability.EventLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * The replay timer. Retries tray rows whose time has come (DEPENDENCY_MISSING, TRANSIENT_EXHAUSTED),
 * slowly, through the normal pipeline.
 *
 * <pre>
 *   10:00  Covenant arrives. CCV missing → failure tray (retry 10:01)
 *   10:01  Retry → CCV still missing (retry 10:06)
 *   10:06  Retry → CCV still missing (retry 10:21)
 *   10:20  CCV letter arrives and is processed
 *   10:21  Retry → CCV found → covenant processed ✔ (ledger: FAILED → REPLAYED)
 * </pre>
 * It does nothing while the platform is down — those rows wait; nothing is burned through the schedule.
 */
@Component
public class AutoReplayScheduler {

    private static final Logger log = LoggerFactory.getLogger(AutoReplayScheduler.class);

    private final PipelineRegistry registry;
    private final FailureRepository failures;
    private final ReplayService replay;
    private final PlatformHealth health;
    private final EventLog eventLog;
    private final IocPlatformProperties props;
    private final Clock clock;

    public AutoReplayScheduler(PipelineRegistry registry, FailureRepository failures, ReplayService replay,
                               PlatformHealth health, EventLog eventLog, IocPlatformProperties props, Clock clock) {
        this.registry = registry;
        this.failures = failures;
        this.replay = replay;
        this.health = health;
        this.eventLog = eventLog;
        this.props = props;
        this.clock = clock;
    }

    @Scheduled(fixedDelayString = "${ioc.platform.auto-replay.poll-interval-ms:30000}")
    public void run() {
        if (!props.getAutoReplay().isEnabled() || health.isDown()) {
            return;
        }
        try {
            int released = failures.releaseExpiredClaims(clock.instant());
            if (released > 0) {
                eventLog.lifecycle("replay.claims.released", Map.of("count", released));
            }
            RateLimiter limiter = new RateLimiter(props.getAutoReplay().getRatePerSecond());
            for (EventPipeline<?, ?> p : registry.all()) {
                Instant now = clock.instant();
                List<StoredFailure> due = failures.claimDue(p.consumerName(), props.getInstanceId(), now,
                        now.plus(props.getAutoReplay().getClaimTimeout()), props.getAutoReplay().getClaimBatchSize());
                for (int i = 0; i < due.size(); i++) {
                    limiter.acquire();
                    try {
                        replay.runClaimed(due.get(i), ReplayContext.AUTO);
                    } catch (PlatformUnavailableException e) {
                        // runClaimed already released row i; hand the rest back untouched and stop.
                        for (int j = i + 1; j < due.size(); j++) {
                            failures.release(due.get(j).failureId());
                        }
                        log.warn("Auto replay paused: platform unavailable ({})", e.getMessage());
                        return;
                    }
                }
            }
        } catch (RuntimeException e) {
            log.warn("Auto replay round failed: {}", e.getMessage());
        }
    }
}
