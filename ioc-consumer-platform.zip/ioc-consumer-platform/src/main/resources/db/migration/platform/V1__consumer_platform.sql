-- =====================================================================================
-- IOC consumer platform tables (Azure SQL / SQL Server).
-- Shared by every IOC consumer. One ledger, one failure tray, one outbox, one replay path.
-- =====================================================================================

-- -------------------------------------------------------------------------------------
-- 1. EVENT LEDGER — exactly one row per Kafka record (consumer, topic, partition, offset).
--    'outcome' is the CURRENT terminal state. Every later change of outcome (e.g. FAILED →
--    REPLAYED) is also written to event_ledger_transition, so the history is never lost.
--
--    Production note: partition this table by business_date (monthly/daily partition
--    function) and purge the hot window with SWITCH PARTITION. Older rows go to the cold
--    archive (ADLS / Parquet). The unique key then needs business_date added to be aligned.
-- -------------------------------------------------------------------------------------
CREATE TABLE event_ledger (
    ledger_id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_event_ledger PRIMARY KEY,
    consumer_name        VARCHAR(100)   NOT NULL,
    topic                VARCHAR(249)   NOT NULL,
    kafka_partition      INT            NOT NULL,
    kafka_offset         BIGINT         NOT NULL,
    kafka_timestamp      DATETIME2(3)   NULL,
    event_id             VARCHAR(100)   NULL,      -- null only if the record could not be decoded
    entity_key           VARCHAR(255)   NULL,
    source_version       BIGINT         NULL,
    schema_id            INT            NULL,
    payload_sha256       BINARY(32)     NOT NULL,  -- fingerprint of the exact bytes received
    payload              VARBINARY(MAX) NULL,      -- only for evidence level FULL topics
    trace_id             VARCHAR(64)    NOT NULL,
    outcome              VARCHAR(20)    NOT NULL,  -- PROCESSED|DUPLICATE|STALE|SUPERSEDED|FILTERED|FAILED|REPLAYED
    outcome_detail       VARCHAR(400)   NULL,
    material             BIT            NOT NULL CONSTRAINT df_ledger_material DEFAULT 0,
    processing_mode      VARCHAR(20)    NOT NULL,  -- LIVE|AUTO_REPLAY|MANUAL_REPLAY|KAFKA_REREAD
    instance_id          VARCHAR(100)   NOT NULL,
    business_date        DATE           NOT NULL,
    received_at          DATETIME2(3)   NOT NULL,
    processed_at         DATETIME2(3)   NOT NULL,
    last_changed_at      DATETIME2(3)   NOT NULL,
    CONSTRAINT uq_ledger_offset UNIQUE (consumer_name, topic, kafka_partition, kafka_offset),
    CONSTRAINT ck_ledger_outcome CHECK (outcome IN
        ('PROCESSED','DUPLICATE','STALE','SUPERSEDED','FILTERED','FAILED','REPLAYED'))
);
CREATE INDEX ix_ledger_event_id   ON event_ledger (consumer_name, event_id) INCLUDE (outcome, kafka_partition, kafka_offset);
CREATE INDEX ix_ledger_entity_key ON event_ledger (consumer_name, entity_key, received_at);
CREATE INDEX ix_ledger_trace_id   ON event_ledger (trace_id);
CREATE INDEX ix_ledger_received   ON event_ledger (consumer_name, received_at) INCLUDE (outcome);
CREATE INDEX ix_ledger_bizdate    ON event_ledger (consumer_name, topic, business_date) INCLUDE (outcome);

CREATE TABLE event_ledger_transition (
    transition_id        BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_ledger_transition PRIMARY KEY,
    ledger_id            BIGINT         NOT NULL CONSTRAINT fk_transition_ledger REFERENCES event_ledger (ledger_id),
    from_outcome         VARCHAR(20)    NOT NULL,
    to_outcome           VARCHAR(20)    NOT NULL,
    detail               VARCHAR(400)   NULL,
    processing_mode      VARCHAR(20)    NOT NULL,
    actor                VARCHAR(100)   NOT NULL,   -- 'system' or the ops user
    replay_request_id    BIGINT         NULL,
    changed_at           DATETIME2(3)   NOT NULL
);
CREATE INDEX ix_transition_ledger ON event_ledger_transition (ledger_id);

-- -------------------------------------------------------------------------------------
-- 2. FAILURE TRAY — one table for every topic. Raw bytes are kept so ANY failure,
--    including undecodable Avro, can be replayed after a fix.
-- -------------------------------------------------------------------------------------
CREATE TABLE event_failure (
    failure_id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_event_failure PRIMARY KEY,
    consumer_name        VARCHAR(100)   NOT NULL,
    topic                VARCHAR(249)   NOT NULL,
    kafka_partition      INT            NOT NULL,
    kafka_offset         BIGINT         NOT NULL,
    kafka_timestamp      DATETIME2(3)   NULL,
    event_id             VARCHAR(100)   NULL,
    entity_key           VARCHAR(255)   NULL,
    source_version       BIGINT         NULL,
    schema_id            INT            NULL,
    record_key           VARBINARY(4000) NULL,
    headers_json         NVARCHAR(MAX)  NULL,
    payload              VARBINARY(MAX) NULL,
    trace_id             VARCHAR(64)    NOT NULL,
    error_category       VARCHAR(30)    NOT NULL,   -- DESERIALISATION|VALIDATION|DEPENDENCY_MISSING|CONFLICT|TRANSIENT_EXHAUSTED|UNKNOWN
    error_class          VARCHAR(255)   NOT NULL,
    error_message        NVARCHAR(2000) NULL,
    attempt_count        INT            NOT NULL CONSTRAINT df_failure_attempts DEFAULT 1,
    status               VARCHAR(20)    NOT NULL,   -- AUTO_RETRY|MANUAL|IN_PROGRESS|REPLAYED|DISCARDED
    next_attempt_at      DATETIME2(3)   NULL,
    claimed_by           VARCHAR(100)   NULL,
    claim_expires_at     DATETIME2(3)   NULL,
    first_failed_at      DATETIME2(3)   NOT NULL,
    last_failed_at       DATETIME2(3)   NOT NULL,
    resolved_at          DATETIME2(3)   NULL,
    resolved_by          VARCHAR(100)   NULL,
    resolution_note      NVARCHAR(1000) NULL,
    CONSTRAINT uq_failure_offset UNIQUE (consumer_name, topic, kafka_partition, kafka_offset),
    CONSTRAINT ck_failure_status CHECK (status IN ('AUTO_RETRY','MANUAL','IN_PROGRESS','REPLAYED','DISCARDED'))
);
CREATE INDEX ix_failure_due      ON event_failure (status, next_attempt_at) INCLUDE (consumer_name);
CREATE INDEX ix_failure_category ON event_failure (consumer_name, error_category, status, first_failed_at);
CREATE INDEX ix_failure_entity   ON event_failure (consumer_name, entity_key);
CREATE INDEX ix_failure_trace    ON event_failure (trace_id);

-- Every attempt (first failure, each auto retry, each manual replay) — "how many times
-- was this retried, by whom, and what happened each time?"
CREATE TABLE event_failure_attempt (
    attempt_id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_failure_attempt PRIMARY KEY,
    failure_id           BIGINT         NOT NULL CONSTRAINT fk_attempt_failure REFERENCES event_failure (failure_id),
    attempt_no           INT            NOT NULL,
    processing_mode      VARCHAR(20)    NOT NULL,
    actor                VARCHAR(100)   NOT NULL,
    result               VARCHAR(20)    NOT NULL,   -- FAILED|SUCCEEDED
    result_outcome       VARCHAR(20)    NULL,       -- ledger outcome when it succeeded
    error_category       VARCHAR(30)    NULL,
    error_class          VARCHAR(255)   NULL,
    error_message        NVARCHAR(2000) NULL,
    replay_request_id    BIGINT         NULL,
    attempted_at         DATETIME2(3)   NOT NULL
);
CREATE INDEX ix_attempt_failure ON event_failure_attempt (failure_id);

-- -------------------------------------------------------------------------------------
-- 3. OUTBOX — written in the SAME transaction as the state change. The publisher sends it
--    later and records where it landed (topic/partition/offset) as evidence.
--    shard = hash(aggregate_key) % N, one publisher per shard ⇒ per-entity order kept.
-- -------------------------------------------------------------------------------------
CREATE TABLE outbox (
    outbox_id            BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_outbox PRIMARY KEY,
    event_id             VARCHAR(100)   NOT NULL CONSTRAINT uq_outbox_event UNIQUE,
    shard                SMALLINT       NOT NULL,
    aggregate_type       VARCHAR(50)    NOT NULL,
    aggregate_key        VARCHAR(255)   NOT NULL,
    aggregate_version    BIGINT         NOT NULL,
    change_type          VARCHAR(60)    NOT NULL,
    reasons              VARCHAR(1000)  NULL,
    rule_version         VARCHAR(50)    NULL,
    consumer_name        VARCHAR(100)   NOT NULL,
    source_system        VARCHAR(100)   NOT NULL,
    source_topic         VARCHAR(249)   NOT NULL,
    source_partition     INT            NOT NULL,
    source_offset        BIGINT         NOT NULL,
    source_event_id      VARCHAR(100)   NOT NULL,
    trace_id             VARCHAR(64)    NOT NULL,
    status               VARCHAR(10)    NOT NULL,   -- PENDING|SENT
    attempts             INT            NOT NULL CONSTRAINT df_outbox_attempts DEFAULT 0,
    last_error           NVARCHAR(1000) NULL,
    created_at           DATETIME2(3)   NOT NULL,
    sent_at              DATETIME2(3)   NULL,
    sent_topic           VARCHAR(249)   NULL,
    sent_partition       INT            NULL,
    sent_offset          BIGINT         NULL,
    CONSTRAINT ck_outbox_status CHECK (status IN ('PENDING','SENT'))
);
CREATE INDEX ix_outbox_pending ON outbox (shard, status, outbox_id);
CREATE INDEX ix_outbox_source  ON outbox (consumer_name, source_topic, source_partition, source_offset);
CREATE INDEX ix_outbox_trace   ON outbox (trace_id);
CREATE INDEX ix_outbox_key     ON outbox (aggregate_key);

CREATE TABLE outbox_shard_lease (
    shard                SMALLINT       NOT NULL CONSTRAINT pk_outbox_lease PRIMARY KEY,
    owner_id             VARCHAR(100)   NULL,
    lease_until          DATETIME2(3)   NOT NULL,
    epoch                BIGINT         NOT NULL
);

-- Live publisher instances, so shards are shared fairly (16 shards / 3 pods ≈ 6 each).
CREATE TABLE outbox_publisher_heartbeat (
    instance_id          VARCHAR(100)   NOT NULL CONSTRAINT pk_publisher_hb PRIMARY KEY,
    heartbeat_at         DATETIME2(3)   NOT NULL
);

-- -------------------------------------------------------------------------------------
-- 4. REPLAY REQUESTS — manual bulk replay with dry-run counts, four-eyes approval and
--    progress. Types: FAILURES (from the tray by filter) and KAFKA_RANGE (re-read offsets).
-- -------------------------------------------------------------------------------------
CREATE TABLE replay_request (
    request_id           BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_replay_request PRIMARY KEY,
    consumer_name        VARCHAR(100)   NOT NULL,
    request_type         VARCHAR(20)    NOT NULL,   -- FAILURES|KAFKA_RANGE
    filter_json          NVARCHAR(4000) NOT NULL,
    reason               NVARCHAR(1000) NOT NULL,
    expected_count       BIGINT         NOT NULL,
    status               VARCHAR(20)    NOT NULL,   -- PENDING_APPROVAL|APPROVED|RUNNING|COMPLETED|FAILED|REJECTED|CANCELLED
    requested_by         VARCHAR(100)   NOT NULL,
    requested_at         DATETIME2(3)   NOT NULL,
    decided_by           VARCHAR(100)   NULL,
    decided_at           DATETIME2(3)   NULL,
    decision_note        NVARCHAR(1000) NULL,
    claimed_by           VARCHAR(100)   NULL,
    started_at           DATETIME2(3)   NULL,
    completed_at         DATETIME2(3)   NULL,
    processed_count      BIGINT         NOT NULL CONSTRAINT df_rr_processed DEFAULT 0,
    succeeded_count      BIGINT         NOT NULL CONSTRAINT df_rr_succeeded DEFAULT 0,
    failed_count         BIGINT         NOT NULL CONSTRAINT df_rr_failed DEFAULT 0,
    last_error           NVARCHAR(1000) NULL,
    CONSTRAINT ck_rr_four_eyes CHECK (decided_by IS NULL OR decided_by <> requested_by)
);
CREATE INDEX ix_replay_status ON replay_request (status, requested_at);

-- -------------------------------------------------------------------------------------
-- 5. OPS AUDIT — who did what, when, with which filter, and what happened.
-- -------------------------------------------------------------------------------------
CREATE TABLE ops_audit (
    audit_id             BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_ops_audit PRIMARY KEY,
    actor                VARCHAR(100)   NOT NULL,
    action               VARCHAR(60)    NOT NULL,
    target               VARCHAR(255)   NULL,
    details_json         NVARCHAR(4000) NULL,
    result               VARCHAR(20)    NOT NULL,
    client_ip            VARCHAR(64)    NULL,
    occurred_at          DATETIME2(3)   NOT NULL
);
CREATE INDEX ix_audit_time ON ops_audit (occurred_at);

-- -------------------------------------------------------------------------------------
-- 6. PER-MINUTE STATS — the same numbers as the Splunk summary line, kept for the console.
-- -------------------------------------------------------------------------------------
CREATE TABLE consumer_stats_minute (
    consumer_name        VARCHAR(100)   NOT NULL,
    instance_id          VARCHAR(100)   NOT NULL,
    minute_start         DATETIME2(0)   NOT NULL,
    consumed             BIGINT NOT NULL, processed  BIGINT NOT NULL, duplicate  BIGINT NOT NULL,
    stale                BIGINT NOT NULL, superseded BIGINT NOT NULL, filtered   BIGINT NOT NULL,
    failed               BIGINT NOT NULL, replayed   BIGINT NOT NULL, retried    BIGINT NOT NULL,
    redelivered          BIGINT NOT NULL, published  BIGINT NOT NULL, material   BIGINT NOT NULL,
    paused_ms            BIGINT NOT NULL, p95_batch_ms BIGINT NOT NULL,
    CONSTRAINT pk_stats_minute PRIMARY KEY (consumer_name, minute_start, instance_id)
);

-- -------------------------------------------------------------------------------------
-- 7. RECONCILIATION — offset gaps (intraday) and producer control totals (EOD).
-- -------------------------------------------------------------------------------------
CREATE TABLE offset_gap (
    gap_id               BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT pk_offset_gap PRIMARY KEY,
    consumer_name        VARCHAR(100)   NOT NULL,
    topic                VARCHAR(249)   NOT NULL,
    kafka_partition      INT            NOT NULL,
    from_offset          BIGINT         NOT NULL,
    to_offset            BIGINT         NOT NULL,
    missing_count        BIGINT         NOT NULL,
    status               VARCHAR(20)    NOT NULL,   -- OPEN|EXPLAINED|RESOLVED
    note                 NVARCHAR(1000) NULL,
    detected_at          DATETIME2(3)   NOT NULL,
    CONSTRAINT uq_offset_gap UNIQUE (consumer_name, topic, kafka_partition, from_offset)
);

CREATE TABLE gap_check_checkpoint (
    consumer_name        VARCHAR(100)   NOT NULL,
    topic                VARCHAR(249)   NOT NULL,
    kafka_partition      INT            NOT NULL,
    checked_to_offset    BIGINT         NOT NULL,
    checked_at           DATETIME2(3)   NOT NULL,
    CONSTRAINT pk_gap_checkpoint PRIMARY KEY (consumer_name, topic, kafka_partition)
);

CREATE TABLE control_total (
    consumer_name        VARCHAR(100)   NOT NULL,
    topic                VARCHAR(249)   NOT NULL,
    business_date        DATE           NOT NULL,
    producer_count       BIGINT         NULL,      -- "SecDB says: yesterday I sent 1,204"
    ioc_count            BIGINT         NULL,      -- "IOC says: yesterday I received 1,204"
    status               VARCHAR(20)    NOT NULL,  -- AWAITING_PRODUCER|MATCHED|MISMATCH
    submitted_by         VARCHAR(100)   NULL,
    reconciled_at        DATETIME2(3)   NULL,
    CONSTRAINT pk_control_total PRIMARY KEY (consumer_name, topic, business_date)
);
