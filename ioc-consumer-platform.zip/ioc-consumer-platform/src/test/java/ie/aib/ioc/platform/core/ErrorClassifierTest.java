package ie.aib.ioc.platform.core;

import java.net.ConnectException;
import java.sql.SQLException;

import ie.aib.ioc.platform.core.ErrorClassifier.ErrorClass;
import ie.aib.ioc.platform.core.ErrorClassifier.Phase;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import org.apache.kafka.common.errors.SerializationException;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.UncategorizedSQLException;

import static org.assertj.core.api.Assertions.assertThat;

/** "A bad letter goes to the failure tray. A broken system makes the clerk wait." */
class ErrorClassifierTest {

    private final ErrorClassifier classifier = new ErrorClassifier();

    @Test
    void databaseUnreachableIsPlatform() {
        assertThat(classifier.classify(new CannotGetJdbcConnectionException("no connection"))).isEqualTo(ErrorClass.PLATFORM);
        assertThat(classifier.classify(wrap(new SQLException("link failure", "08S01")))).isEqualTo(ErrorClass.PLATFORM);
        assertThat(classifier.classify(wrap(new SQLException("Database is not currently available", "S0001", 40613)))).isEqualTo(ErrorClass.PLATFORM);
    }

    @Test
    void deadlockAndThrottlingAreTransient() {
        assertThat(classifier.classify(wrap(new SQLException("deadlock victim", "40001", 1205)))).isEqualTo(ErrorClass.TRANSIENT);
        assertThat(classifier.classify(wrap(new SQLException("service busy", "S0001", 40501)))).isEqualTo(ErrorClass.TRANSIENT);
    }

    @Test
    void schemaRegistryDownIsPlatformButUnknownSchemaIsData() {
        SerializationException down = new SerializationException("Error retrieving schema", new RestClientException("unavailable", 503, 50301));
        SerializationException unknown = new SerializationException("Error retrieving schema", new RestClientException("Schema not found", 404, 40403));
        assertThat(classifier.classify(down)).isEqualTo(ErrorClass.PLATFORM);
        assertThat(classifier.classify(unknown)).isEqualTo(ErrorClass.DATA);
        assertThat(classifier.classify(new SerializationException("x", new ConnectException("refused")))).isEqualTo(ErrorClass.PLATFORM);
    }

    @Test
    void corruptBytesAreDeserialisationFailures() {
        SerializationException corrupt = new SerializationException("Unknown magic byte!");
        assertThat(classifier.classify(corrupt)).isEqualTo(ErrorClass.DATA);
        assertThat(classifier.category(corrupt, Phase.DESERIALISE, ErrorClass.DATA)).isEqualTo(FailureCategory.DESERIALISATION);
    }

    @Test
    void contractBreachesKeepTheirCategoryWhereverTheyHappen() {
        assertThat(classifier.category(new ValidationException("blank id"), Phase.PERSIST, ErrorClass.DATA)).isEqualTo(FailureCategory.VALIDATION);
        assertThat(classifier.category(new ConflictException("v5 differs"), Phase.PERSIST, ErrorClass.DATA)).isEqualTo(FailureCategory.CONFLICT);
        assertThat(classifier.category(new DependencyMissingException("CCV"), Phase.MAP, ErrorClass.DATA)).isEqualTo(FailureCategory.DEPENDENCY_MISSING);
        assertThat(classifier.category(new IllegalStateException("bug"), Phase.PERSIST, ErrorClass.DATA)).isEqualTo(FailureCategory.UNKNOWN);
        assertThat(classifier.category(new RuntimeException("timeout"), Phase.PERSIST, ErrorClass.TRANSIENT)).isEqualTo(FailureCategory.TRANSIENT_EXHAUSTED);
    }

    @Test
    void onlyRetryableCategoriesAreAutoRetried() {
        assertThat(FailureCategory.TRANSIENT_EXHAUSTED.autoRetry()).isTrue();
        assertThat(FailureCategory.DEPENDENCY_MISSING.autoRetry()).isTrue();
        assertThat(FailureCategory.VALIDATION.autoRetry()).isFalse();
        assertThat(FailureCategory.DESERIALISATION.autoRetry()).isFalse();
        assertThat(FailureCategory.CONFLICT.autoRetry()).isFalse();
    }

    private static UncategorizedSQLException wrap(SQLException e) {
        return new UncategorizedSQLException("test", "SELECT 1", e);
    }
}
