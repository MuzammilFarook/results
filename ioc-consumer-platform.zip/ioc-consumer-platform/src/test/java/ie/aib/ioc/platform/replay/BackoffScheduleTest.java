package ie.aib.ioc.platform.replay;

import java.time.Duration;
import java.time.Instant;

import ie.aib.ioc.platform.config.IocPlatformProperties;
import ie.aib.ioc.platform.core.FailureCategory;
import ie.aib.ioc.platform.core.ProcessingMode;
import ie.aib.ioc.platform.failure.FailureRepository;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

/** "Retries get further apart: 1 minute, 5 minutes, 15 minutes, 1 hour, 4 hours. After that, a person looks at it." */
class BackoffScheduleTest {

    private final BackoffSchedule schedule = new BackoffSchedule(new IocPlatformProperties());
    private final Instant now = Instant.parse("2026-10-27T10:00:00Z");

    @ParameterizedTest
    @CsvSource({"1,PT1M", "2,PT5M", "3,PT15M", "4,PT1H", "5,PT4H"})
    void retryableFailuresFollowTheSchedule(int failuresSoFar, String wait) {
        BackoffSchedule.Decision d = schedule.next(FailureCategory.TRANSIENT_EXHAUSTED, failuresSoFar, ProcessingMode.AUTO_REPLAY, now);
        assertThat(d.status()).isEqualTo(FailureRepository.AUTO_RETRY);
        assertThat(d.nextAttemptAt()).isEqualTo(now.plus(Duration.parse(wait)));
    }

    @Test
    void afterTheLastStepAPersonLooksAtIt() {
        BackoffSchedule.Decision d = schedule.next(FailureCategory.DEPENDENCY_MISSING, 6, ProcessingMode.AUTO_REPLAY, now);
        assertThat(d.status()).isEqualTo(FailureRepository.MANUAL);
        assertThat(d.nextAttemptAt()).isNull();
    }

    @Test
    void brokenLettersAreNeverRetriedAutomatically() {
        for (FailureCategory c : new FailureCategory[]{FailureCategory.VALIDATION, FailureCategory.DESERIALISATION,
                FailureCategory.CONFLICT, FailureCategory.UNKNOWN}) {
            assertThat(schedule.next(c, 1, ProcessingMode.LIVE, now).status()).isEqualTo(FailureRepository.MANUAL);
        }
    }

    @Test
    void aFailedManualReplayStaysWithThePerson() {
        assertThat(schedule.next(FailureCategory.TRANSIENT_EXHAUSTED, 2, ProcessingMode.MANUAL_REPLAY, now).status())
                .isEqualTo(FailureRepository.MANUAL);
    }
}
