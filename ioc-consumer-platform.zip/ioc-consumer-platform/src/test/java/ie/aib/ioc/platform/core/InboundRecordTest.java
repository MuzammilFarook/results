package ie.aib.ioc.platform.core;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Map;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class InboundRecordTest {

    private static InboundRecord rec(byte[] value, Map<String, byte[]> headers) {
        return InboundRecord.of("credit.account.v1", 3, 48122L, Instant.EPOCH, null, value, headers, Instant.EPOCH);
    }

    @Test
    void readsTraceIdFromW3cTraceparent() {
        InboundRecord r = rec(new byte[0], Map.of("traceparent",
                "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01".getBytes(StandardCharsets.US_ASCII)));
        assertThat(r.traceIdFromHeaders()).isEqualTo("4bf92f3577b34da6a3ce929d0e0e4736");
    }

    @Test
    void derivedTraceIdIsStableSoRedeliveryAndReplayShareIt() {
        InboundRecord a = rec(new byte[]{1}, Map.of());
        InboundRecord b = rec(new byte[]{2}, Map.of());
        assertThat(a.traceIdFromHeaders()).isNull();
        assertThat(a.derivedTraceId()).hasSize(32).isEqualTo(b.derivedTraceId());
    }

    @Test
    void readsConfluentSchemaIdFromWireFormat() {
        byte[] value = {0, 0, 1, (byte) 0x87, 0x07, 42};
        assertThat(rec(value, Map.of()).schemaId()).isEqualTo(0x00018707);
        assertThat(rec("not avro".getBytes(StandardCharsets.UTF_8), Map.of()).schemaId()).isNull();
    }

    @Test
    void fingerprintIsOfTheExactBytes() {
        assertThat(rec(new byte[]{1, 2}, Map.of()).payloadSha256()).hasSize(32)
                .isEqualTo(InboundRecord.sha256(new byte[]{1, 2}))
                .isNotEqualTo(InboundRecord.sha256(new byte[]{2, 1}));
    }
}
